<?php 
    include '../components/comp-conn.php';
    
    $tbl_id = $_POST['id'];
    $rider_id = $_POST['rider_id'];
    
    $query0 = mysqli_query($conn, "select * from tbl_user_make_order where id = '$tbl_id' ");
    while($row0 = mysqli_fetch_assoc($query0)){
        if(mysqli_num_rows($query0) == 1){
            
            mysqli_query($conn, "update tbl_user_make_order set status = '2', rider_id = '$rider_id', rider_status = '2' where id = '$tbl_id' ");
        }
    }
    echo '';
?>