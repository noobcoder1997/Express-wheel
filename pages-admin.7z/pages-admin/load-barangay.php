<?php
//  session_start();
    include( '../components/comp-conn.php');

    $municipal_code = htmlentities($_POST['city']);
    
    $query = "select * from tbl_brgy where citymunCode = '$municipal_code'";
    $brgy = mysqli_query($conn, $query);
    
    while($row = mysqli_fetch_assoc($brgy)){
        echo "<option value='$row[brgyCode]'>$row[brgyDesc]</option>";
    }
?>