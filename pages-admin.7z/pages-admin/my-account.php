<!DOCTYPE html>
<HTML> 
<head> 
<TITLE>Wheel Express</TITLE>  
<link rel="icon" href="../assets/image/eMove.png">
<meta name="viewport" content="width=device-width, initial-scale=1.0"> 
<link rel="stylesheet" href="../lib/bootstrap/css/bootstrap.css">
<link rel="stylesheet" href="../lib/bootstrap/css/bootstrap.min.css">
<link rel="stylesheet" href="../lib/font-awesome-5/css/all.css">
<script src="../lib/jquery/jquery-1.11.3.js"></script>
<script src="../lib/bootstrap/js/bootstrap.min.js"></script>
<?php
    include "../components/comp-conn.php"; 
    // session_start();
    $userNo =  "NO USER NUMBER".$_SESSION['userNo'];
    if(!isset($_SESSION['userNo'])){
        ?>
        <script>
            window.location.href='../';
        </script>
        <?php
    }else{
        $userNo = $_SESSION['userNo'];
    } 
    
    $userQry = mysqli_query($conn,"SELECT * FROM tbl_user WHERE no='$userNo' ")or die(mysqli_error($conn));
    $userRw  = mysqli_fetch_assoc($userQry);
    $verified = $userRw['verified'];
    if($verified == 2){
        
         ?>
        <script>
            alert("Sorry it seem your account has been deactivated. Please contact the customer service.")
            window.location.href='../';
        </script>
        <?php
    }else if($verified==1){
        $ver = "";
    }else{ 
        $pg  = 'verified-account.php';
        // $ver = '<a   data-toggle="modal" data-target="#verify" >Get verify</a>';
    }
?>
</head>
 <style>
  body {
    font: 400 15px Lato, sans-serif;
    line-height: 1.8;
    color: #818181;
    font-family: 'century gothic';
    width:100%;
  }
  h2 {
    font-size: 24px;
    text-transform: uppercase;
    color: #303030;
    font-weight: 600;
    margin-bottom: 30px;
  }
  h4 {
    font-size: 19px;
    line-height: 1.375em;
    color: #303030;
    font-weight: 400;
    margin-bottom: 30px;
  }  
  .jumbotron {
    background-color: #414c50;
    color: #192428;
    padding: 40px 25px;
    padding-top:70px;
    font-family: Montserrat, sans-serif; 
    
  }
  .container-fluid {
    padding: 40px 50px;
  }
  .bg-grey {
    background-color: #414c50;
    color: #39ace7;
  }
  .logo-small {
    color: #192428;
    font-size: 50px;
  }
  .logo {
    color: darkgreen;
    font-size: 200px;
  }
  .thumbnail {
    padding: 0 0 15px 0;
    border: none;
    border-radius: 0;
  }
  .thumbnail img {
    width: 100%;
    height: 100%;
    margin-bottom: 10px;
  }
  .prod:hover{
     border:2px solid grey;
      cursor: pointer;
      transition-duration: .5s;
  }
  .carousel-control.right, .carousel-control.left {
    background-image: none;
    color: darkgreen;
  }
  .carousel-indicators li {
    border-color: darkgreen;
  }
  .carousel-indicators li.active {
    background-color: darkgreen;
  }
  .item h4 {
    font-size: 19px;
    line-height: 1.375em;
    font-weight: 400;
    font-style: italic;
    margin: 70px 0;
  }
  .item span {
    font-style: normal;
  }
  .panel {
    border: 1px solid darkgreen; 
    border-radius:0 !important;
    transition: box-shadow 0.5s;
  }
  .panel:hover {
    box-shadow: 5px 0px 40px rgba(0,0,0, .2);
  }
  .panel-footer .btn:hover {
    border: 1px solid darkgreen;
    background-color: #fff !important;
    color: darkgreen;
  }
  .panel-heading {
    color: #fff !important;
    background-color:darkgreen !important;
    padding: 25px;
    border-bottom: 1px solid transparent;
    border-top-left-radius: 0px;
    border-top-right-radius: 0px;
    border-bottom-left-radius: 0px;
    border-bottom-right-radius: 0px;
  }
  .panel-footer {
    background-color: white !important;
  }
  .panel-footer h3 {
    font-size: 32px;
  }
  .panel-footer h4 {
    color: #aaa;
    font-size: 14px;
  }
  .panel-footer .btn {
    margin: 15px 0;
    background-color:darkgreen;
    color: #fff;
  }
  .navbar {
    margin-bottom: 0;
    background-color: #192428;
    z-index: 9999;
    border: 0;
    font-size: 12px !important;
    line-height: 1.42857143 !important;
    letter-spacing: 4px;
    border-radius: 0;
    font-family: Montserrat, sans-serif;
  }
  .navbar li a, .navbar .navbar-brand {
    color: #fff !important;
  }
  .navbar-nav li a:hover, .navbar-nav li.active a {
    color: #192428 !important;
    background-color: #fff !important;
  }
  .navbar-default .navbar-toggle {
    border-color: transparent;
    color: #fff !important;
  }
  footer .glyphicon {
    font-size: 20px;
    margin-bottom: 10px;
    color: #192428;
  }
  .slideanim {visibility:hidden;}
  .slide {
    animation-name: slide;
    -webkit-animation-name: slide;
    animation-duration: 1s;
    -webkit-animation-duration: 1s;
    visibility: visible;
  }
  @keyframes slide {
    0% {
      opacity: 0;
      transform: translateY(70%);
    } 
    100% {
      opacity: 1;
      transform: translateY(0%);
    }
  }
  @-webkit-keyframes slide {
    0% {
      opacity: 0;
      -webkit-transform: translateY(70%);
    } 
    100% {
      opacity: 1;
      -webkit-transform: translateY(0%);
    }
  } 
  .div-title, .div-title-1, .div-title-0{
    cursor: pointer; 
  }
  .div-title-1{
      color: #fff;
  }
  @media screen and (max-width: 480px) {
    .logo {
      font-size: 150px;
      width: 100%;
    }
    .div-title{
        border: 3px solid #0784b5; cursor: pointer; border-radius:5px;  
    }
    .div-title-1{
        border: 3px solid #fff; cursor: pointer; border-radius:5px;padding: 0;
    }
  }
  
 .cat-btn{
     background-color: white;
 }
.cat-btn:hover{ 
    border:1px solid black;
    background-color: lightgreen;
    cursor: pointer;
    transition-duration: 1s;
    
}
strong{
    word-wrap: word-break;
}
.btn{
    font-weight: bold;
}
.btn:hover, .btn:active, .delivery:hover, .delivery:active{
    transform: scale(1.03);
}
.btn:hover, .btn:active{
    transform: scale(1.03);
}
.my-btn:active, .my-btn:hover{
    transform: scale(1.06);
}
.nav-btn:active, .nav-btn:hover{
    transform: scale(1.5);
}
.btn{
    font-weight: bold;
}
.btn-block{
    width:100%;
}

  </style>
</head>
<body id="myPage" data-spy="scroll" data-target=".navbar" data-offset="60">

<nav class="navbar navbar-default navbar-fixed-top">
  <div class="container">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
      <a class="navbar-brand" href="#myPage">
          <table>
              <tr>
                  <td> 
                    <img src='../assets/image/eMove.png' style=' height:25px; border-radius:50%;' /> 
                     
                  </td>
                  <td style='color:white;font-weight:bold;'>&nbsp;<?php  echo $userRw['fn'];?></td>
                  <input type='hidden' id='userNo' value='<?php echo $userNo;?>' /> 
              </tr>
          </table>
      </a>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav navbar-right">
        <?php  
            $cartQry = mysqli_query($conn,"SELECT * FROM tbl_cart WHERE userNo='$userNo'  ")or die(mysqli_error($conn));
            $cartNum = mysqli_num_rows($cartQry);
            $cartNum = $cartNum==0?"":$cartNum;
            
            
            $orderQry = mysqli_query($conn,"SELECT * FROM tbl_order WHERE userNo='$userNo'  ")or die(mysqli_error($conn));
            $orderNum = mysqli_num_rows($orderQry);
            $orderNum = $orderNum==0?"":$orderNum;
        ?>
        <!--<?php if($verified==1){ ?><li><a href="#" data-toggle="modal" data-target="#startBusiness"><span class='fas fa-store-alt' ></span> MY STORE</a></li>  <?php } ?>-->
        <li><a class="my-btn" href="index.php" ><span class='fa fa-home' ></span>&nbsp;HOME <sup style='color:white;'><?php echo $cartNum;?></sup></a></li>  
        <li><a class="my-btn" href="my-trasaction.php" ><span class='fas fa-clipboard-check' ></span>&nbsp;HISTORY <sup style='color:white;'><?php echo $cartNum;?></sup></a></li>
        <li><a class="my-btn" href="my--notification.php" ><span class='fas fa-bell' ></span>&nbsp;NOTIFICATIONS <sup style='color:white;'><?php echo $cartNum;?></sup></a></li>
        <li><a class="my-btn" href="my-account.php" ><span class='fa fa-user' ></span>&nbsp;ME <sup style='color:white;'><?php echo '';?></sup></a></li>  
        <li><a class="my-btn" data-target="#logout-modal" data-toggle="modal"><span class='fa fa-sign-out-alt' ></span>&nbsp;EXIT</a></li>
      </ul>
    </div>
  </div>
</nav>

<div class="jumbotron text-center"  >
    <BR />
    <br />
    <div class='row'>
        <div class='col-sm-6'>   
        <img src='../assets/image/eMove.png' style='height:100px; border-radius:50%;margin-top:-30px;' />
        <strong style='font-size:45px;color:#39ace7'>Express Wheel</strong> 
        </div>
        <div class='col-sm-6'> 
            <div class='row' style='font-size:2em; font-family: "Comic Sans MS"; color: white '>
                <div class='col-sm-12'> 
                Connecting communities, delivering convenience
                </div> 
            </div>
        </div>
    </div> 
</div> 

<!--LOGOUT MODAL-->
<div id="logout-modal" class="modal fade" role="dialog" style='z-index:999999'>
    <div class="modal-dialog  modal-md"  >  
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title text-center" style='font-weight:bold; color:#192428'>
                    <img src='../assets/image/eMove.png' style='height:40px; border-radius:50%;' />
                    Express Wheel | Sign out
                </h4>
            </div>
            <div class="modal-body">  
                <div class='row'> 
                    <div class='col-sm-12'> 
                         Do you really want to continue?   
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <a type="button" class="btn btn-default btn-block" data-dismiss="modal">Cancel</a>
                <a type="button" class="btn btn-success btn-block" href="logout.php" >Sign out</a>
            </div>
        </div>
    </div>
</div>   

<!-- User Information -->

<div id="" class="container-fluid bg-grey" style="color:#0784b5;margin:0; padding:10px 0 0 0;">
    <div class="row" style="margin-top:10px;margin-left:5px;margin-right:5px;"> 
        <div class="col-sm-6 col-sm-offset-3 text-center">
            <div class="alert alert-default my-btn" style="border-radius:10px; box-shadow:0 0 15px 0 #000;background-color:#fff" data-toggle="collapse" href="#my-info">
                <h4 style="margin:0"><strong>MY INFORMATION&nbsp;<span class="fas fa-angle-down"></span></strong></h4>
            </div>  
            
        </div>
        <div class="col-sm-12 collapse" id="my-info" style="color:#fff">
            <div class="col-sm-12">
                <div class="col-sm-4 text-center"><br>
                    <img src="../assets/image/user.png" class="img-circle elevation-2" alt="Profile Photo" style="width:100px; height:100px; object-fit: fill; position: flex; margin-left: 10px;">
                    <br>
                    <div style="margin-left:10px">
                        <?php 
                            $index=1;
                            $query=mysqli_query($conn, "select COUNT(id) as total, SUM(rating) as summed from tbl_rider_rating where rider_id = '$userNo' ");
                            if(mysqli_num_rows($query)>0){

                                $fetched = mysqli_fetch_assoc($query);

                                if($fetched['total'] > 0){

                                    $rate = $fetched['summed']/$fetched['total']; 
                                    
                                    while($index <= 5){

                                        if($index > $rate){
                                                ?>
                                                <span class="fa fa-star" id="s<?php echo $index; ?>" style="color:lightgrey"></span>
                                            <?php
                                        }
                                        else{
                                            ?>
                                                <span class="fa fa-star" id="s<?php echo $index; ?>"  style="color:#0784b5"></span>
                                            <?php
                                        }
                                        $index++;
                                    } 
                                }
                                else{
                                    while($index <= 5){
                                    ?>
                                        <span class="fa fa-star" style="color:lightgray;"></span>
                                    <?php
                                        $index++;
                                    }
                                }
                            } 
                        ?>
                    </div>
                </div>
                <div class="col-sm-4">
                    <div class="row"><br>
                      <p>First Name: <?php $query = mysqli_query($conn, "SELECT * FROM tbl_user WHERE no='$userNo'"); if($result = mysqli_fetch_assoc($query)){ echo strtoupper($result['fn']); } ?></p>
                      <p>Middle Name: <?php $query = mysqli_query($conn, "SELECT * FROM tbl_user WHERE no='$userNo'"); if($result = mysqli_fetch_assoc($query)){ echo strtoupper($result['mn']); } ?></p>
                      <p>Last Name: <?php $query = mysqli_query($conn, "SELECT * FROM tbl_user WHERE no='$userNo'"); if($result = mysqli_fetch_assoc($query)){ echo strtoupper($result['ln']); } ?></p>
                      <p>Sex: <?php $query = mysqli_query($conn, "SELECT * FROM tbl_user WHERE no='$userNo'"); if($result = mysqli_fetch_assoc($query)){ echo strtoupper($result['sex']); } ?></p>
                    </div>
                </div>
                <div class="col-sm-4">
                    <div class="row">
                      <p>Date of Birth: <?php $query = mysqli_query($conn, "SELECT * FROM tbl_user WHERE no='$userNo'"); if($result = mysqli_fetch_assoc($query)){ echo strtoupper($result['bday']); } ?></p>
                      <p>Email Address: <?php $query = mysqli_query($conn, "SELECT * FROM tbl_user WHERE no='$userNo'"); if($result = mysqli_fetch_assoc($query)){ echo strtolower($result['email']); } ?>&nbsp;<span class="fa fa-edit fa-fw" data-toggle="modal" data-target="#edit-email-modal<?php echo $userNo; ?>"></span></p>
                      <p>Contact Number: <?php $query = mysqli_query($conn, "SELECT * FROM tbl_user WHERE no='$userNo'"); if($result = mysqli_fetch_assoc($query)){ echo strtoupper($result['contact']); } ?>&nbsp;<span class="fa fa-edit fa-fw" data-toggle="modal" data-target="#edit-contact-modal<?php echo $userNo; ?>"></span></p>
                      <p>Address: <?php $query = mysqli_query($conn, "SELECT * FROM tbl_user WHERE no='$userNo'"); if($result = mysqli_fetch_assoc($query)){ echo strtoupper($result['purok']).", ".strtoupper($result['barangay']).", ".strtoupper($result['municipal'])." (".strtoupper($result['zipcode']).")"; } ?>&nbsp;<span class="fa fa-edit fa-fw" data-toggle="modal" data-target="#edit-address-modal<?php echo $userNo; ?>"></span></p>
                    </div>
                </div>
                <div class="col-sm-4">
                    <div class="row">
                        <button class="btn btn-success btn-block" style="margin: 10px 0 20px 0" data-toggle="modal" data-target="#edit-unim-pass-modal<?php echo $userNo; ?>"><span class="fa fa-lock fa-fw"></span>&nbsp;Update Login Credentials</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!--EDIT USERNAME/PASSWORD MODAL-->
<div id="edit-unim-pass-modal<?php echo $userNo; ?>" class="modal fade" role="dialog" style='z-index:999999;color:#0784b5'>
    <div class="modal-dialog  modal-md"  >  
        <div class="modal-content">
            <div class="modal-header text-center">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title" style='font-weight:bold; color:#192428'>
                    <img src='../assets/image/eMove.png' style='height:40px; border-radius:50%;' />
                    Express Wheel | Edit Username/Password
                </h4>
            </div>
            <div class="modal-body">  
                <div class='row'> 
                    <div class='col-sm-12'> 
                        <p>Username</p>  
                        <input class="form-control" id="unim<?php echo $userNo; ?>" value="<?php $query = mysqli_query($conn, "SELECT * FROM tbl_user WHERE no='$userNo'"); if($result = mysqli_fetch_assoc($query)){ echo strtolower($result['user']); } ?>"/>
                    </div>
                </div>
                <div class='row'> 
                    <div class='col-sm-12'> 
                        <p>New Password</p>  
                        <input class="form-control" id="new-pass<?php echo $userNo; ?>" />
                    </div>
                </div>
                <div class='row'> 
                    <div class='col-sm-12'> 
                        <p>Confirm Password</p>  
                        <input class="form-control" id="confirm-pass<?php echo $userNo; ?>" />
                    </div>
                </div>
                <br>
                <span id="edit-unim-pass-message"></span>
            </div>
            <div class="modal-footer">
                <div class="row">
                    <div class="col-sm-12">
                        <a type="button" class="btn btn-default btn-block" data-dismiss="modal">Cancel</a>
                        <a type="button" class="btn btn-danger btn-block" onclick="edit_unim_pass(<?php echo $userNo; ?>)" >Submit</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!--EDIT EMAIL MODAL-->
<div id="edit-email-modal<?php echo $userNo; ?>" class="modal fade" role="dialog" style='z-index:999999' data-keyboard="false" data-backdrop="false">
    <div class="modal-dialog  modal-md"  >  
        <div class="modal-content">
            <div class="modal-header text-center">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title" style='font-weight:bold; color:#192428'>
                    <img src='../assets/image/eMove.png' style='height:40px; border-radius:50%;' />
                    Express Wheel | Edit Email Address
                </h4>
            </div>
            <div class="modal-body">  
                <div class='row'> 
                    <div class='col-sm-12'> 
                        <p>Enter Email Address</p>  
                        <input class="form-control" id="email<?php echo $userNo; ?>" value="<?php $query = mysqli_query($conn, "SELECT * FROM tbl_user WHERE no='$userNo'"); if($result = mysqli_fetch_assoc($query)){ echo strtolower($result['email']); } ?>"/>
                    </div>
                </div>
                <br>
                <span id="edit-email-message"></span>
            </div>
            <div class="modal-footer">
                <a type="button" class="btn btn-default btn-block" data-dismiss="modal">Cancel</a>
                <a type="button" class="btn btn-danger btn-block" onclick="edit_email(<?php echo $userNo; ?>)" >Submit</a>
            </div>
        </div>
    </div>
</div>

<!--EDIT CONTACT MODAL-->
<div id="edit-contact-modal<?php echo $userNo; ?>" class="modal fade" role="dialog" style='z-index:999999;' data-keyboard="false" data-backdrop="false">
    <div class="modal-dialog  modal-md"  >  
        <div class="modal-content">
            <div class="modal-header text-center">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title" style='font-weight:bold; color:#192428'>
                    <img src='../assets/image/eMove.png' style='height:40px; border-radius:50%;' />
                    Express Wheel | Edit Contact Number
                </h4>
            </div>
            <div class="modal-body">  
                <div class='row'> 
                    <div class='col-sm-12'> 
                        <p>Enter Contact Number</p>  
                        <input class="form-control" id="contact<?php echo $userNo; ?>" value="<?php $query = mysqli_query($conn, "SELECT * FROM tbl_user WHERE no='$userNo'"); if($result = mysqli_fetch_assoc($query)){ echo $result['contact']; } ?>"/>
                    </div>
                </div>
                <br>
                <span id="edit-contact-message"></span>
            </div>
            <div class="modal-footer">
                <a type="button" class="btn btn-default btn-block" data-dismiss="modal">Cancel</a>
                <a type="button" class="btn btn-danger btn-block" onclick="edit_contact(<?php echo $userNo; ?>)" >Submit</a>
            </div>
        </div>
    </div>
</div>

<!--EDIT ADDRESS MODAL-->
<div id="edit-address-modal<?php echo $userNo; ?>" class="modal fade" role="dialog" style='z-index:999999' data-keyboard="false" data-backdrop="false">
    <div class="modal-dialog  modal-md"  >  
        <div class="modal-content">
            <div class="modal-header text-center">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title" style='font-weight:bold; color:#192428'>
                    <img src='../assets/image/eMove.png' style='height:40px; border-radius:50%;' />
                    Express Wheel | Edit Home Address
                </h4>
            </div>
            <div class="modal-body">  
                <div class='row'> 
                    <div class='col-sm-12'> 
                        <p>Purok</p>
                        <input class="form-control" id="purok<?php echo $userNo; ?>" value="<?php $query = mysqli_query($conn, "SELECT * FROM tbl_user WHERE no='$userNo'"); if($result = mysqli_fetch_assoc($query)){ echo $result['purok']; } ?>">
                        <div class="row">
                            <div class="col-sm-4" style="display: none">
                                <p>Province</p>
                                <select id="select-province-0" class="form-control">
                                    <?php
                                        $query = "select * from refprovince WHERE provCode = '0864' order by provDesc ASC ";
                                        $province = mysqli_query($conn, $query);
                                        while($row = mysqli_fetch_assoc($province)){
                                            echo "<option value='$row[provCode]'>$row[provDesc]</option>";
                                        }
                                    ?>
                                </select>
                            </div>
                            <div class="col-sm-6">
                                <p>City</p>
                                <select id="select-citymun-0" class="form-control"></select>
                            </div>
                            <div class="col-sm-6">
                                <p>Barangay</p>
                                <select id="select-barangay-0" class="form-control"></select>
                            </div>
                        </div>
                        <p>Zip code</p>
                        <input class="form-control" id="zipcode<?php echo $userNo; ?>" value="<?php $query = mysqli_query($conn, "SELECT * FROM tbl_user WHERE no='$userNo'"); if($result = mysqli_fetch_assoc($query)){ echo $result['zipcode']; } ?>">
                        <p>Landmark</p>
                        <input class="form-control" id="landmark<?php echo $userNo; ?>" value="<?php $query = mysqli_query($conn, "SELECT * FROM tbl_user WHERE no='$userNo'"); if($result = mysqli_fetch_assoc($query)){ echo $result['landmark']; } ?>">
                    </div>
                </div>
                <br>
                <span id="edit-address-message"></span>
            </div>
            <div class="modal-footer">
                <a type="button" class="btn btn-default btn-block" data-dismiss="modal">Cancel</a>
                <a type="button" class="btn btn-danger btn-block" onclick="edit_address(<?php echo $userNo; ?>)" >Submit</a>
            </div>
        </div>
    </div>
</div>

<!--JOB HISTORY-->
<div id="" class="container-fluid" style="color:#0784b5;margin:0; padding:0;">
  <div class="row" style="margin-bottom: 20px;margin-top:20px;margin-left:5px;margin-right:5px"> 
    <div class="col-sm-6 col-sm-offset-3 text-center">
        <div class="alert alert-default my-btn" style="border-radius:10px; box-shadow:0 0 15px 0 #000" data-toggle="collapse" href="#job-history">
            <h4 style="margin:0"><strong>JOB HISTORY&nbsp;<span class="fas fa-angle-down"></span></strong></h4>
        </div>
    </div> 
    <div class="col-sm-6">
        <div class="collapse" id="job-history" style="margin-top:20px">
            <div class="col-12">
                <div class="col-sm-6 col-sm-offset-6">
                    <strong>Today&nbsp;&nbsp;
                        (<?php
                            $query=mysqli_query($conn, 'select count(id) as today from tbl_transactions where status = 1 and date = curdate()');
                            $row=mysqli_fetch_assoc($query);
                            echo $row['today'];
                        ?>)
                    </strong>
                </div>
            </div>
            <div class="col-12">
                <div class="col-sm-6 col-sm-offset-6">
                    <strong>Last Week&nbsp;&nbsp;
                        (<?php
                            $query=mysqli_query($conn, 'select count(id) as lastweek from tbl_transactions where status = 1 and week (date) = week( current_date ) - 1 and year( date) = year( current_date )');
                            $row=mysqli_fetch_assoc($query);
                            echo $row['lastweek'];
                        ?>)
                    </strong>
                </div>
            </div>
            <div class="col-12">
                <div class="col-sm-6 col-sm-offset-6">
                    <strong>Last Month&nbsp;&nbsp; 
                        (<?php
                            $query=mysqli_query($conn, "select count(id) as lastmonth from tbl_transactions where status = 1 and year(date) = year(current_date - interval 1 month)
and month(date) = month(current_date - interval 1 month)");
                            $row=mysqli_fetch_assoc($query);
                            echo $row['lastmonth'];
                        ?>)
                    </strong>
                </div>
            </div>
        </div>
    </div> 
<!--INCOME HISTORY-->
    <div style="height:20px"></div>
    <div class="col-sm-6 col-sm-offset-3 text-center">
        <div class="alert alert-default my-btn" style="border-radius:10px; box-shadow:0 0 15px 0 #000;margin-bottom:0"  data-toggle="collapse" href="#income">
            <h4 style="margin:0"><strong>TOTAL INCOME&nbsp;<span class="fas fa-angle-down"></span></strong></h4>
        </div>
    </div> 
    <div class="col-sm-6">
        <div class="collapse" id="income">
            <div class="col-12">
                <div class="col-sm-6 col-sm-offset-6" style="margin-top:20px">
                    <strong>Today&nbsp;&nbsp;
                        (&#8369; <?php
                            $query=mysqli_query($conn, 'select sum(fare) as today from tbl_transactions where status = 1 and date = curdate()');
                            $row=mysqli_fetch_assoc($query);
                             if(isset($row['today'])){
                                echo $row['today'];
                            }
                            else{
                                echo 0;
                            }
                        ?>)
                    </strong>
                </div>
            </div>
            <div class="col-12">
                <div class="col-sm-6 col-sm-offset-6">
                    <strong>Last Week&nbsp;&nbsp;
                        (&#8369; <?php
                            $query=mysqli_query($conn, 'select sum(fare) as lastweek from tbl_transactions where status = 1 and week (date) = week( current_date ) - 1 and year( date) = year( current_date )');
                            $row=mysqli_fetch_assoc($query);
                            if(isset($row['lastweek'])){
                                echo $row['lastweek'];
                            }
                            else{
                                echo 0;
                            }
                        ?>)
                    </strong>
                </div>
            </div>
            <div class="col-12">
                <div class="col-sm-6 col-sm-offset-6">
                    <strong>Last Month&nbsp;&nbsp; 
                        (&#8369; <?php
                            $query=mysqli_query($conn, "select sum(fare) as lastmonth from tbl_transactions where status = 1 and year(date) = year(current_date - interval 1 month)
and month(date) = month(current_date - interval 1 month)");
                            $row=mysqli_fetch_assoc($query);
                            if(isset($row['lastmonth'])){
                                echo $row['lastmonth'];
                            }
                            else{
                                echo 0;
                            }
                        ?>)
                    </strong>
                </div>
            </div>
        </div>
    </div>
  </div>
</div> 

<!-- Container (Contact Section) -->
<div id="user-info" class="container-fluid bg-grey" style="color:#0784b5;margin:0; padding:10px 0 0 0; margin-bottom:60px">
    <div class="row" style="margin-top:10px;margin-left:5px;margin-right:5px;"> 
        <div class="col-sm-6 col-sm-offset-3 text-center">
            <div class="alert alert-default my-btn" style="border-radius:10px; box-shadow:0 0 15px 0 #000;background-color:#fff" data-toggle="collapse" href="#customer-service">
                <h4 style="margin:0"><strong>COSTUMER SERVICES&nbsp;<span class="fas fa-angle-down"></span></strong></h4>
            </div> 
        </div>
        <div class="col-sm-6">
            <div class="col-sm-12">
                <div class="row collapse" id="customer-service" style="color:#fff">
                    <div class="col-sm-6 col-sm-offset-3">
                      <p>Please contact us</p>
                      <p><span class="fa fa-home fa-fw"></span>&nbsp;Business and Management Department</p>
                      <p><span class="fa fa-university fa-fw"></span>&nbsp;Southern Leyte State University-San Juan Campus</p>
                      <p><span class="fa fa-envelope fa-fw"></span>&nbsp;<a type="button" style="color: #fff;" href="mailto:dbma_sj@southernleytestateu.com">dbma_sj@southernleytestateu.com</a></p>
                      <p><span class="fab fa-facebook-f fa-fw"></span>&nbsp;<a type="button" style="color: #fff;" href="https://www.facebook.com/share/1A6MopfwGS">Express Wheel</a></p>
                    </div> 
                </div>
            </div>
        </div>
    </div>
</div> 

<footer class="container-fluid text-center mobile-view" style='background-color:#0784b5;'>
    <a href="#myPage" title="To Top" class="toTop">
        <span class="glyphicon glyphicon-chevron-up"></span>
    </a>
    <div class="row home-mobile-view" style="display: none">
       <a href="index.php" style="color:#000; margin:0 5%; font-size: 25px"><span class="fa fa-home fa-fw nav-btn"></span></a>
       <a href="my-trasaction.php" style="color:#000; margin:0 5%; font-size: 25px"><span class="fas fa-clipboard-check fa-fw nav-btn"></span></a>
       <a href="my--notification.php" style="color:#000; margin:0 5%; font-size: 25px"><span class="fas fa-bell fa-fw nav-btn"></span></a>
       <a href="my-account.php" style="color:#000; margin:0 5%; font-size: 25px"><span class="fa fa-user fa-fw nav-btn"></span></a>
       <a href="#logout-modal" data-toggle="modal" style="color:#000; margin:0 5%; font-size: 25px"><span class="fa fa-sign-out-alt fa-fw nav-btn"></span></a>
    </div>
    <script>
       setInterval(()=>{
           if(screen.width <= 480){
                $('.mobile-view').removeClass('container-fluid').addClass('container').css({'padding':'10px 20px','bottom':'0','position':'fixed','width':'100%'});
                $('.home-mobile-view').css('display','block')
                $('.toTop').css('display','none')
                $('div#order').css('margin-bottom', '65px')
                $('.navbar-toggle').css('display','none');
           } 
           else{
                $('.mobile-view').addClass('container-fluid').removeClass('container');
                $('.home-mobile-view').css('display','none')
                $('.toTop').css('display','block')
                // $('.navbar-toggle').css('display','block');
           }
       },100)
    </script>
</footer>

<script>
$(document).ready(function(){
  // Add smooth scrolling to all links in navbar + footer link
  $(".navbar a, footer a[href='#myPage']").on('click', function(event) {
    // Make sure this.hash has a value before overriding default behavior
    if (this.hash !== "") {
      // Prevent default anchor click behavior
      event.preventDefault();

      // Store hash
      var hash = this.hash;

      // Using jQuery's animate() method to add smooth page scroll
      // The optional number (900) specifies the number of milliseconds it takes to scroll to the specified area
      $('html, body').animate({
        scrollTop: $(hash).offset().top
      }, 900, function(){
   
        // Add hash (#) to URL when done scrolling (default click behavior)
        window.location.hash = hash;
      });
    } // End if
  });
  
  $(window).scroll(function() {
    $(".slideanim").each(function(){
      var pos = $(this).offset().top;

      var winTop = $(window).scrollTop();
        if (pos < winTop + 600) {
          $(this).addClass("slide");
        }
    });
  });
})
</script>

<script>
    function edit_email(id){
        $.ajax({
            data: "email="+$('#email'+id).val()+"&id="+id,
            url: "edit-email.php",
            method: "post",
        }).done( function(data){
            $('#edit-email-message').html(data);
        })
    }
</script><script>
    function edit_contact(id){
        $.ajax({
            data: "contact="+$('#contact'+id).val()+"&id="+id,
            url: "edit-contact.php",
            method: "post",
        }).done( function(data){
            $('#edit-contact-message').html(data);
        })
    }
</script>
<script>
    function edit_address(id){
        $.ajax({
            data: "purok="+$('#purok'+id).val()+"&landmark="+$('#landmark'+id).val()+"&zipcode="+$('#zipcode'+id).val()+"&province="+$('#select-province-0 :selected').text()+"&city="+$('#select-citymun-0 :selected').text()+"&brgy="+$('#select-barangay-0 :selected').text()+"&id="+id,
            url: "edit-address.php",
            method: "post",
        }).done( function(data){
            $('#edit-address-message').html(data);
        })
    }
</script>

<script>
    // loads the municipals that belongs under the selected province
    $("#select-province-0").on('change', function(){
        $.ajax({
            url: 'load-municipal.php',
            method: "POST",
            data: "province="+$("#select-province-0").val(),
        }).done( function(data){
            $('#select-citymun-0').html(data);
            
            $.ajax({
                url: 'load-barangay.php',
                method: "POST",
                data: "city="+$("#select-citymun-0").val(),
            }).done( function(data){
                $('#select-barangay-0').html(data);
            })
        })
    })
    
    // loads the barangays that belongs under the selected municipal
    $("#select-citymun-0").on('change', function(){
        $.ajax({
            url: 'load-barangay.php',
            method: "POST",
            data: "city="+$("#select-citymun-0").val(),
        }).done( function(data){
            $('#select-barangay-0').html(data);
        })
    })
</script>

<script>
    //  Sender's Address
    $(document).ready( function(){
        // loads the municipals that belongs under the selected province
        ajax = $.ajax({
            url: 'load-municipal.php',
            method: "POST",
            data: "province="+$("#select-province-0").val(),
        })
        $.when(ajax).done( function(ajax){
            $('#select-citymun-0').html(ajax);
            
            // loads the barangays that belongs under the selected municipal
            $.ajax({
                url: 'load-barangay.php',
                method: "POST",
                data: "city="+$("#select-citymun-0").val(),
            }).done( function(data){
                $('#select-barangay-0').html(data);
            })
        })
    })
</script>

<script>
    function edit_unim_pass(id){
        $.ajax(
            {
                url: "edit-unim-pass.php",
                method: "post",
                data: "unim="+$('#unim'+id).val()+"&new_pass="+$('#new-pass'+id).val()+"&confirm_pass="+$('#confirm-pass'+id).val()+"&id="+id,
            } 
        ).done( function(data){
            $('#edit-unim-pass-message').html(data);
        });        
    }
</script>
</body>
</html>