<!DOCTYPE html>
<HTML> 
<head> 
<TITLE>Wheel Express</TITLE>  
<link rel="icon" href="../assets/image/eMove.png">
<meta name="viewport" content="width=device-width, initial-scale=1.0"> 
<link rel="stylesheet" href="../lib/bootstrap/css/bootstrap.css">
<link rel="stylesheet" href="../lib/bootstrap/css/bootstrap.min.css">
<link rel="stylesheet" href="../lib/font-awesome-5/css/all.css">
<link rel="stylesheet" href="https://cdn.datatables.net/2.2.1/css/dataTables.dataTables.min.css">
<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.3/dist/leaflet.css" integrity="sha256-kLaT2GOSpHechhsozzB+flnD+zUyjE2LlfWPgU04xyI=" crossorigin="" />
<link rel="stylesheet" href="https://unpkg.com/leaflet-routing-machine@latest/dist/leaflet-routing-machine.css" />
<link rel="stylesheet" href="style.css">
<script src="../lib/jquery/jquery-1.11.3.js"></script>
<script src="../lib/bootstrap/js/bootstrap.min.js"></script>
<script src="https://cdn.datatables.net/2.2.1/js/dataTables.min.js"></script>
<script src="https://unpkg.com/leaflet@1.9.3/dist/leaflet.js" integrity="sha256-WBkoXOwTeyKclOHuWtc+i2uENFpDZ9YPdf5Hf+D7ewM=" crossorigin=""></script>
<script src="https://unpkg.com/leaflet-routing-machine@latest/dist/leaflet-routing-machine.js"></script>
<?php
    include "../components/comp-conn.php"; 
    // session_start();
    if(!isset($_SESSION['admin_status'])){
        header('location: ../');
    }
    
    $userNo =  "NO USER NUMBER".$_SESSION['userNo'];
    if(!isset($_SESSION['userNo'])){
        ?>
        <script>
            window.location.href='../';
        </script>
        <?php
    }else{
        $userNo = $_SESSION['userNo'];
    } 
    
    $userQry = mysqli_query($conn,"SELECT * FROM tbl_user WHERE no='$userNo' ")or die(mysqli_error($conn));
    $userRw  = mysqli_fetch_assoc($userQry);
?>
<style>
    #map, #track-order-map { 
        height: 350px;
        background: #fff;
        border: 1px solid grey;
        box-shadow: 0 0 15px 0 #000;
    }
    img.end_huechange { filter: hue-rotate(270deg); }
    img.start_huechange { filter: hue-rotate(150deg); }
    .btn{
        font-weight: bold;
    }
    .btn:hover, .btn:active, .delivery:hover, .delivery:active{
        transform: scale(1.03);
    }
    .btn:hover, .btn:active{
        transform: scale(1.03);
    }
    .my-btn:active, .my-btn:hover{
        transform: scale(1.06);
    }
    .nav-btn:active, .nav-btn:hover{
        transform: scale(1.5);
    }
    .btn{
        font-weight: bold;
    }
    .btn-block{
        width:100%;
    }
    .alert-default{
        background-color:#fff;
    }
</style>

</head>
<!-- -->
<body id="myPage" data-spy="scroll" data-target=".navbar" data-offset="60">

<nav class="navbar navbar-default navbar-fixed-top">
  <div class="container">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
      <a class="navbar-brand" href="#myPage">
          <table>
              <tr>
                  <td> 
                    <img src='../assets/image/eMove.png' style=' height:25px; border-radius:50%;' /> 
                     
                  </td>
                  <td style='color:white;font-weight:bold;'>&nbsp;<?php  echo $userRw['fn'];?></td>
                  <input type='hidden' id='userNo' value='<?php echo $userNo;?>' /> 
              </tr>
          </table>
      </a>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav navbar-right"><li><a class="my-btn" href="index.php" ><span class='fa fa-home fa-fw' ></span> HOME </a></li>  
        <li><a class="my-btn" href="my-trasaction.php" ><span class='fas fa-clipboard-check fa-fw' ></span> HISTORY </a></li> 
        <li><a class="my-btn" href="my--notification.php" ><span class='fas fa-bell fa-fw' ></span> NOTIFICATIONS </a></li> 
        <li><a class="my-btn" href="my-account.php" ><span class='fa fa-user fa-fw' ></span> ME </a></li>  
        <li><a class="my-btn" data-target="#logout-modal" data-toggle="modal"><span class='fa fa-sign-out-alt' ></span>EXIT</a></li>
      </ul>
    </div>
  </div>
</nav>

<div class="jumbotron text-center">
    <BR />
    <br />
    <div class='row'>
        <div class='col-sm-6'>   
        <img src='../assets/image/eMove.png' style='height:100px; border-radius:50%;margin-top:-30px;' />
        <strong style='font-size:45px;color:#39ace7'>Express&nbsp;Wheel</strong> 
        </div>
        <div class='col-sm-6'> 
            <div class='row' style='font-size:2em; font-family: "Comic Sans MS"; color: white '>
                <div class='col-sm-12'> 
                Connecting communities, delivering convenience
                </div> 
            </div>
        </div>
    </div> 
</div> 

<!-- Container () -->
<div id="order" class="container-fluid bg-grey"  style="margin:0; padding:0">
    <div class="row" style="margin-bottom: 20px;margin-top:20px;margin-left:5px;margin-right:5px">
        <div id="div-booking"></div>
        <script>
        </script>
        <div class="col-sm-4"  style="color:#0784b5">
            <div class="card">
              <!--<div class="card-header" style='background:darkgrey; margin:0;padding:0'>-->
              <!--    <h1>&nbsp;</h1>-->
              <!--</div>-->
              <div class="card-body text-center">
                <div class="row">   
                    <div class="col-sm-12">
                        <div class="form-group">
                            <span class="btn my-btn" data-toggle="modal" data-target="#view-booking">
                                <p id="order"><span class='fas fa-map-marker order-icon'></span> Booking
                                <br>
                                <i style="font-size: 18px;font-weight:normal;margin-left: 10px" id="bookings">View Bookings <span id="book-count" style="font-weight:bolder"></span></i>
                                </p> 
                            </span> 
                                <!-- The Modal -->
                                <div class="modal" id="view-booking" style='z-index:999999; color:#0784b5' data-keyboard="false" data-backdrop="false">
                                  <div class="modal-dialog">
                                    <div class="modal-content">
                                
                                      <!-- Modal Header -->
                                      <div class="modal-header">
                                         <!--<button type="button" class="close" data-dismiss="modal">&times;</button>-->
                                        <h4 class="modal-title" style='font-weight:bold; color:#192428'>
                                            <img src='../assets/image/eMove.png' style='height:40px; border-radius:50%;' />
                                            Express Wheel | Ride Booking
                                        </h4>
                                      </div>
                                
                                      <!-- Modal body -->
                                      <div class="modal-body" style="text-align:left">
                                        <!-- Modal body content -->
                                        <div id="row">
                                            <?php
                                                $interval=1;
                                                $background_color="";
                                                $color="";
                                                $border="";

                                                $query0 = mysqli_query($conn, "select * from tbl_book_ride where status = 0");
                                                if(mysqli_num_rows($query0)>0){
                                                    while($r=mysqli_fetch_assoc($query0)){  

                                                        if($interval % 2 == 0){
                                                            $background_color='#39ace7';
                                                            $color='#fff';
                                                        }
                                                        else{
                                                            $background_color='#fff';
                                                            $color='#39ace7';
                                                            $border='3px solid #39ace7';
                                                        }
                                                        $interval++;
                                            ?>
                                            <div class="row div<?php echo $r['id']; ?>" style="border:<?php echo $border; ?> ;background-color:<?php echo $background_color; ?> ;color:<?php echo $color ?>;  border-radius:5px; margin:5px; padding:5px; cursor:pointer" data-dismiss="modal" data-toggle="modal" data-target="#book-waiting<?php echo $r['id']; ?>"> 
                                                <div class="col-sm-3 text-center" style=" top:14px">
                                                    <img src="../assets/image/user.png" class="img-circle elevation-2" alt="Profile Photo" style="width:95px; height:95px; object-fit: fill; position: flex;">  
                                                </div>
                                                <div class="col-sm-8 "  style="margin-top: 10px">
                                                    <p style="margin:0">Name: 
                                                        <?php 
                                                            $query1 = mysqli_query($conn, "select * from tbl_user where no = '$r[passenger_id]' ");
                                                            if($r1=mysqli_fetch_assoc($query1)){
                                                                echo strtoupper($r1['fn']." ".$r1['ln']);
                                                            }
                                                        ?>
                                                    </p>
                                                    <p style="margin:0">Pick up at: 
                                                        <?php 
                                                            $query1 = mysqli_query($conn, "select * from tbl_brgy where id = '$r[_from]' ");
                                                            if($r1=mysqli_fetch_assoc($query1)){
                                                                echo strtoupper($r1['brgyDesc']);
                                                            }
                                                        ?>
                                                    </p>
                                                    <p style="margin:0">Drop off at: 
                                                        <?php 
                                                            $query1 = mysqli_query($conn, "select * from tbl_brgy where id = '$r[_to]' ");
                                                            if($r1=mysqli_fetch_assoc($query1)){
                                                                echo strtoupper($r1['brgyDesc']);
                                                            }
                                                        ?>
                                                    </p>
                                                    <p style="margin:0">Fare:
                                                        <span style="font-size: 17px">&#8369;</span><strong> <?php echo $r['fare']; ?></strong> 
                                                    </p>
                                                </div>
                                            </div>
                                            <?php
                                                    }
                                                }
                                                else{
                                                    echo "<div class='text-center'><h3>No Bookings yet!</h3></div>";
                                                }
                                            ?> 
                                        </div>
                                      </div>
                                
                                      <!-- Modal footer -->
                                      <div class="modal-footer">
                                        <button type="button" class="btn btn-default btn-block" data-dismiss="modal">Close</button>
                                        <!--<button type="submit" class="btn btn-danger" id="submit-order-btn" >Submit</button>-->
                                      </div>
                                
                                    </div>
                                  </div>
                                </div>
                            
                                <?php
                                    $query0 = mysqli_query($conn, "select * from tbl_book_ride where rider_id='' and status = '0' ");
                                    while($result0 = mysqli_fetch_assoc($query0)){
                                ?>
                                <!-- The Modal -->
                                <div class="modal" id="book-waiting<?php echo $result0['id']; ?>" style='z-index:999999' data-keyboard="false" data-backdrop="false">
                                  <div class="modal-dialog">
                                    <div class="modal-content">
                                
                                      <!-- Modal Header -->
                                      <div class="modal-header">
                                         <button type="button" class="close" data-dismiss="modal">&times;</button>
                                        <h4 class="modal-title" style='font-weight:bold; color:#192428'>
                                            <img src='../assets/image/eMove.png' style='height:40px; border-radius:50%;' />
                                            Express Wheel | Ride Booking
                                        </h4>
                                      </div>
                                
                                      <!-- Modal body -->
                                      <div class="modal-body" style="text-align:Left">
                                        <span id="book-ride-alert"></span>
                                        <div class="row" style="background-color:#39ace7 ; color:#fff;  border-radius:5px; margin:0;"  > 
                                            <div class="col-sm-12 text-center" style=" top:7px">
                                                <img src="../assets/image/user.png" class="img-circle elevation-2" alt="Profile Photo" style="width:70px; height:70px; object-fit: fill; position: flex;"> 
                                                
                                                <?php
                                                    $name='';
                                                    $contact='';
                                                    $count='';
                                                    
                                                    $query1= mysqli_query($conn, "select * from tbl_user where no = '$result0[passenger_id]' ");
                                                    while($result1 = mysqli_fetch_assoc($query1)){
                                                        $name = $result1['fn'].' '.$result1['ln'];
                                                        $contact = $result1['contact'];
                                                        $contact = substr($contact, 1);
                                                    }
                                                ?>
                                                <a class="btn btn-success btn-sms" type="button" onclick="document.location.href = 'sms:0<?php echo $contact; ?>?body=hello!' "><span class="fas fa-sms fa-fw" style="font-size:18px"></span></a>
                                                
                                                <a class="btn btn-success btn-call" type="button" onclick="document.location.href = 'tel:+63<?php echo $contact; ?>' "><span class="fas fa-phone fa-fw" style="font-size:18px"></span></a>
                                            </div>
                                            <div class="col-sm-12" style="margin-top: 10px">
                                                <p style="margin:0">Name: 
                                                    <?php
                                                        echo strtoupper($name);
                                                    ?>
                                                </p>
                                                 <p style="margin:0">Contact #: 
                                                    <?php
                                                        echo $contact;
                                                    ?>
                                                </p>
                                                <?php
                                                    $from='';
                                                    $query1= mysqli_query($conn, "select * from refbrgy where id = '$result0[_from]' ");
                                                    while($result1 = mysqli_fetch_assoc($query1)){
                                                        $from = $result1['brgyDesc'];
                                                    }
                                                ?>
                                                <p style="margin:0">Pick up at:
                                                    <?php
                                                        echo strtoupper($from);
                                                    ?>
                                                </p>
                                                <?php
                                                    $to='';
                                                    $query1= mysqli_query($conn, "select * from refbrgy where id = '$result0[_to]' ");
                                                    while($result1 = mysqli_fetch_assoc($query1)){
                                                        $to = $result1['brgyDesc'];
                                                    }
                                                ?>
                                                <p style="margin:0">Drop off at:
                                                    <?php
                                                        echo strtoupper($to);
                                                    ?>
                                                </p>
                                            </div>
                                            <div class="col-sm-12" style="margin-bottom: 10px">
                                                
                                                <p style="margin:0">Note:</p>
                                                
                                                <textarea class="form-control" rows="3" id="br-note" placeholder="E.g. Bring raincoat" style="resize:none;font-size:14px" disabled="disabled"><?php echo $result0['note']; ?></textarea>
                                                
                                                <p style="margin:0">Instruction:</p>
                                                
                                                <textarea class="form-control" rows="3" id="br-instruction" placeholder="E.g. a landmark, or beside a building" style="resize:none;font-size:14px" disabled="disabled"><?php echo $result0['instruction']; ?></textarea>
                                            </div>                                            
                                        </div> 
                                        <div style="margin-bottom: 10px"></div>                                                
                                        <div class="" id="map2<?php echo $result0['id']; ?>" style="width: 100%; height: 350px; box-shadow: 0 0 10px 0 #000; border-radius:5px; "></div>
                                  </div>   
                                                <script>
                                                   
                                                    const _map<?php echo $result0['id']; ?> = L.map('map2<?php echo $result0['id']; ?>', { attributionControl:false });
                                                    // Initializes map
                                                    
                                                    _map<?php echo $result0['id']; ?>.setView([51.505, -0.09], 13); 
                                                    // Sets initial coordinates and zoom level
                                                    
                                                    L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
                                                        maxZoom: 19,
                                                        minZoom: 10,
                                                        attribution: '© OpenStreetMap'
                                                    }).addTo(_map<?php echo $result0['id']; ?>); 
                                                    // Sets map data source and associates with map

                                                    let marker<?php echo $result0['id']; ?>, circle<?php echo $result0['id']; ?>, zoomed<?php echo $result0['id']; ?>;
                                                    
                                                    <?php
                                                        $strt_lat='';
                                                        $strt_lng='';
                                                        $end_lat='';
                                                        $end_lng='';
                                                    ?>
                                                    
                                                    function success(pos) {
                                                                                                       
                                                    <?php
                                                        $_result0 = mysqli_query($conn, "select * from tbl_brgy_position where brgy_id = '$result0[_from]'");
                                                        if($row = mysqli_fetch_assoc($_result0)){
                                                            $strt_lat=$row['latitude'];
                                                            $strt_lng=$row['longitude'];
                                                        }
                                                        $_result1 = mysqli_query($conn, "select * from tbl_brgy_position where brgy_id = '$result0[_to]'");
                                                        if($row = mysqli_fetch_assoc($_result1)){
                                                            $end_lat=$row['latitude'];
                                                            $end_lng=$row['longitude'];
                                                        }
                                                    ?>
                                                    
                                                        const lat = pos.coords.latitude;
                                                        const lng = pos.coords.longitude;
                                                        const accuracy = pos.coords.accuracy;
                                                        var locations = [
                                                          ["YOU", lat, lng],
                                                          ["START", <?php echo $strt_lat; ?>, <?php echo $strt_lng; ?>],
                                                          ["END", <?php echo $end_lat; ?>, <?php echo $end_lng; ?>]
                                                        ];
                                                                                                            
                                                        if (marker<?php echo $result0['id']; ?>) {
                                                            _map<?php echo $result0['id']; ?>.removeLayer(marker<?php echo $result0['id']; ?>);
                                                            _map<?php echo $result0['id']; ?>.removeLayer(circle<?php echo $result0['id']; ?>);
                                                        }
                                                        // Removes any existing marker and circule (new ones about to be set)
                                                        for (var i = 0; i < locations.length; i++) {
                                                            if(locations[i][0] == 'START'){
                                                                marker<?php echo $result0['id']; ?> = new L.marker([locations[i][1], locations[i][2]])
                                                                .bindTooltip(locations[i][0], { permanent: true, direction: 'right'}).addTo(_map<?php echo $result0['id']; ?>).openPopup();
                                                                marker<?php echo $result0['id']; ?>._icon.classList.add("start_huechange");
                                                            }
                                                            else if(locations[i][0] == 'END'){
                                                                marker<?php echo $result0['id']; ?> = new L.marker([locations[i][1], locations[i][2]])
                                                                .bindTooltip(locations[i][0], { permanent: true, direction: 'right'}).addTo(_map<?php echo $result0['id']; ?>).openPopup();
                                                                marker<?php echo $result0['id']; ?>._icon.classList.add("end_huechange");
                                                            }
                                                            else{
                                                                marker<?php echo $result0['id']; ?> = new L.marker([locations[i][1], locations[i][2]])
                                                                .bindTooltip(locations[i][0], { permanent: true, direction: 'right'}).addTo(_map<?php echo $result0['id']; ?>).openPopup();
                                                            }
                                                        }
                                                        // marker<?php //echo $result0['id']; ?> = L.marker([lat, lng]).bindPopup('You').addTo(_map<?php //echo $result0['id']; ?>);
                                                        circle<?php echo $result0['id']; ?> = L.circle([lat, lng], { radius: accuracy }).addTo(_map<?php echo $result0['id']; ?>);
                                                        // Adds marker to the map and a circle for accuracy
                                                    
                                                        if (!zoomed<?php echo $result0['id']; ?>) {
                                                            zoomed<?php echo $result0['id']; ?> = _map<?php echo $result0['id']; ?>.fitBounds(circle<?php echo $result0['id']; ?>.getBounds()); 
                                                        }
                                                        // Set zoom to boundaries of accuracy circle
                                                    
                                                        _map<?php echo $result0['id']; ?>.setView([lat, lng]);
                                                        // Set map focus to current user position
                                                        
                                                        //Routing from rider to Passenger
                                                        $('#_accept-btn<?php echo $result0['id']; ?>').on('click', () => {
                                                            L.Routing.control({
                                                                waypoints: [
                                                                    L.latLng(lat,lng),
                                                                    L.latLng(<?php echo $strt_lat; ?>, <?php echo $strt_lng; ?>)
                                                                ],
                                                                routeWhileDragging: true,
                                                                draggableWaypoints: false,
                                                                addWaypoints: false
                                                            }).addTo(_map<?php echo $result0['id']; ?>);
                                                        });
                                                        //Routing from start to end point
                                                        $('#pickup-btn<?php echo $result0['id']; ?>').on('click', () => {
                                                            L.Routing.control({
                                                                waypoints: [
                                                                    L.latLng(lat,lng),
                                                                    L.latLng(<?php echo $end_lat; ?>, <?php echo $end_lng; ?>)
                                                                ],
                                                                routeWhileDragging: true,
                                                                draggableWaypoints: false,
                                                                addWaypoints: false
                                                            }).addTo(_map<?php echo $result0['id']; ?>);
                                                        });
                                                    }
                                                    
                                                    function error(err) {
                                                    
                                                        if (err.code === 1) {
                                                            alert("Please allow geolocation access");
                                                        } else {
                                                            alert("Cannot get current location");
                                                        }
                                                    
                                                    }
                                                    
                                                    setTimeout( navigator.geolocation.getCurrentPosition(success, error), 500);
                                                    // navigator.geolocation.getCurrentPosition(success, error)
                                                
                                                </script>
                                                <script>
                                                    $('#book-waiting<?php echo $result0['id']; ?>').on('shown.bs.modal', ()=>{
                                                        //resize the map - this is the important part for you
                                                        _map<?php echo $result0['id']; ?>.invalidateSize();
                                                    })
                                                </script>

                                      <!-- Modal footer -->
                                      <div class="modal-footer">
                                        <div class="row">
                                            <div class="col-sm-12">
                                                <button type="button" class="btn btn-danger btn-block" id="_accept-btn<?php echo $result0['id']; ?>" onclick="acceptBooking(<?php echo $result0['id']; ?> )"><strong>Accept Booking</strong></button>
                                                <button type="button" class="btn btn-primary btn-block" id="pickup-btn<?php echo $result0['id']; ?>" onclick="pickupBooking(<?php echo $result0['id']; ?> )" style="display:none"><strong>Passenger is on board</strong></button>
                                                <button type="button" class="btn btn-success btn-block" data-toggle="modal" data-dismiss="modal" onclick="arrivedBooking(<?php echo $result0['id']; ?> )" data-target="#ride-success<?php echo $result0['id']; ?>" id="dropoff-btn<?php echo $result0['id']; ?>"  style="display:none"><strong>Passenger has arrived</strong></button> 
                                                <button type="button" class="btn btn-default btn-block" id="close-btn<?php echo $result0['id']; ?>" data-dismiss="modal">Close</button>                                                
                                            </div>
                                        </div>
                                        <script>
                                            // rider accepts the booking
                                            function acceptBooking(id){
                                                $('#_accept-btn'+id).css('display', 'none');
                                                $('#pickup-btn'+id).fadeIn(1000);
                                                
                                                form = new FormData();
                                                form.append('id', id)
                                                form.append('rider-id', <?php echo $userNo; ?>)
                                                $.ajax({
                                                    data: form,
                                                    type: 'post',
                                                    url: 'accept-booking-status.php',
                                                    cache: false,
                                                    contentType: false,
                                                    processData: false,
                                                    success: (data)=>{
                                                        console.log(data);
                                                    },
                                                    error: (data)=>{
                                                        console.log(data)
                                                    }
                                                }).done(()=>{
                                                    $('#close-btn'+id).attr({'id' : 'cancel-btn'+id, 'onclick' : 'cancelBooking('+id+')'}).html('Cancel Booking');
                                                });
                                            }
                                            // Rider picks up the passenger
                                            function pickupBooking(id){
                                                $('#pickup-btn'+id).css('display', 'none');
                                                $('#dropoff-btn'+id).fadeIn(1000);
                                                if($('#dropoff-btn'+id).is(":visible") == true){
                                                    $('#cancel-btn'+id).fadeOut(500);
                                                }
                                                
                                                form = new FormData();
                                                form.append('id', id)
                                                form.append('rider-id', <?php echo $userNo; ?>)
                                                $.ajax({
                                                    data: form,
                                                    type: 'post',
                                                    url: 'riderto-passenger-location.php',
                                                    cache: false,
                                                    contentType: false,
                                                    processData: false,
                                                    success: (data)=>{
                                                        console.log(data);
                                                    },
                                                    error: (data)=>{
                                                        console.log(data)
                                                    }
                                                });
                                            }
                                            //rider has arrived to end point
                                            function arrivedBooking(id){
                                                form = new FormData();
                                                form.append('id', id)
                                                form.append('rider-id', <?php echo $userNo; ?>)
                                                $.ajax({
                                                    data: form,
                                                    type: 'post',
                                                    url: 'riderto-passenger-arrived.php',
                                                    cache: false,
                                                    contentType: false,
                                                    processData: false,
                                                    success: (data)=>{
                                                        console.log(data);
                                                    },
                                                    error: (data)=>{
                                                        console.log(data)
                                                    }
                                                });
                                            }
                                            // rider cancels the booking
                                            function cancelBooking(id){
                                                clearInterval(endTimer);
                                                form = new FormData();
                                                form.append('id', id)
                                                form.append('rider-id', <?php echo $userNo; ?>);
                                                form.append('from', '<?php echo $from; ?>');
                                                form.append('to', '<?php echo $to; ?>');
                                                form.append('passenger_id', <?php echo $result0['passenger_id']; ?>);
                                                $.ajax({
                                                    data: form,
                                                    type: 'post',
                                                    url: 'cancel-booking-status.php',
                                                    cache: false,
                                                    contentType: false,
                                                    processData: false,
                                                    success: (data)=>{
                                                        console.log(data);
                                                        alert('You cancelled the booking...');
                                                    },
                                                    error: (data)=>{
                                                        console.log(data)
                                                    }
                                                }).done(()=>{
                                                    history.go(0);
                                                });
                                            }
                                        </script>
                                        <script>
                                            //triggers when the passenger cancelled the booking
                                            endTimer=setInterval(()=>{
                                                $.ajax({
                                                    data: 'id='+<?php echo $result0['id']; ?>+'&rider_id='+<?php echo $userNo; ?>,
                                                    url: 'booking-cancelled.php',
                                                    type: 'post'
                                                }).done((data)=>{
                                                    if(data == 1){   
                                                        clearInterval(endTimer);
                                                        $('#cancelled-booking-modal').modal('toggle');
                                                    }
                                                })
                                            }, 500);
                                        </script>
                                        <script>
                                            // checks if the booking was cancelled by time
                                            statusTimer = setInterval(() => {
                                                $.ajax({
                                                    data: 'id='+<?php echo $result0['id']; ?>+'&rider_id='+<?php echo $userNo; ?>,
                                                    url: 'check-cancelled-status.php',
                                                    method: 'post',
                                                }).done((data)=>{
                                                    if(data == 1){
                                                        clearInterval(statusTimer);

                                                        $('#hasAutoCancel').modal('show');

                                                        $('#hasAutoCancel').on('hidden.bs.modal', function () {
                                                            statusTimer = setInterval(() => {
                                                                $.ajax({
                                                                    data: 'id='+<?php echo $result0['id']; ?>+'&rider_id='+<?php echo $userNo; ?>,
                                                                    url: 'check-cancelled-status.php',
                                                                    method: 'post',
                                                                }).done((data)=>{
                                                                    console.log(data);
                                                                    if(data == 1){
                                                                        $('#hasAutoCancel').modal('show');
                                                                    }
                                                                })
                                                            }, 500);
                                                        });
                                                    }
                                                })
                                            }, 500)
                                        </script>
                                      </div>
                                    </div>
                                  </div>
                                </div>

                                <!-- The Arrival Modal (Ride Hailing)-->
                                <div class="modal" id="ride-success<?php echo $result0['id']; ?>" style='z-index:999999'>
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                
                                            <!-- Modal Header -->
                                            <div class="modal-header text-center">
                                                <button type="button" class="close" data-dismiss="modal">&times;</button>
                                                <h4 class="modal-title" style='font-weight:bold; color:#192428'>
                                                    <img src='../assets/image/eMove.png' style='height:40px; border-radius:50%;' />
                                                    Express Wheel | Ride Booking
                                                </h4>
                                            </div>
                                
                                          <!-- Modal body -->
                                          <div class="modal-body">
                                            <span id="book-ride-alert"></span>
                                                <div class="row" style="margin:0 5%; background-color:#39ace7 ; color:#fff; border-radius:1%;" > 
                                                    <div class="col-sm-12 text-center">
                                                        <img src="../assets/image/user.png" class="img-circle elevation-2" alt="Profile Photo" style="width:120px; height:120px; object-fit: fill; position: flex;margin-top:20%"> 
                                                        <h4>You have arrived!</h4>
                                                        <h1>&#8369; 
                                                            <?php 
                                                                 echo $result0['fare'];
                                                            ?>
                                                        </h1>
                                                        <h4>Passenger's Total Fare</h4>
                                                        <i style="margin-bottom:20%">Please collect passenger's total fare</i>
                                                    </div>
                                                </div>
                                          </div>
                                          <!-- Modal footer -->
                                          <div class="modal-footer">
                                            <!--<button type="button" class="btn btn-danger" data-dismiss="modal">Submit</button>-->
                                            <div class="row">
                                                <div class="col-sm-12">
                                                    <button type="button" class="btn btn-danger btn-block" onclick="successTransaction()">OK</button>
                                                    <script>
                                                        function successTransaction(){
                                                            form = new FormData();
                                                            form.append('book_id',<?php echo $result0['id']; ?>);
                                                            form.append('from','<?php $query = mysqli_query($conn, "select brgyDesc from refbrgy where id = '$result0[_from]'");if($row=mysqli_fetch_assoc($query)){echo $row['brgyDesc'];} ?>');
                                                            form.append('to','<?php $query = mysqli_query($conn, "select brgyDesc from refbrgy where id = '$result0[_to]'");if($row=mysqli_fetch_assoc($query)){echo $row['brgyDesc'];} ?>');
                                                            form.append('fare',<?php echo $result0['fare']; ?>)
                                                            form.append('passenger_id',<?php echo $result0['passenger_id'] ?>)
                                                            $.ajax({
                                                                data:form,
                                                                type:'post',
                                                                url: 'transaction.php',
                                                                processData: false,
                                                                contentType:false,
                                                                cache:false,
                                                                success: (data)=>{
                                                                    $('#ride-success<?php echo $result0['id']; ?>').modal('toggle');
                                                                    location.reload();
                                                                }
                                                            });
                                                        }
                                                    </script>
                                                </div>
                                            </div>
                                          </div>
                                    </div>
                                  </div>
                                </div>
                                <?php
                                    }
                                ?>

                        </div>
                    </div>
                </div>
              </div>
              <!--<div class="card-footer"></div>-->
          </div>
        </div> 
        <div class="col-sm-4 order"  style="color:#0784b5">
            <div class="card">
              <!--<div class="card-header" style='background:darkgrey; margin:0;padding:0'>-->
              <!--    <h1>&nbsp;</h1>-->
              <!--</div>-->
              <div class="card-body text-center">
                <div class="row">   
                    <div class="col-sm-12">
                        <div class="form-group">
                            <span class="btn my-btn btn-block" data-toggle="modal" data-target="#make-order">
                                <p id="order"><span class='fas fa-shopping-cart order-icon'></span> Orders <br><i style="font-size: 18px;font-weight:normal;margin-left: 10px">View Orders <span id="orders" style="font-weight:bolder"></span></i>
                                </p> 
                            </span> 
                            <!-- The Modal -->
                            <div class="modal" id="make-order" style='z-index:999999; color:#0784b5' data-keyboard="false" data-backdrop="false">
                              <div class="modal-dialog">
                                <div class="modal-content">
                            
                                  <!-- Modal Header -->
                                  <div class="modal-header">
                                     <!--<button type="button" class="close" data-dismiss="modal">&times;</button>-->
                                    <h4 class="modal-title" style='font-weight:bold; color:#192428'>
                                        <img src='../assets/image/eMove.png' style='height:40px; border-radius:50%;' />
                                        Express Wheel | View Orders
                                    </h4>
                                  </div>
                            
                                  <!-- Modal body -->
                                  <div class="modal-body" style="text-align:left">
                                    <!-- Modal body content -->
                                    <div class="btn-group btn-block">
                                        <a class="btn btn-primary sameday" style="width:50%" onclick="samedayDelivery()">Same Day<span id="sday-del" style="font-weight:bolder;margin:5px;padding:0"><span></a>
                                        <script>
                                            function samedayDelivery(){
                                                if( $('.sameday').hasClass('btn-default')){
                                                    $('.scheduled').addClass('btn-default').removeClass('btn-primary');
                                                    $('.sameday').addClass('btn-primary').removeClass('btn-default');
                                                }
                                                $('#div-sameday').css('display', 'block');
                                                $('#div-scheduled').css('display', 'none');
                                            }
                                        </script>
                                        <a class="btn btn-default scheduled" style="width:50%; border-radius:0 4px 4px 0" onclick="scheduledDelivery()">Scheduled<span id="sched-del" style="font-weight:bolder;margin:5px;padding:0"><span></a>
                                        <script>
                                            function scheduledDelivery(){
                                                if( $('.scheduled').hasClass('btn-default')){
                                                    $('.scheduled').removeClass('btn-default').addClass('btn-primary');
                                                    $('.sameday').removeClass('btn-primary').addClass('btn-default');
                                                }
                                                $('#div-scheduled').css('display', 'block');
                                                $('#div-sameday').css('display', 'none');
                                            }
                                        </script>
                                    </div>
                                    <div id="div-sameday" style="display:block">
                                        <?php
                                            $interval=1;
                                            $background_color="";
                                            $color="";
                                            $border="";
                                            $query0 = mysqli_query($conn, "select * from tbl_user_make_order where status ='0' and rider_id = '' and rider_status = '0' and delivery_type = 'Same day'");
                                            if(mysqli_num_rows($query0) > 0){
                                                while($result0 = mysqli_fetch_assoc($query0)){
                                                    if($interval % 2 == 0){
                                                        $background_color='#39ace7';
                                                        $color='#fff';
                                                    }
                                                    else{
                                                        $background_color='#fff';
                                                        $color='#39ace7';
                                                        $border='3px solid #39ace7';
                                                    }
                                                    $interval++;
                                        ?>
                                        <div class="row delivery" style="border:<?php echo $border; ?> ;background-color:<?php echo $background_color; ?> ;color:<?php echo $color ?>;  border-radius:5px; margin:5px; padding:5px; cursor:pointer" data-dismiss="modal" data-toggle="modal" data-target="#order-waiting<?php echo $result0['id']; ?>"> 
                                            <div class="col-sm-3 text-center" style=" top:14px">
                                                <img src="../assets/image/user.png" class="img-circle elevation-2" alt="Profile Photo" style="width:95px; height:95px; object-fit: fill; position: flex;">  
                                            </div>
                                            <div class="col-sm-8 "  style="margin-top: 10px">
                                                <p style="margin:0" id='sender-name0'><?php echo $result0['sender_name']; ?></p>
                                                <p style="margin:0" id="sender-contact0"><?php echo $result0['sender_contact']; ?></p>
                                                <p style="margin:0" id="item-name0"><?php echo $result0['item_name']; ?></p>
                                                <p style="margin:0">Fare: &#8369;<span style="font-weight:bolder;" id="item-fare0"><?php echo $result0['fee']; ?></span>
                                                </p>
                                            </div>
                                        </div>
                                        <?php
                                                }
                                            }
                                            else{
                                                echo "<div class='text-center'><h3>No Orders yet!</h3></div>";
                                            }
                                        ?> 
                                    </div>
                                    <!--END SAMEDAY DELIVERIES-->
                                    
                                    <div id="div-scheduled" style="display:none">
                                        <?php
                                            $interval=1;
                                            $background_color="";
                                            $color="";
                                            $border="";
                                            $query0 = mysqli_query($conn, "select * from tbl_user_make_order where status ='0' and rider_id = '' and rider_status = '0' and delivery_type = 'Scheduled'");
                                            if(mysqli_num_rows($query0) > 0){
                                                while($result0 = mysqli_fetch_assoc($query0)){
                                                    if($interval % 2 == 0){
                                                        $background_color='#39ace7';
                                                        $color='#fff';
                                                    }
                                                    else{
                                                        $background_color='#fff';
                                                        $color='#39ace7';
                                                        $border='3px solid #39ace7';
                                                    }
                                                    $interval++;
                                        ?>
                                        <div class="row delivery" style="border:<?php echo $border; ?> ;background-color:<?php echo $background_color; ?> ;color:<?php echo $color ?>;  border-radius:5px; margin:5px; padding:5px; cursor:pointer" data-dismiss="modal" data-toggle="modal" data-target="#order-waiting<?php echo $result0['id']; ?>"> 
                                            <div class="col-sm-3 text-center" style=" top:14px">
                                                <img src="../assets/image/user.png" class="img-circle elevation-2" alt="Profile Photo" style="width:95px; height:95px; object-fit: fill; position: flex;">  
                                            </div>
                                            <div class="col-sm-9 "  style="margin-top: 10px">
                                                <p style="margin:0" id="sender-name1"><?php echo $result0['sender_name']; ?>
                                                </p>
                                                <p style="margin:0" id="sender-contact1"><?php echo $result0['sender_contact']; ?>
                                                </p>
                                                <p style="margin:0" id="item-name1"><?php echo $result0['item_name']; ?>
                                                </p>
                                                <span class="badge sched" style="display:flex;position:absolute;right:10px;background-color:#000;bottom:5px">
                                                    <?php 
                                                        $date = strtotime($result0['item_scheduled']);
                                                        if($date != null){
                                                            echo $date = date('m-d-Y', $date);
                                                        }
                                                        else{
                                                            echo "00-00-00";
                                                        }
                                                    ?>
                                                </span>
                                                <p style="margin:0">Fare: &#8369; :<span style="font-weight: bolder" id="item-fare1"></span>
                                                    <?php echo $result0['fee']; ?>
                                                </p>
                                            </div>
                                        </div>
                                        <?php
                                                }
                                            }
                                            else{
                                                echo "<div class='text-center'><h3>No Orders yet!</h3></div>";
                                            }
                                        ?>  
                                    </div>
                                    <!--END SCHEDULED DELIVERIES-->
                                    <span id="book-ride-message"></span>  
                                  </div>
                            
                                  <!-- Modal footer -->
                                  <div class="modal-footer">
                                    <button type="button" class="btn btn-default btn-block" data-dismiss="modal">Close</button>
                                    <!--<button type="submit" class="btn btn-danger" id="submit-order-btn" >Submit</button>-->
                                  </div>
                            
                                </div>
                              </div>
                            </div>

                            <?php
                                $tbl_id=''; $sender=''; $fare=''; $to=''; $from='';
                                $query0 = mysqli_query($conn, "select * from tbl_user_make_order where status ='0' and rider_id = '' and rider_status = '0' ");
                                while($result0 = mysqli_fetch_assoc($query0)){
                                    $tbl_id = $result0 ['id']; $sender=$result0['sender_id']; $fare=$result0['fee']; $to=$result0['recipient_barangay']; $from=$result0['sender_barangay'];
                            ?>
                            <!-- The Modal -->
                            <div class="modal" id="order-waiting<?php echo $result0['id']; ?>" style='z-index:999999' data-keyboard="false" data-backdrop="false">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                
                                      <!-- Modal Header -->
                                      <div class="modal-header">
                                         <button type="button" class="close" data-dismiss="modal">&times;</button>
                                        <h4 class="modal-title" style='font-weight:bold; color:#192428'>
                                            <img src='../assets/image/eMove.png' style='height:40px; border-radius:50%;' />
                                            Express Wheel | View Orders
                                        </h4>
                                      </div>
                                
                                      <!-- Modal body -->
                                      <div class="modal-body" style="text-align:Left">
                                        <div class="row" style="background-color:#39ace7 ; color:#fff;  border-radius:5px; margin:0"  > 
                                            <div class="col-sm-12 text-center" style=" top:7px">
                                                <img src="../assets/image/user.png" class="img-circle elevation-2" alt="Profile Photo" style="width:70px; height:70px; object-fit: fill; position: flex;"> 
                                                <a class="btn btn-success btn-sms" type="button" onclick="document.location.href = 'sms:+63<?php echo substr($result0['sender_contact'], 1); ?>?body=hello!'"><span class="fas fa-sms fa-fw" style="font-size:18px"></span></a>
                                                
                                                <a class="btn btn-success btn-call" type="button" onclick="document.location.href = 'tel:+63<?php echo substr($result0['sender_contact'], 1); ?>'"><span class="fas fa-phone fa-fw" style="font-size:18px"></span></a>
                                            </div>
                                            <div class="col-sm-12" style="margin-top: 10px">
                                                <label>Item's Information</label>
                                                <p style="margin:0">Package Name: 
                                                    <?php
                                                        echo strtoupper($result0['item_name']."/".$result0['service_type']."/".$result0['package_type']." * 1(pcs)");
                                                    ?>
                                                </p>
                                                <p style="margin:0">Dimension:
                                                    <?php
                                                        echo strtoupper($result0['item_length']."cm*".$result0['item_width']."cm*".$result0['item_height']."cm");
                                                    ?>
                                                </p>
                                                <p style="margin:0">Weight:
                                                    <?php
                                                        echo strtoupper($result0['item_weight'].'kg');
                                                    ?>
                                                </p>
                                                <p style="margin:0">Total Fee: &#8369;
                                                    <?php
                                                        echo $result0['fee'];
                                                    ?>
                                                </p>
                                                <p style="margin:0">Remarks:
                                                    <?php
                                                        echo $result0['remarks'];
                                                    ?>
                                                </p>
                                            </div>
                                            <div class="col-sm-12" style="margin-top: 10px">
                                                <label>Sender's Information</label>
                                                <p style="margin:0">Name: 
                                                    <?php
                                                        echo strtoupper($result0['sender_name']);
                                                    ?>
                                                </p>
                                                 <p style="margin:0">Contact #: 
                                                    <?php
                                                        echo $result0['sender_contact'];
                                                    ?>
                                                </p>
                                                <p style="margin:0">Address:
                                                    <?php
                                                        echo strtoupper($result0['sender_barangay'].', '.$result0['sender_city']);
                                                    ?>
                                                </p>
                                                <p style="margin:0">Landmark:
                                                    <?php
                                                        echo strtoupper($result0['sender_landmark']);
                                                    ?>
                                                </p>
                                            </div>
                                            <div class="col-sm-12" style="margin-top: 10px;">
                                                <label>Recipient's Information</label>
                                                <p style="margin:0">Name: 
                                                    <?php
                                                        echo strtoupper($result0['recipient_name']);
                                                    ?>
                                                </p>
                                                 <p style="margin:0">Contact #: 
                                                    <?php
                                                        echo $result0['recipient_contact'];
                                                    ?>
                                                </p>
                                                <p style="margin:0">Address:
                                                    <?php
                                                        echo strtoupper($result0['recipient_barangay'].', '.$result0['recipient_city']);
                                                    ?>
                                                </p>
                                                <p style="margin:0">Landmark:
                                                    <?php
                                                        echo strtoupper($result0['recipient_landmark']);
                                                    ?>
                                                </p>
                                            </div>
                                        </div>
                                          
                                        <div style="margin-top: 10px;"></div>
                                        <div id="track-order-map<?php echo $result0['id']; ?>" style="width: 100%; height: 350px; box-shadow: 0 0 10px 0 #000; border-radius:5px; "></div> 
                                    
                                      
                                        <div class="row">
                                            <div class="col-sm-12">
                                                <br>
                                                <div class="alert alert-info">
                                                    <strong>Attention: </strong> Please collect the delivery fee first before proceeding to the delivery.
                                                    <!--<a class="close" data-dismiss="alert">&times</a>-->
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    
                                      <!-- Modal footer -->
                                      <div class="modal-footer">
                                          <div class="row">
                                                <div class="col-sm-12">
                                                    <button type="button" class="btn btn-danger btn-block" id="accept-btn<?php echo $result0['id']; ?>" onclick="acceptOrder(<?php echo $result0['id']; ?>)" >Accept Order</button>
                                                    <script>
                                                        function acceptOrder(id){
                                                            form = new FormData();
                                                            form.append('id', id)
                                                            form.append('rider_id',<?php echo $userNo; ?>)
                                                            $.ajax({
                                                                data: form,
                                                                type: 'post',
                                                                url: 'accept-order.php',
                                                                cache: false,
                                                                contentType: false,
                                                                processData: false,
                                                                success: (data)=>{
                                                                    console.log(data);
                                                                },
                                                                error: (data)=>{
                                                                    console.log(data)
                                                                }
                                                            }).done(function(){
                                                                $("#accept-btn"+id).css('display', 'none');
                                                                $("#collect-btn"+id).fadeIn(1000);
                                                                $('#_close-btn'+id).html('Cancel Booking').attr('onclick', '_cancelBooking('+id+')');
                                                            });
                                                        }
                                                    </script>
                                                </div>
                                                <div class="col-sm-12">
                                                    <button type="button" class="btn btn-primary btn-block" id="collect-btn<?php echo $result0['id']; ?>" onclick="collectOrder(<?php echo $result0['id']; ?>)" style="display:none">Order Collected</button>
                                                    <script>
                                                    function collectOrder(id){
                                                        form = new FormData();
                                                        form.append('id', id)
                                                        form.append('rider_id',<?php echo $userNo; ?>)
                                                        $.ajax({
                                                            data: form,
                                                            type: 'post',
                                                            url: 'collect-order.php',
                                                            cache: false,
                                                            contentType: false,
                                                            processData: false,
                                                            success: (data)=>{
                                                                console.log(data);
                                                            },
                                                            error: (data)=>{
                                                                console.log(data)
                                                            }
                                                        }).done( function(data){
                                                            $("#collect-btn"+id).css('display', 'none');
                                                            $("#deliver-btn"+id).fadeIn(1000);
                                                        });
                                                    }
                                                </script>
                                                </div>
                                                <div class="col-sm-12">
                                                    <button type="button" class="btn btn-success btn-block" id="deliver-btn<?php echo $result0['id']; ?>" onclick="deliverOrder(<?php echo $result0['id']; ?>)" style="display:none">Order Delivered</button>
                                                    <script>
                                                        function deliverOrder(id){
                                                            form = new FormData();
                                                            form.append('id', id)
                                                            form.append('rider_id',<?php echo $userNo; ?>)
                                                            $.ajax({
                                                                data: form,
                                                                type: 'post',
                                                                url: 'deliver-order.php',
                                                                cache: false,
                                                                contentType: false,
                                                                processData: false,
                                                                success: (data)=>{
                                                                    console.log(data);
                                                                    // location.reload();
                                                                    $("#order-delivered<?php echo $result0['id']; ?>").modal('toggle');
                                                                },
                                                                error: (data)=>{
                                                                    console.log(data)
                                                                }
                                                            });
                                                        }
                                                    </script>                                    
                                                </div>
                                              <div class="col-sm-12" style="padding-top:3px">
                                                    <button type="button" class="btn btn-default btn-block" id="_close-btn<?php echo $result0['id']; ?>" data-dismiss="modal">Close</button>
                                              </div>
                                              <script>
                                                    function _cancelBooking(id){
                                                        form=new FormData();
                                                        form.append('id',id);
                                                        $.ajax({
                                                            data:form,
                                                            url:'order-cancel.php',
                                                            type:'post',
                                                            contentType:false,
                                                            processData:false,
                                                            cache:false,
                                                        }).done((data) => {
                                                            console.log(data);
                                                            alert(data);
                                                            history.go(0);
                                                        })
                                                    }
                                              </script>
                                          </div>

                                      </div>
                                
                                    </div>
                                  </div>
                                </div>
                                                <script>
                                                   
                                                    const order_map<?php echo $result0['id']; ?> = L.map('track-order-map<?php echo $result0['id']; ?>', { attributionControl:false });
                                                
                                                    // Initializes map
                                                    
                                                    order_map<?php echo $result0['id']; ?>.setView([51.505, -0.09], 13); 
                                                    // Sets initial coordinates and zoom level
                                                    
                                                    L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
                                                        maxZoom: 19,
                                                        minZoom: 10,
                                                        attribution: '© OpenStreetMap'
                                                    }).addTo(order_map<?php echo $result0['id']; ?>); 
                                                    // Sets map data source and associates with map
                                                   
                                                    <?php
                                                        $strt_lat;
                                                        $strt_lng;
                                                        $end_lat;
                                                        $end_lng;
                                                        $_result0 = mysqli_query($conn, "select id from tbl_brgy where brgyDesc = '$result0[sender_barangay]' ");
                                                        if($row = mysqli_fetch_assoc($_result0)){
                                                            $_query1=mysqli_query($conn, "select * from tbl_brgy_position where brgy_id = '$row[id]' ");
                                                            if($row1 = mysqli_fetch_assoc($_query1)){
                                                                $strt_lat=$row1['latitude'];
                                                                $strt_lng=$row1['longitude'];                                                                
                                                            }
                                                        }
                                                        $_result1 = mysqli_query($conn, "select id from tbl_brgy where brgyDesc = '$result0[recipient_barangay]' ");
                                                        if($row = mysqli_fetch_assoc($_result1)){
                                                            $_query1=mysqli_query($conn, "select * from tbl_brgy_position where brgy_id = '$row[id]' ");
                                                            while($row1 = mysqli_fetch_assoc($_query1)){
                                                                $end_lat=$row1['latitude'];
                                                                $end_lng=$row1['longitude'];
                                                            }
                                                        }
                                                    ?>
                                                    
                                                    let order_marker<?php echo $result0['id']; ?>, order_circle<?php echo $result0['id']; ?>, order_zoomed<?php echo $result0['id']; ?>;
                                                    
                                                    function success(pos) {
                                                    
                                                        const lat = pos.coords.latitude;
                                                        const lng = pos.coords.longitude;
                                                        const accuracy = pos.coords.accuracy;
                                                        var locations = [
                                                          ["YOU", lat, lng],
                                                          ["START", <?php echo $strt_lat; ?>, <?php echo $strt_lng; ?>],
                                                          ["END", <?php echo $end_lat; ?>, <?php echo $end_lng; ?>]
                                                        ];
                                                                                                            
                                                        if (order_marker<?php echo $result0['id']; ?>) {
                                                            order_map<?php echo $result0['id']; ?>.removeLayer(order_marker<?php echo $result0['id']; ?>);
                                                            order_map<?php echo $result0['id']; ?>.removeLayer(order_circle<?php echo $result0['id']; ?>);
                                                        }
                                                        // Removes any existing marker and circule (new ones about to be set)
                                                        
                                                        for (var i = 0; i < locations.length; i++) {
                                                            if(locations[i][0] == 'START'){
                                                                order_marker<?php echo $result0['id']; ?> = new L.marker([locations[i][1], locations[i][2]])
                                                                .bindTooltip(locations[i][0], { permanent: true, direction: 'right'}).addTo(order_map<?php echo $result0['id']; ?>).openPopup();
                                                                order_marker<?php echo $result0['id']; ?>._icon.classList.add("start_huechange");
                                                            }
                                                            else if(locations[i][0] == 'END'){
                                                                order_marker<?php echo $result0['id']; ?> = new L.marker([locations[i][1], locations[i][2]])
                                                                .bindTooltip(locations[i][0], { permanent: true, direction: 'right'}).addTo(order_map<?php echo $result0['id']; ?>).openPopup();
                                                                order_marker<?php echo $result0['id']; ?>._icon.classList.add("end_huechange");
                                                            }
                                                            else {
                                                                order_marker<?php echo $result0['id']; ?> = new L.marker([locations[i][1], locations[i][2]])
                                                                .bindTooltip(locations[i][0], { permanent: true, direction: 'right'}).addTo(order_map<?php echo $result0['id']; ?>).openPopup();
                                                            }
                                                        }
                                                        // order_marker<?php //echo $result0['id']; ?> = L.marker([lat, lng]).bindPopup('You').addTo(_map<?php //echo $result0['id']; ?>);
                                                        order_circle<?php echo $result0['id']; ?> = L.circle([lat, lng], { radius: accuracy }).addTo(order_map<?php echo $result0['id']; ?>);
                                                        // Adds marker to the map and a circle for accuracy
                                                    
                                                        if (!order_zoomed<?php echo $result0['id']; ?>) {
                                                            order_zoomed<?php echo $result0['id']; ?> = order_map<?php echo $result0['id']; ?>.fitBounds(order_circle<?php echo $result0['id']; ?>.getBounds()); 
                                                        }
                                                        // Set zoom to boundaries of accuracy circle
                                                    
                                                        order_map<?php echo $result0['id']; ?>.setView([lat, lng]);
                                                        // Set map focus to current user position
                                                        
                                                        //Routing from rider to Passenger
                                                        $('#accept-btn<?php echo $result0['id']; ?>').on('click', () => {
                                                            L.Routing.control({
                                                                waypoints: [
                                                                    L.latLng(lat,lng),
                                                                    L.latLng(<?php echo $strt_lat; ?>, <?php echo $strt_lng; ?>)
                                                                ],
                                                                routeWhileDragging: true,
                                                                draggableWaypoints: false,
                                                                addWaypoints: false
                                                            }).addTo(order_map<?php echo $result0['id']; ?>);
                                                        });
                                                        //Routing from start to end point
                                                        $('#collect-btn<?php echo $result0['id']; ?>').on('click', () => {
                                                            L.Routing.control({
                                                                waypoints: [
                                                                    L.latLng(lat,lng),
                                                                    L.latLng(<?php echo $end_lat; ?>, <?php echo $end_lng; ?>)
                                                                ],
                                                                routeWhileDragging: true,
                                                                draggableWaypoints: false,
                                                                addWaypoints: false
                                                            }).addTo(order_map<?php echo $result0['id']; ?>);
                                                        });
                                                    }
                                                    
                                                    function error(err) {
                                                    
                                                        if (err.code === 1) {
                                                            alert("Please allow geolocation access");
                                                        } else {
                                                            alert("Cannot get current location");
                                                        }
                                                    
                                                    }
                                                    
                                                    setInterval(navigator.geolocation.getCurrentPosition(success, error), 1000)
                                                    
                                                
                                                </script>
                                                <script>
                                                    $('#order-waiting<?php echo $result0['id']; ?>').on('shown.bs.modal', ()=>{
                                                        //resize the map - this is the important part for you
                                                        order_map<?php echo $result0['id']; ?>.invalidateSize();
                                                    })
                                                </script>
                                                
                                <!-- The Arrival Modal (Delivery)-->
                                <div class="modal" id="order-delivered<?php echo $result0['id']; ?>" style='z-index:999999'>
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                
                                        <!-- Modal Header -->
                                        <div class="modal-header text-center">
                                            <button type="button" class="close" data-dismiss="modal">&times;</button>
                                            <h4 class="modal-title" style='font-weight:bold; color:#192428'>
                                                <img src='../assets/image/eMove.png' style='height:40px; border-radius:50%;' />
                                                Express Wheel | View Orders
                                            </h4>
                                        </div>
                                
                                          <!-- Modal body -->
                                          <div class="modal-body">
                                            <span id="book-ride-alert"></span>
                                                <div class="row" style="margin:0 5%; background-color:#39ace7 ; color:#fff; border-radius:1%;" > 
                                                    <div class="col-sm-12 text-center">
                                                        <img src="../assets/image/user.png" class="img-circle elevation-2" alt="Profile Photo" style="width:120px; height:120px; object-fit: fill; position: flex;margin-top:20%"> 
                                                        <h4>Package Delivered!</h4>
                                                        <br>
                                                        <div class="alert alert-info">
                                                            <strong>Attention: </strong> Please take a picture of package together with the recipient as proof of delivery.
                                                            <a class="btn btn-default" onclick="$('#input-proof-img<?php echo $result0['id']; ?>').click();">&nbsp;<span class="fa fa-camera fa-fw" style="font-size:24px">&nbsp;</a>
                                                            <input type="file" id="input-proof-img<?php echo $result0['id']; ?>" style="position: absolute; left: -9999px;" tabindex="0" accept="image/png, image/gif, image/jpeg"/>
                                                        </div>
                                                        
                                                        <img style="height: 400px; width: 100%; box-shadow:0 0 15px 0 #000; border-radius: 5px; margin-bottom:20px" id="img<?php echo $result0['id']; ?>" name="img">
                                                        
                                                        <span id="upload-alert<?php echo $result0['id']; ?>"></span>
                                                        <br>
                                                    </div>
                                                </div>
                                          </div>
                                          <!-- Modal footer -->
                                          <div class="modal-footer">
                                            <!--<button type="button" class="btn btn-danger" data-dismiss="modal">Submit</button>-->
                                            <div class="row">
                                                <div class="col-sm-12">
                                                    <button type="button" class="btn btn-danger btn-block" id="upload-btn<?php echo $result0['id']; ?>">Delivery Completed</button>
                                                </div>
                                            </div>
                                          </div>
                                          <script>
                                                // Triggers whenever the rider uplaods an image
                                                $("#input-proof-img<?php echo $result0['id']; ?>").on('change', function () {
                                                    if (this.files && this.files[0]) {
                                                        var img = document.getElementById('img<?php echo $result0['id']; ?>');
                                                        img.onload = () => {
                                                        URL.revokeObjectURL(img.src);
                                                    }
                                                    img.src = URL.createObjectURL(this.files[0]);
                                                      
                                                    const fileInput = document.getElementById('input-proof-img<?php echo $result0['id']; ?>');
                                                    
                                                    const _img = fileInput.files[0];
                                                    
                                                    if(!_img){
                                                        return alert("Please upload picture of parcel together with the recipient!");
                                                    }
                                                    form = new FormData();
                                                    form.append('img', _img)
                                                    form.append('id', <?php echo $tbl_id; ?>)
                                                    $.ajax({
                                                        data: form,
                                                        type: 'post',
                                                        url: 'upload-proof-delivery.php',
                                                        contentType: false,
                                                        processData: false,
                                                        cache:false,
                                                        beforeSend:()=>{ },
                                                        success:(data)=>{ $('#upload-alert').html(data); },
                                                        error:(data)=>{ console.log(data); }
                                                    });
                                                    }
                                                });
                                            </script>
                                            <script>
                                                // Button after uploading proof of delivery
                                                $("#upload-btn<?php echo $result0['id']; ?>").on('click', () => {

                                                    if( $("#input-proof-img<?php echo $result0['id']; ?>").val() != ''){
                                                        
                                                        form = new FormData();
                                                        form.append('book_id','<?php echo $result0['id']; ?>');
                                                        form.append('from','<?php echo $from; ?>');
                                                        form.append('to','<?php echo $to; ?>');
                                                        form.append('sender_id','<?php echo $sender; ?>');
                                                        form.append('rider','<?php echo $userNo; ?>');
                                                        form.append('fare','<?php echo $fare; ?>');
                                                        $.ajax({
                                                            data:form,
                                                            type:'post',
                                                            url:'transaction.php',
                                                            processData:false,
                                                            contentType:false,
                                                            cache:false,
                                                        }).done((data)=>{
                                                            window.location.href='index.php'; 
                                                            console.log(data)
                                                        });
                                                    }
                                                    else{
                                                        $('#upload-alert<?php echo $result0['id']; ?>').html('<div class="alert alert-danger text-left">\
                                                              <strong>Warning:</strong> No image uploaded.\
                                                            </div>');
                                                    }
                                                });
                                            </script>
                                    </div>
                                  </div>
                                </div>
                            <?php
                                }
                            ?>
                        </div>
                    </div>
                </div>
              </div>
              <!--<div class="card-footer"></div>-->
          </div>
        </div> 
        <!--<div class="col-sm-4 order"  style="color:#0784b5">-->
        <!--    <div class="card">-->
        <!--        <div class="card-body text-center">-->
        <!--            <div class="row">   -->
        <!--                <div class="col-sm-12">-->
        <!--                    <div class="form-group">-->
        <!--                        <span class="btn" data-toggle="modal" data-target="#track-order">-->
        <!--                            <p id="track"><span class='fas fa-map-marked-alt track-icon'></span> Track <br><i style="font-size: 18px;font-weight:normal;margin-left: 10px">Track your order</i>-->
        <!--                            </p>-->
        <!--                        </span>  -->
                                <!-- The Modal -->
        <!--                        <div class="modal" id="track-order" style='z-index:999999'>-->
        <!--                          <div class="modal-dialog">-->
        <!--                            <div class="modal-content">-->
                                
                                      <!-- Modal Header -->
        <!--                              <div class="modal-header">-->
        <!--                                 <button type="button" class="close" data-dismiss="modal">&times;</button>-->
        <!--                                <h4 class="modal-title" style='font-weight:bold; color:#192428'>-->
        <!--                                    <img src='../assets/image/eMove.png' style='height:40px; border-radius:50%;' />-->
        <!--                                    Express Wheel | Track your order-->
        <!--                                </h4>-->
        <!--                              </div>-->
                                
                                      <!-- Modal body -->
        <!--                              <div class="modal-body" style="text-align:Left">-->
        <!--                                <div class="row">-->
        <!--                                    <div class="col-sm-12">-->
        <!--                                        <p>Search Order Receipt Number</p>-->
        <!--                                        <input class="form-control" id="order-number">-->
        <!--                                    </div>-->
        <!--                                </div>-->
        <!--                                <br>-->
        <!--                                <div class="row">-->
        <!--                                    <div class="col-sm-12">-->
        <!--                                        <p>History</p>-->
        <!--                                        <span id="span-history" class='alert alert-default'>-->
                                                    <?php
                                                        // $query = "select count(order_id) as order_ids, order_id from tbl_user_track_history where status = '1' ";
                                                        // $result = mysqli_query($conn, $query);
                                                        // if(mysqli_num_rows($result) > 0){
                                                        //     while($row = mysqli_fetch_assoc($result)){
                                                        //         if($row['order_ids'] >= 1){
                                                        //             echo "<strong id='order-id'>$row[order_id]</strong><br>";
                                                        //         }
                                                        //     }    
                                                        // }
                                                    ?>
        <!--                                        </span>-->
        <!--                                    </div>-->
        <!--                                </div>-->
        <!--                                    <br>-->
        <!--                                    <span id="track-response-message"></span>-->
        <!--                              </div>-->
                                
                                      <!-- Modal footer -->
        <!--                              <div class="modal-footer">-->
        <!--                                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>-->
        <!--                                <button type="submit" class="btn btn-danger" id="submit-track-btn" >Submit</button>-->
        <!--                              </div>-->
                                
        <!--                            </div>-->
        <!--                          </div>-->
        <!--                        </div>-->
                                
                                <!-- The Modal -->
        <!--                        <div class="modal" id="track-order-0" style='z-index:999999'>-->
        <!--                          <div class="modal-dialog">-->
        <!--                            <div class="modal-content">-->
                                
                                      <!-- Modal Header -->
        <!--                              <div class="modal-header">-->
        <!--                                 <button type="button" class="close" data-dismiss="modal">&times;</button>-->
        <!--                                <h4 class="modal-title" style='font-weight:bold; color:#192428'>-->
        <!--                                    <img src='../assets/image/agri-logo.png' style='height:40px; border-radius:50%;' />-->
        <!--                                    Express Wheel | Track your order-->
        <!--                                </h4>-->
        <!--                              </div>-->
                                
                                      <!-- Modal body -->
        <!--                              <div class="modal-body" style="text-align:Left">-->
        <!--                                <div class="row">-->
        <!--                                    <div class="col-sm-12">-->
        <!--                                        <strong>Progress:</strong>-->
        <!--                                        <div class="col-sm-12">-->
        <!--                                            <span id="progress"></span>-->
        <!--                                        </div>-->
        <!--                                </div>-->
        <!--                              </div>-->
                                
                                      <!-- Modal footer -->
        <!--                              <div class="modal-footer">-->
        <!--                                <button type="button" class="btn btn-default" data-dismiss="modal" onclick="$('#track-order').modal('toggle');">Close</button>-->
                                        <!--<button type="submit" class="btn btn-danger" id="submit-track-btn" >Submit</button>-->
        <!--                              </div>-->
                                
        <!--                            </div>-->
        <!--                          </div>-->
        <!--                        </div>-->
        <!--                    </div>-->
        <!--                </div>-->
        <!--            </div>-->
        <!--            </div>-->
        <!--        </div>-->
        <!--    </div>  -->
        <!--</div>-->
    </div> 
</div>

<footer class="container-fluid text-center mobile-view" style='background-color:#0784b5;'>
    <a href="#myPage" title="To Top" class="toTop">
        <span class="glyphicon glyphicon-chevron-up"></span>
    </a>
    <div class="row home-mobile-view" style="display: none">
       <a href="index.php" style="color:#000; margin:0 5%; font-size: 25px"><span class="fa fa-home fa-fw nav-btn"></span></a>
       <a href="my-trasaction.php" style="color:#000; margin:0 5%; font-size: 25px"><span class="fas fa-clipboard-check fa-fw nav-btn"></span><sup class="badge" style="font-size:8px;position:absolute;margin:20px 0 0 0;left:1.53in">99+</sup></a>
        <a href="my--notification.php" style="color:#000; margin:0 5%; font-size: 25px"><span class="fas fa-bell fa-fw nav-btn"></span><sup class="badge" style="font-size:8px;position:absolute;margin:20px 0 0 0;right:1.85in">99+</sup></a>
        <a href="my-account.php" style="color:#000; margin:0 5%; font-size: 25px"><span class="fa fa-user fa-fw nav-btn"></span></a>
       <a href="#logout-modal" data-toggle="modal" style="color:#000; margin:0 5%; font-size: 25px"><span class="fa fa-sign-out-alt fa-fw nav-btn"></span></a>
    </div>
    <script>
       setInterval(()=>{
           if(screen.width <= 480){
               $('.mobile-view').removeClass('container-fluid').addClass('container').css({'padding':'10px 20px','bottom':'0','position':'fixed','width':'100%'});
               $('.home-mobile-view').css('display','block')
               $('.toTop').css('display','none')
               $('div#order').css('margin-bottom', '65px')
           $('.navbar-toggle').css('display','none');
           } 
           else{
               $('.mobile-view').addClass('container-fluid').removeClass('container');
               $('.home-mobile-view').css('display','none')
               $('.toTop').css('display','block')
        //    $('.navbar-toggle').css('display','block');
           }
       },100)
    </script>
</footer>
<!--Logout Modal-->
<div id="logout-modal" class="modal fade" role="dialog" style='z-index:999999;color:#0784b5;'>
    <div class="modal-dialog  modal-md"  >  
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title text-center" style='font-weight:bold; color:#192428'>
                    <img src='../assets/image/eMove.png' style='height:40px; border-radius:50%;' />
                    Express Wheel | Sign out
                </h4>
            </div>
            <div class="modal-body">  
                <div class='row'> 
                    <div class='col-sm-12'> 
                         Do you really want to continue?   
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <a type="button" class="btn btn-default btn-block" data-dismiss="modal">Cancel</a>
                <a type="button" class="btn btn-success btn-block" href="logout.php" >Sign out</a>
            </div>
        </div>
    </div>
</div>  

<!--Auto Cancelled booking Modal-->
<div id="hasAutoCancel" class="modal fade" role="dialog" style='z-index:999999;color:#0784b5;' data-backdrop='false' data-keyboard='false'>
    <div class="modal-dialog  modal-md">  
        <div class="modal-content">
            <div class="modal-header">
                <!--<button type="button" class="close" data-dismiss="modal">&times;</button>-->
                <h4 class="modal-title" style='font-weight:bold; color:#192428'>
                    <img src='../assets/image/eMove.png' style='height:40px; border-radius:50%;' />
                    Express Wheel | Cancelled Booking
                </h4>
            </div>
            <div class="modal-body">  
                <div class='row'> 
                    <div class='col-sm-12 text-center' style="height:70vh"> 
                        <br>
                        <h1 style="color:#0784b5;font-weight:bold">We are sorry! </h1>
                        <br>
                        <br>
                        <h3 style="color:#0784b5;">Your Passenger has cancelled the booking...</h3>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <a type="button" class="btn btn-danger btn-block" onclick="window.location.href=window.location.href" data-dismiss="modal">OK</a>
            </div>
        </div>
    </div>
</div> 

<script>
    
    // Track Order
    $("#submit-track-btn").on("click", function (){
        form = new FormData()
        form.append('order-number', $('#order-number').val())
        form.append('user-number', "<?php echo $userNo; ?>")
        $.ajax({
            url: 'user-track-order.php',
            data: form,
            method: 'POST',
            cache: false,
            contentType: false,
            processData: false,
        }).done( function(data){
            if(data == 0){
                $('#track-response-message').html('<div class="alert alert-danger">\
                                                        <strong>Error: </strong> Invalid Order number! Please try again.\
                                                        <a class="close" data-dismiss="alert">&times</a>\
                                                    </div>');
            }
            else{
                // Display successfull results
                $('#progress').html('');
                $('#progress').append(data)     
                $("#track-order").modal('toggle'); // closes the first modal
                $("#track-order-0").modal('toggle'); // opens the second modal 
                $.ajax({
                    url: 'history.php',
                    data: form,
                    method: 'POST',
                    cache: false,
                    contentType: false,
                    processData: false,
                })
            }
        })
    })
</script>

<script>
    $("#order-id").css("cursor","pointer");

    //  Sender's Address
    $(document).ready( function(){
        // loads the municipals that belongs under the selected province
        ajax = $.ajax({
            url: 'load-municipal.php',
            method: "POST",
            data: "province="+$("#select-province-0").val(),
            cache:false,
        })
        $.when(ajax).done( function(ajax){
            $('#select-citymun-0').html(ajax);
            
            // loads the barangays that belongs under the selected municipal
            $.ajax({
                url: 'load-barangay.php',
                method: "POST",
                data: "city="+$("#select-citymun-0").val(),
                cache:false,
            }).done( function(data){
                $('#select-barangay-0').html(data);
            })
        })
    })
    //  Recipient's Address
    $(document).ready( function(){
        // loads the municipals that belongs under the selected province
        ajax = $.ajax({
            url: 'load-municipal.php',
            method: "POST",
            data: "province="+$("#select-province-1").val(),
            cache:false,
        })
        $.when(ajax).done( function(data){
            $('#select-citymun-1').html(data);
            
            // loads the barangays that belongs under the selected municipal
            $.ajax({
                url: 'load-barangay.php',
                method: "POST",
                data: "city="+$("#select-citymun-1").val(),
                cache:false,
            }).done( function(data){
                $('#select-barangay-1').html(data);
            })
        })
    })
</script>
<script>
    let id;
    let target;
    let options;
    
    function success(pos) {
        const lat = pos.coords.latitude;
        const lng = pos.coords.longitude;
        const accuracy = pos.coords.accuracy;
        
        setInterval( updateMyLocation(lat, lng), 2000);
    }
    
    function error(err) {
        if (err.code === 1) {
            alert("Please allow geolocation access");
        } else {
            alert("Cannot get current location");
        }
    }
    
    navigator.geolocation.watchPosition(success, error);

    function updateMyLocation(lat, lng){
        $.ajax({
            data:{
                    'latitude' : lat,
                    'longitude' : lng,
                    'id' : <?php echo $userNo; ?>
                },
            method: 'post',
            url: 'update-my-location.php',
            cache: false,
        });
    }
</script>
                                                      
</body>
</html>