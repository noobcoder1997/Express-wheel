<?php
    // successful transaction 
    include '../components/comp-conn.php';

    $book_id = $_POST['book_id'];
    $from = $_POST['from'];
    $to = $_POST['to'];
    $date = date('y-m-d').' '.date('h:i:s');

    if(isset($_POST['passenger_id'])){

        $passenger_id = $_POST['passenger_id'];
        $query0 = mysqli_query($conn, "select * from tbl_book_ride where id='$_POST[book_id]' ");

        if(mysqli_num_rows($query0) > 0){

            $row0 = mysqli_fetch_assoc($query0);
            mysqli_query($conn, "insert into tbl_transactions (book_id,passenger_id,_from,_to,fare,rider_id,status,date) values ('$book_id','$passenger_id','$from','$to','$row0[fare]','$row0[rider_id]','1','$date') ");
            
            $message = "Hi! Your ride from $from to $to has been successfully concluded. Thank you for Express wheeling with us!";
            $title = "You have Arrived!";
            mysqli_query($conn, "insert into tbl_notifications (user_id,message,title) values ('$passenger_id','$message','$title') ");
        }
    }
    else if(isset($_POST['sender_id'])){

        $passenger_id = $_POST['sender_id'];
        $rider = $_POST['rider'];
        $fare = $_POST['fare'];
        mysqli_query($conn, "insert into tbl_transactions (book_id,passenger_id,_from,_to,fare,rider_id,status,date) values ('$book_id','$passenger_id','$from','$to','$fare','$rider','1','$date') ");
               
        $message = "Hi! Your order for delivery from $from to $to has been successfully concluded. Thank you Express wheeling with us!";
        $title = "Order Delivered!";
        mysqli_query($conn, "insert into tbl_notifications (user_id,message, title) values ('$passenger_id','$message','$title' ) ");
    }

    

?>