<?php 
    include '../components/comp-conn.php';
    
    $datas0=array('');
    $datas1=array('');
    $ids0=array('');
    $ids1=array('');
    $i=0;
    $j=0;
    
    $query = mysqli_query($conn, "select * from tbl_user_make_order where status ='0' and rider_id = '' and rider_status = '0' and delivery_type = 'Same day' ");
    while($row=mysqli_fetch_assoc($query)){
        $ids0[$i]=$row['id'];
        $i++;
    }
    
    $query = mysqli_query($conn, "select * from tbl_user_make_order where status ='0' and rider_id = '' and rider_status = '0' and delivery_type = 'Scheduled' ");
    while($row=mysqli_fetch_assoc($query)){
        $ids1[$j]=$row['id'];
        $j++;
    }
    
    $query0 = mysqli_query($conn, "select * from tbl_user_make_order where status ='0' and rider_id = '' and rider_status = '0' and delivery_type = 'Same day'");
    while($row=mysqli_fetch_assoc($query0)){
        $datas0[$row['id']] = [
                                'name'      =>  $row['sender_name'], 
                                'contact'   =>  $row['sender_contact'],
                                'item'      =>  $row['item_name'], 
                                'fee'       =>  $row['fee']    
                            ];
        // $i++;
    }
    
    $query1 = mysqli_query($conn, "select * from tbl_user_make_order where status ='0' and rider_id = '' and rider_status = '0' and delivery_type = 'Scheduled'");
    while($row=mysqli_fetch_assoc($query1)){
        $datas1[$row['id']] = [
                                'name'      =>  $row['sender_name'], 
                                'contact'   =>  $row['sender_contact'],
                                'item'      =>  $row['item_name'], 
                                'fee'       =>  $row['fee']    
                            ];
        // $i++;
    }
    
    echo json_encode([$ids0,$ids1,$datas0,$datas1,$i,$j]);
?>