<?php

    session_start();
    unset($_SESSION['admin_status']);
    session_destroy();
    header('location: ../');
?>