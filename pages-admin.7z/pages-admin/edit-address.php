<?php
    include('../components/comp-conn.php');
    
    $province = $_POST['province'];
    $city = $_POST["city"];
    $brgy = $_POST["brgy"];
    $purok = $_POST['purok'];
    $zipcode = $_POST['zipcode'];
    $landmark = $_POST['landmark'];
    $id = $_POST['id'];
    $message;
    
    if ( !$province || !$city || !$brgy || ( strlen($zipcode) != 4 || !is_numeric($zipcode) ) ) {
      $message = "<div class='alert alert-warning'>
                    <strong>Error Home Address:</strong> You entered invalid home address!
                 </div>";
    }
    else{
        $query = "update tbl_user set barangay = '$brgy', municipal = '$city', purok = '$purok', zipcode = '$zipcode', landmark = '$landmark' where no = '$id'";
        mysqli_query($conn, $query); 
        $message = "<div class='alert alert-success'>
                    <strong>Success:</strong> You have updated your home address!
                 </div>";
    }
    echo $message;
?>