    <?php
        include('../components/comp-conn.php');
        
        $datas=[''];
        $d=0;
        $ids=[''];
        $query0 = mysqli_query($conn, "select * from tbl_book_ride where status = 0");
        if(mysqli_num_rows($query0) > 0){
            while($result0 = mysqli_fetch_assoc($query0)){
                $query = mysqli_query($conn, "select * from tbl_user where no = '$result0[passenger_id]' ");
                $result = mysqli_fetch_assoc($query);
                
                $query1 = mysqli_query($conn, "select * from refbrgy where id = '$result0[_from]' ");
                $result1 = mysqli_fetch_assoc($query1);
                
                $query2 = mysqli_query($conn, "select * from refbrgy where id = '$result0[_to]' ");
                $result2 = mysqli_fetch_assoc($query2);
                
                $datas[$result0['id']]=[
                            'passenger'=> $result['fn']." ".$result['ln'],
                            'from'=> $result1['brgyDesc'],
                            'to'=> $result2['brgyDesc'],
                            'fare'=> $result0['fare']
                        ];
                $ids[$d]=$result0['id'];
                $d++;
            }
        }
        echo json_encode([$datas,$d,$ids]);
    ?>
                              