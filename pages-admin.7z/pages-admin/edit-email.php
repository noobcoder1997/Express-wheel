<?php
    include('../components/comp-conn.php');
    
    $email = $_POST["email"];
    $id = $_POST['id'];
    $message;
    
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
      $message = "<div class='alert alert-warning'>
                        <strong>Error Email Address:</strong> You entered invalid email address!
                     </div>";
    }
    else{
        $query = "update tbl_user set email = '$email' where no = '$id'";
        mysqli_query($conn, $query);  
        $message = "<div class='alert alert-success'>
                        <strong>Success:</strong> You have updated your email address!
                    </div>";          
    }
    echo $message;
?>