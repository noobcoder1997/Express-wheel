<?php
    include '../components/comp-conn.php';
    
    if(!empty($_FILES['img']['tmp_name'])){
        
        $fileinfofront=PATHINFO($_FILES["img"]["name"]);
        
		$newFilenamefront=$fileinfofront['filename'] ."." . $fileinfofront['extension'];
		
		move_uploaded_file($_FILES["img"]["tmp_name"],"../assets/proof_delivery/" . $newFilenamefront);
		
		$front_img="assets/proof_delivery/" . $newFilenamefront;
		
		mysqli_query($conn, "update tbl_user_make_order set proof_img = '$front_img' where id = '$_POST[id]' ");
		
        echo   '<div class="alert alert-success text-left">
                  <strong>Success:</strong> Successfully uploaded.
                </div>';
    }
    else {
        echo '<div class="alert alert-danger text-left">
                  <strong>Warning:</strong> No image uploaded.
                </div>';
    }
?>