<?php
    // session start();
    include "../components/comp-conn.php";
    
    $order_number = htmlentities($_POST['order-number']);
    // $user_number = htmlentities($_POST['user-number']);
    
    $stmt=$conn->prepare("SELECT * FROM tbl_user_track_history WHERE order_id = ? order by date desc");
    $stmt->bind_param("s", $order_number);
    $stmt->execute();
    $result=$stmt->get_result();
    if(mysqli_num_rows($result) > 0){
        while($row = $result->fetch_assoc()){
            echo "<p><i class='fas fa-circle fa-fw' style='font-size:9px'></i> $row[note]</p><small>&emsp;$row[date] $row[time]</small>";
        }
    }
    else{
        echo 0; //Invalid Order number
    }

?>