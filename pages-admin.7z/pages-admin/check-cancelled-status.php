<?php

    include '../components/comp-conn.php';

    $id = $_POST['id'];
    $rider_id = $_POST['rider_id'];

    $query = mysqli_query($conn, "select * from tbl_book_ride where rider_status = 3 and cancel_code = 0 and id='$id' and rider_id='$rider_id' ");

    if(mysqli_num_rows($query) > 0){

        mysqli_query($conn, "update tbl_book_ride set status = 3 where id='$id' and rider_id='$rider_id' ");
        echo 1;
    }else{
        echo 0;
    }
?>