<?php
    include('../components/comp-conn.php');
    
    $contact = $_POST["contact"];
    $id = $_POST['id'];
    $message;
    
    if (strlen($contact) != 11 || $contact[0] != '0' || is_numeric($contact) == false || preg_match('/\s/',$contact) ) {
      $message = "<div class='alert alert-warning'>
                        <strong>Error Contact Number:</strong> You entered invalid contact number!
                     </div>";
    }
    else{
        $query = "update tbl_user set contact = '$contact' where no = '$id'";
        mysqli_query($conn, $query); 
        $message = "<div class='alert alert-success'>
                        <strong>Success:</strong> You have updated your contact number!
                    </div>";       
    }
    echo $message;
?>