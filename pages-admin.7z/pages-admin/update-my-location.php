<?php
    include'../components/comp-conn.php';
    session_start();
    
    echo$lat=$_POST['latitude'];
    echo$lng=$_POST['longitude'];
    echo$id=$_POST['id'];
    
    mysqli_query($conn, "UPDATE tbl_user SET lat = '$lat', lng = '$lng' WHERE no = '$id' ");
?>