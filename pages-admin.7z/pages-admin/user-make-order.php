<?php
    include "../components/comp-conn.php";
    session_start();
    
    $sender_name = htmlentities($_POST['sender-name']);
    $sender_contact = htmlentities($_POST['sender-contact']);
    $sender_address = htmlentities($_POST['sender-address']);
    
    $recipient_name = htmlentities($_POST['recipient-name']);
    $recipient_contact = htmlentities($_POST['recipient-contact']);
    $recipient_address = htmlentities($_POST['recipient-address']);
    
    $item_name = htmlentities($_POST['item-name']);
    $item_weight = htmlentities($_POST['item-weight']);
    $item_quantity = htmlentities($_POST['item-quantity']);
    
    $item_value = htmlentities($_POST['item-value']);
    $item_length = htmlentities($_POST['item-length']);
    $item_width = htmlentities($_POST['item-width']);
    
    $item_height = htmlentities($_POST['item-height']);
    $item_service_type = htmlentities($_POST['item-service-type']);
    $item_package_type = htmlentities($_POST['item-package-type']); // selected option text in select tag
    
    $item_delivery_type = htmlentities($_POST['item-delivery-type']); // selected option text in select tag
    $item_scheduled = htmlentities($_POST['item-scheduled']);   // date for schedule
    $item_fee = htmlentities($_POST['item-fee']);
    
    $item_remarks = htmlentities($_POST['item-remarks']);
    // $branch_id = html_entity_decode($_POST['branch-id']);
    // $admin_id = html_entity_decode($_POST['admin-id']);
    
    $message = "";
    
    if(strlen($recipient_contact) != 11){
        $message = "<div class='alert alert-warning'>";
        $message .= "<strong>Warning:</strong> Invalid Contact Number! Please try again.";
        $message .= "<a class='close' data-dismiss='alert'>&times</a>";
        $message .= "</div>";
    }
    
    else if($sender_name == null || $sender_contact == null || $sender_address == null ||
            $recipient_name == null  || $recipient_contact == null || $recipient_address == null || 
            $item_name == null || $item_weight == null || $item_quantity == null || $item_value == null ||
            $item_length == null|| $item_width == null || $item_height == null || $item_service_type == null ||
            $item_package_type == null|| $item_delivery_type == null|| $item_scheduled == null || $item_fee == null ||
            $item_remarks == null){
                
        $message = "<div class='alert alert-warning'>";
        $message .= "<strong>Warning:</strong> Fields should not leave empty! Please try again.";
        $message .= "<h1 style='font-weight:bolder' id='text-to-copy'>".$number."</h1>";
        $message .= "<a class='btn'><span class='fa fa-copy' onclick='copy()'></span> copy</a>";
        $message .= "</div>";
    }
    else{
        $number = rand(1000000,2000000);
        
        $stmt = $conn->prepare("INSERT INTO tbl_user_make_order (order_number, sender_name, sender_contact, sender_address, recipient_name, recipient_contact, recipient_address, item_name, item_quantity, 	item_weight, item_value, item_length, item_width, item_height, service_type, package_type, delivery_type, item_scheduled, fee, remarks, branch_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?) ");
        $stmt->bind_param("sssssssssssssssssssss",$number, $sender_name,$sender_contact,$sender_address,$recipient_name,$recipient_contact,$recipient_address,$item_name,$item_quantity,$item_weight,$item_value,$item_length,$item_width,$item_height,$item_service_type,$item_package_type,$item_delivery_type,$item_scheduled,$item_fee,$item_remarks,$branch_id);
        $stmt->execute();
        // $last_id=mysqli_insert_id($conn);
        
        $stmt=$conn->prepare("SELECT branch_name FROM tbl_branch WHERE id = ?");
        $stmt->bind_param("s",$branch_id);
        $stmt->execute();
        $result=$stmt->get_result();
        if(mysqli_num_rows($result) > 0){
            if($row=$result->fetch_assoc()){
                $date = date("Y-m-d");
                $time = date("h:i:s");
                $note = "Your Package has been received by $row[branch_name]";
                $query = "INSERT INTO tbl_user_track_history (order_id, note, date, time) VALUES (?, ?, ?, ?)";
                $stmt = $conn->prepare($query);
                $stmt->bind_param("ssss",$number,$note,$date,$time);
                $stmt->execute();
            }
        }
    
        
        $message = "<div class='alert alert-success'>";
        $message .= "<strong>Order Successful:</strong> You have created an order! <br> Your Order Number:";
        $message .= "<h1 style='font-weight:bolder' id='text-to-copy'>".$number."</h1>";
        $message .= "<a class='btn'><span class='fa fa-copy' onclick='copy()'></span> copy</a>";
        $message .= "</div>";  
    }

    
    echo $message;
  
?>

