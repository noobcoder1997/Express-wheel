<?php
    include('../components/comp-conn.php');
    
    $id = $_POST['id'];
    $rider = $_POST['rider-id'];
    $from = $_POST['from'];
    $to = $_POST['to'];
    $date = date('y-m-d').' '.date('h:i:s');
    
    mysqli_query($conn, "update tbl_book_ride set status='3', rider_id='$rider', rider_status='3', cancel_code = '1' where id = '$id' ");
    
    if(isset($_POST['passenger_id'])){
        $passenger_id = $_POST['passenger_id'];
        $query0 = mysqli_query($conn, "select * from tbl_book_ride where id='$id' ");
        if(mysqli_num_rows($query0) > 0){
            $row0 = mysqli_fetch_assoc($query0);
            mysqli_query($conn, "insert into tbl_transactions (book_id,passenger_id,_from,_to,fare,rider_id,date) values ('$id','$passenger_id','$from','$to','$row0[fare]','$rider','$date') ");
        }
    }
    else if(isset($_POST['sender_id'])){
        $passenger_id = $_POST['sender_id'];
        $fare = $_POST['fare'];
        mysqli_query($conn, "insert into tbl_transactions (book_id,passenger_id,_from,_to,fare,rider_id,date) values ('$id','$passenger_id','$from','$to','$fare','$rider','$date') ");
    }

    '<div class="alert alert-success">
            <strong>Success: </strong> Booking Canceled!
            <a class="close" data-dismiss="alert">&times</a>
        </div>';
?>