<?php
//  session_start();
    include( '../components/comp-conn.php');

    $provice_code = htmlentities($_POST['province']);
    
    $query = "select * from refcitymun where provCode = '$provice_code'";
    $province = mysqli_query($conn, $query);
    
    while($row = mysqli_fetch_assoc($province)){
        echo "<option value='$row[citymunCode]'>$row[citymunDesc]</option>";
    }
?>