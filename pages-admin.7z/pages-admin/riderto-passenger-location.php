<?php
    include('../components/comp-conn.php');
    
    $rider = $_POST['rider-id'];
    $id = $_POST['id'];
    
    mysqli_query($conn, "update tbl_book_ride set status='1', rider_status='1' where id = '$id' ");
    
    echo '<div class="alert alert-success">
            <strong>Success: </strong> Booking Accepted!
            <a class="close" data-dismiss="alert">&times</a>
        </div>';
?>