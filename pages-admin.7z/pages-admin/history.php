<?php
    include "../components/comp-conn.php";
    session_start();
    
    echo $order = $_POST['order-number'];
    $user = $_POST['user-number'];
    $date = date("Y-m-d");
    $status = 1;
    
    $query = "update tbl_user_track_history set status = '$status' where order_id = '$order' " ;
    // mysqli_query($conn, $query);

    // if(mysqli_num_rows($result) > 0){
    //     if($row = mysqli_fetch_assoc($result)){
    //         echo "<p>$row[order_id]</p></br>";
    //     }      
    // }
?>