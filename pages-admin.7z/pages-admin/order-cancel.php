<?php
    include('../components/comp-conn.php');
    
    mysqli_query($conn, "update tbl_user_make_order set status = 3, rider_status = 3 where id = '$_POST[id]' ");

    echo 'You have cancelled the booking...';
?>