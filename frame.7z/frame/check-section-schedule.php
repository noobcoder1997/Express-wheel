<?php 
    include '../components/comp-conn.php';  
    
    $subOffNo = $_GET['subOffNo'];
    $sectNo= $_GET['sectNo']; 
    $strt  = $_GET['strt']; 
    $end   = $_GET['end']; 
    $strt  = $_GET['strt']; 
    $end   = $_GET['end']; 
    $mon   = $_GET['mon']; 
    $tue   = $_GET['tue']; 
    $wed   = $_GET['wed']; 
    $thu   = $_GET['thu']; 
    $fri   = $_GET['fri']; 
    $sat   = $_GET['sat']; 
    
    $qry0   = mysqli_query($conn,"SELECT * FROM tblSubjectOffer WHERE fldNo='$subOffNo' ")or die(mysqli_error($conn));
    $rw0    = mysqli_fetch_assoc($qry0);
    $subNo  = $rw0['fldSubNo'];
    
    $qry   = mysqli_query($conn,"SELECT * FROM tblSubject WHERE fldNo='$subOffNo' ")or die(mysqli_error($conn));
    $rw    = mysqli_fetch_assoc($qry);
    $subHr0 = $rw['fldHr'];
    $subHr = $rw['fldHr']*60;
    $mins  = 0;
    
    $strt = date('H',strtotime($strt))*60 + date('i',strtotime($strt));
    $end  = date('H',strtotime($end))*60 + date('i',strtotime($end));
    
    if($mon==1){ $mins += $end - $strt; } 
    if($tue==1){ $mins += $end - $strt; } 
    if($wed==1){ $mins += $end - $strt; } 
    if($thu==1){ $mins += $end - $strt; } 
    if($fri==1){ $mins += $end - $strt; } 
    if($sat==1){ $mins += $end - $strt; } 
    $withNote = false;
    $notes = "<ul style='color:red; font-weight:bold;'>"; 
    if(($mon + $tue + $wed + $thu + $fri + $sat)==0){ 
        $notes .= "<li>Please specify the day of class schedule.</li>";
        $withNote = true;
    }   
    if($subHr > $mins){
        $notes .= "<li>Insuficient class hours as required hours by the subject ($subHr0 hrs).</li>";
        $withNote = true;
    }else if($subHr<$mins){
        $notes .= "<li>Class hours is more than the required hours by the subject ($subHr0 hrs).</li>";
        $withNote = true;
    }       
    $flds = ['fldMon', 'fldTue', 'fldWed', 'fldThu', 'fldFri', 'fldSat'];
    $DAY  = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
    $days = [$mon, $tue, $wed, $thu, $fri, $sat ];
    $conflicts = "";
    $conflict = 0;
    if($end > $strt){
        for($f=0;$f<count($flds);$f++){
            if($days[$f]==1){ 
                $fldDay = $flds[$f];
                $qry = mysqli_query($conn,"SELECT * FROM tblSubjectOffer WHERE fldSectNo='$sectNo' AND  $fldDay='1'  ")or die(mysqli_error($conn)); 
                while($rw = mysqli_fetch_assoc($qry)){
                    $subOffNo = $rw['fldSubNo'];
                    
                    $qry1   = mysqli_query($conn,"SELECT * FROM tblSubject WHERE fldNo='$subOffNo' ")or die(mysqli_error($conn));
                    $rw1    = mysqli_fetch_assoc($qry1);
                    
                    $strt0 = $rw['fldStart'];
                    $end0  = $rw['fldEnd'];  
                    $strt1 = date('H',strtotime($strt0))*60 + date('i',strtotime($strt0));
                    $end1  = date('H',strtotime($end0))*60 + date('i',strtotime($end0));
                    if($strt>=$strt1 && $strt<$end1){ 
                      $notes .= "<li>Schedule is conflict: ".$DAY[$f]." ".date('h:i',strtotime($strt0))."-".date('h:i',strtotime($end0))."</li>";
                      $withNote = true;
                      $conflict++;
                    } 
                    if($end>$strt1 && $end < $end1 ){ 
                      $notes .= "<li>Schedule is conflict: ".$DAY[$f]." ".date('h:i',strtotime($strt0))."-".date('h:i',strtotime($end0))." </li>";
                      $withNote = true;
                      $conflict++;
                    }  
                }
            }
        }  
    }else{ 
        $notes.= "<li style='color:red;font-weight:bold;'>Time schedule is invalid.  </li>";
        $withNote = true;
    }
    $notes .="</ul>";
    if( $withNote){
    echo "<br /><div class='panel panel-danger'><div class='panel-body'>".$notes."</div></div>";
    }
?> 
 