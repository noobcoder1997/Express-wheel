<?php 
    include '../components/comp-conn.php';  
    $deptNo = $_POST['deptNo'];
    
    $condition = "WHERE fldDeptNo='$deptNo' ";
    if($_POST['srch']!=''){
        $srch       = $_POST['srch'];
        $condition  .= "AND fldName LIKE '%$srch%'";
    }
    
    if($_POST['dptNo']!=0){
        $dptNo      = $_POST['dptNo'];
        $condition .= " AND fldDeptNo='$dptNo'";
    }
    if($_POST['emp']!=''){
        $emp        = $_POST['emp'];
        $condition .= " AND fldEmpStatus='$emp'";
    } 
    $qry0 = mysqli_query($conn,"SELECT * FROM tblFaculty $condition ORDER BY fldDeptNo, fldName ")or die(mysqli_error($conn));
?>

<br /> 
<div class='col-sm-12'  > 
     
</div> 

<script>
function editForm(fcNo){ 
        showModal("Faculty Information","", 1, 600);
        $("#modalContent").load("../form/form-faculty-edit.php?fcNo="+fcNo); 
}  
function deleteForm(fcNo){ 
        showModal("Faculty Information","", 1, 600);
        $("#modalContent").load("../form/form-faculty-remove.php?fcNo="+fcNo); 
}    
</script>



