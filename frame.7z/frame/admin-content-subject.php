<?php 
    include '../components/comp-conn.php';  
    
    $prNo   = $_POST['prNo']; 
    $rev    = $_POST['rv']; 
    $srch   = $_POST['srch'];
    
    $condition = "WHERE fldRev='$rev' AND fldPrgNo='$prNo' ";
    
    if($srch!=''){
        $condition .= " AND (fldCode LIKE '%$srch%' || fldDesc LIKE '%$srch%' ) ";
    } 
    $yearLevel = ['First Year', 'Second Year', 'Third Year', 'Fourth Year'];
    $semester = ['First Semester', 'Second Semester', 'Summer 1', 'Summer 2'];
    $qry1  = mysqli_query($conn,"SELECT * FROM tblProgram  WHERE  fldNo='$prNo'   ")or die(mysqli_error($conn));
    $rw1 = mysqli_fetch_assoc($qry1);
?>

<br /> 
<div class='col-sm-12'  >
    <center> 
        <strong style='text-transform:uppercase; color:steelblue; font-size:24px;'><?php echo $rw1['fldName'];?></strong>
        <br />
        <strong style='text-transform:uppercase; color:steelblue; font-size:20px;'><?php echo $rw1['fldMajor'] ;?></strong>
        <br />
        <span style='text-transform:uppercase; color:red; font-size:18px;'>Revision Year: <?php echo $rev ;?></span>
        <br />
    </center>

</div> 
<?php for($yrLvl=0;$yrLvl<count($yearLevel);$yrLvl++){
    
?> 
<?php  
    $qry0 = mysqli_query($conn,"SELECT * FROM tblSubject $condition AND fldYrLvl='$yrLvl' AND fldSem='0' ")or die(mysqli_error($conn));
    if(mysqli_num_rows($qry0)>0){ 
?>
<div class='col-sm-12'  >
    <center>  
        <strong style='text-transform:uppercase; color:steelblue; font-size:15px;'><?php echo $yearLevel[$yrLvl];?></strong>
        <br />
        <br />
    </center>
</div> 
<div class='col-sm-12'  > 
    <center> 
        <strong>FIRST SEMESTER</strong>
        <table class='table-list' border=0>
            <tr>
                <td></td>
                <td>Options</td> 
                <td>Code Name</td>
                <td>Subject Title</td>   
                <td style='text-align:center'> Units</td>  
                <td style='text-align:center'>Credited Units</td> 
                <td style='text-align:center'>Hrs per week</td> 
            </tr>
            <?php 
                $no  = 1;
                while($rw0 = mysqli_fetch_assoc($qry0)){
                    $subNo   = $rw0['fldNo']; 
                    $mjr     = $rw0['fldMajor']==0?"Major":"Minor";
                    echo "<tr>";
                    echo "<td>$no.</td>"; 
                    echo "<td  style='width:80px;text-align:left' >";
                    echo "<button class='btn btn-default btn-xs ' onclick='editForm($subNo)' ><i class='fa fa-edit'></i> </button>"; 
                    echo "<button class='btn btn-danger btn-xs ' onclick='deleteForm($subNo)' ><i class='fa fa-trash'></i> </button>";
                    echo "</td>";
                    echo "<td style='width:120px;text-align:left' >".$rw0['fldCode']."</td>";
                    echo "<td style='width:400px;text-align:left' >".$rw0['fldDesc']."</td>";  
                    echo "<td style='width:90px;text-align:center' >".$rw0['fldUnit']."</td>";
                    echo "<td style='width:90px;text-align:center' >".$rw0['fldCUnit']."</td>";
                    echo "<td style='width:90px;text-align:center' >".$rw0['fldHr']."</td>";
                    echo "</tr>"; 
                    $no++;
                }
            ?>
        </table>
    </center>
    <br />
    <br />
</div> 

<?php } ?>
<?php  
    $qry0 = mysqli_query($conn,"SELECT * FROM tblSubject $condition AND fldYrLvl='$yrLvl' AND fldSem='1' ")or die(mysqli_error($conn));
    if(mysqli_num_rows($qry0)>0){ 
?>
<div class='col-sm-12'  > 
    <center> 
        <strong>SECOND SEMESTER</strong>
        <table class='table-list' border=0>
            <tr>
                <td></td>
                <td>Options</td> 
                <td>Code Name</td>
                <td>Subject Title</td>    
                <td style='text-align:center'> Units</td>  
                <td style='text-align:center'>Credited Units</td> 
                <td style='text-align:center'>Hrs per week</td> 
            </tr>
            <?php
                $no  = 1;
                while($rw0 = mysqli_fetch_assoc($qry0)){
                    $subNo   = $rw0['fldNo']; 
                    $mjr     = $rw0['fldMajor']==0?"Major":"Minor";
                    echo "<tr>";
                    echo "<td>$no.</td>"; 
                    echo "<td  style='width:80px;text-align:left' >";
                    echo "<button class='btn btn-default btn-xs ' onclick='editForm($subNo)' ><i class='fa fa-edit'></i> </button>"; 
                    echo "<button class='btn btn-danger btn-xs ' onclick='deleteForm($subNo)' ><i class='fa fa-trash'></i> </button>";
                    echo "</td>";
                    echo "<td style='width:120px;text-align:left' >".$rw0['fldCode']."</td>";
                    echo "<td style='width:400px;text-align:left' >".$rw0['fldDesc']."</td>";  
                    echo "<td style='width:90px;text-align:center' >".$rw0['fldUnit']."</td>";
                    echo "<td style='width:90px;text-align:center' >".$rw0['fldCUnit']."</td>";
                    echo "<td style='width:90px;text-align:center' >".$rw0['fldHr']."</td>";
                    echo "</tr>"; 
                    $no++;
                }
            ?>
        </table>
    </center>
    <br />
    <br />
</div> 

<?php } ?>
<?php  
    $qry0 = mysqli_query($conn,"SELECT * FROM tblSubject $condition AND fldYrLvl='$yrLvl' AND fldSem='2' ")or die(mysqli_error($conn));
    if(mysqli_num_rows($qry0)>0){ 
?>
<div class='col-sm-12'  > 
    <center> 
        <strong>SUMMER 1</strong>
        <table class='table-list' border=0>
            <tr>
                <td></td>
                <td>Options</td> 
                <td>Code Name</td>
                <td>Subject Title</td>    
                <td style='text-align:center'> Units</td>  
                <td style='text-align:center'>Credited Units</td> 
                <td style='text-align:center'>Hrs per week</td> 
            </tr>
            <?php 
                $no  = 1;
                while($rw0 = mysqli_fetch_assoc($qry0)){
                    $subNo   = $rw0['fldNo']; 
                    $mjr     = $rw0['fldMajor']==0?"Major":"Minor";
                    echo "<tr>";
                    echo "<td>$no.</td>"; 
                    echo "<td  style='width:80px;text-align:left' >";
                    echo "<button class='btn btn-default btn-xs ' onclick='editForm($subNo)' ><i class='fa fa-edit'></i> </button>"; 
                    echo "<button class='btn btn-danger btn-xs ' onclick='deleteForm($subNo)' ><i class='fa fa-trash'></i> </button>";
                    echo "</td>";
                    echo "<td style='width:120px;text-align:left' >".$rw0['fldCode']."</td>";
                    echo "<td style='width:400px;text-align:left' >".$rw0['fldDesc']."</td>";  
                    echo "<td style='width:90px;text-align:center' >".$rw0['fldUnit']."</td>";
                    echo "<td style='width:90px;text-align:center' >".$rw0['fldCUnit']."</td>";
                    echo "<td style='width:90px;text-align:center' >".$rw0['fldHr']."</td>";
                    echo "</tr>"; 
                    $no++;
                }
            ?>
        </table>
    </center>
    <br />
    <br />
</div> 

<?php } ?>
<?php  
    $qry0 = mysqli_query($conn,"SELECT * FROM tblSubject $condition AND fldYrLvl='$yrLvl' AND fldSem='3' ")or die(mysqli_error($conn));
    if(mysqli_num_rows($qry0)>0){ 
?>
<div class='col-sm-12'  > 
    <center> 
        <strong>SUMMER 2</strong>
        <table class='table-list' border=0>
            <tr>
                <td></td>
                <td>Options</td> 
                <td>Code Name</td>
                <td>Subject Title</td>    
                <td style='text-align:center'> Units</td>  
                <td style='text-align:center'>Credited Units</td> 
                <td style='text-align:center'>Hrs per week</td> 
            </tr>
            <?php
                $no  = 1;
                while($rw0 = mysqli_fetch_assoc($qry0)){
                    $subNo   = $rw0['fldNo']; 
                    $mjr     = $rw0['fldMajor']==0?"Major":"Minor";
                    echo "<tr>";
                    echo "<td>$no.</td>"; 
                    echo "<td  style='width:80px;text-align:left' >";
                    echo "<button class='btn btn-default btn-xs ' onclick='editForm($subNo)' ><i class='fa fa-edit'></i> </button>"; 
                    echo "<button class='btn btn-danger btn-xs ' onclick='deleteForm($subNo)' ><i class='fa fa-trash'></i> </button>";
                    echo "</td>";
                    echo "<td style='width:120px;text-align:left' >".$rw0['fldCode']."</td>";
                    echo "<td style='width:400px;text-align:left' >".$rw0['fldDesc']."</td>";  
                    echo "<td style='width:90px;text-align:center' >".$rw0['fldUnit']."</td>";
                    echo "<td style='width:90px;text-align:center' >".$rw0['fldCUnit']."</td>";
                    echo "<td style='width:90px;text-align:center' >".$rw0['fldHr']."</td>";
                    echo "</tr>"; 
                    $no++;
                }
            ?>
        </table>
    </center>
    <br />
    <br />
</div>
<?php } ?>

<?php } ?>
<script>
function editForm(subNo){ 
        showModal("Faculty Information","", 1, 800);
        $("#modalContent").load("../form/form-subject-edit.php?subNo="+subNo); 
}  
function deleteForm(subNo){ 
        showModal("Faculty Information","", 1, 800);
        $("#modalContent").load("../form/form-subject-remove.php?subNo="+subNo); 
}    
</script>



