<?php 
    include '../components/comp-conn.php';  
    
    $condition = "";
    if($_POST['srch']!=''){
        $srch       = $_POST['srch'];
        $condition  .= "WHERE fldName LIKE '%$srch%'";
    } 
    if($_POST['dptNo']!=0){
        $dptNo      = $_POST['dptNo'];
        $condition .= $condition==""?"WHERE fldDeptNo='$dptNo'":" AND fldDeptNo='$dptNo'";
    } 
    $qry0 = mysqli_query($conn,"SELECT * FROM tblProgram $condition ORDER BY fldDeptNo, fldName ")or die(mysqli_error($conn));
?>

<br /> 
<div class='col-sm-12'  > 
    <table class='table-list' border=0>
        <tr>
            <td></td>
            <td>Program Name</td>
            <td>Major</td>  
            <td>Department</td> 
            <td>Options</td> 
        </tr>
        <?php
            $no  = 1;
            while($rw0 = mysqli_fetch_assoc($qry0)){
                $prNo   = $rw0['fldNo'];
                $deptNo = $rw0['fldDeptNo'];
                $qry1  = mysqli_query($conn,"SELECT * FROM tblDepartment WHERE fldNo='$deptNo'  ")or die(mysqli_error($conn));
                $rw1   = mysqli_fetch_assoc($qry1); 
                echo "<tr>";
                echo "<td>$no.</td>"; 
                echo "<td>".$rw0['fldName']."</td>";
                echo "<td>".$rw0['fldMajor']."</td>"; 
                echo "<td>".$rw1['fldName']." Department</td>";
                echo "<td>";
                echo "<button class='btn btn-default btn-xs ' onclick='editForm($prNo)' ><i class='fa fa-edit'></i> Edit</button>";
                echo "<button class='btn btn-danger btn-xs ' onclick='deleteForm($prNo)' ><i class='fa fa-trash'></i> Remove</button>";
                echo "</td>";
                echo "</tr>";
                $no++;
            }
        ?>
    </table>
    <br />
    <br />
</div> 

<script>
function editForm(prNo){ 
        showModal("Faculty Information","", 1, 600);
        $("#modalContent").load("../form/form-program-edit.php?prNo="+prNo); 
}  
function deleteForm(prNo){ 
        showModal("Faculty Information","", 1, 600);
        $("#modalContent").load("../form/form-program-remove.php?prNo="+prNo); 
}    
</script>



