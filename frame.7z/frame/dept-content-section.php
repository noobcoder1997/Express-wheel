<?php 
    include '../components/comp-conn.php';  
    $prgNo = $_POST['prgNo'];
    $semNo = $_POST['semNo'];
    
    $condition = "WHERE fldPrgNo='$prgNo' AND fldSemNo='$semNo' ";
    if($_POST['srch']!=''){
        $srch       = $_POST['srch'];
        $condition  .= "AND fldName LIKE '%$srch%'";
    }
     
    if($_POST['yr']!=''){
        $yr          = $_POST['yr']; 
        $condition  .= "AND fldYrLvl = '$yr' ";
    }  
    $qry0 = mysqli_query($conn,"SELECT * FROM tblSection $condition ORDER BY fldDeptNo, fldPrgNo, fldYrLvl, fldSect ")or die(mysqli_error($conn));
?>
<style>
    .sched{
        background-color:white;
        border:1px solid black;
        position:absolute; 
        height:90px;  
    }
</style>
<br />
<div class='col-sm-12'> 
<?php
    while($rw0 = mysqli_fetch_assoc($qry0)){
        $sectNo     = $rw0['fldNo']; 
        $prgNo      = $rw0['fldPrgNo']; 
        $deptNo     = $rw0['fldDeptNo'];
        $qry1       = mysqli_query($conn,"SELECT * FROM tblProgram WHERE fldNo='$prgNo'  ")or die(mysqli_error($conn));
        $rw1        = mysqli_fetch_assoc($qry1); 
        $qry2       = mysqli_query($conn,"SELECT * FROM tblDepartment WHERE fldNo='$deptNo'  ")or die(mysqli_error($conn));
        $rw2        = mysqli_fetch_assoc($qry2); 
        $disabled   = $deptNo != $_SESSION['deptNo']?"disabled":"";
        $cols       = $rw0['fldYrLvl']==0?4:3;
        $yrLvl      = $rw0['fldYrLvl'];
        $width      = $yrLvl == 0?"width:170px;;height:100%":"width:195px; height:100%";
        $width1     = $yrLvl == 0?"width:170px;":"width:195px;";
        
        $MTH        = "";
        $qry5 = mysqli_query($conn,"SELECT * FROM tblSubjectOffer WHERE fldSectNo='$sectNo' AND ((fldStart !='00:00:00' AND fldEnd !='00:00:00 ') AND (fldMon='1' || fldThu='1')) ")or die(mysqli_error($conn));
        $base = 450; 
        while($rw5 = mysqli_fetch_assoc($qry5)){
            $subNo = $rw5['fldSubNo'];
            $fcNo = $rw5['fldFcNo'];
            $faculty = "No faculty";
            $room    = "No room";
            $note    = "";
            $qry6   = mysqli_query($conn,"SELECT * FROM tblSubject WHERE fldNo='$subNo' ")or die(mysqli_error($conn));
            $rw6    = mysqli_fetch_assoc($qry6);
            
            $qry7   = mysqli_query($conn,"SELECT * FROM tblFaculty WHERE fldNo='$fcNo' ")or die(mysqli_error($conn));
            $rw7    = mysqli_fetch_assoc($qry7); 

            $strt = $rw5['fldStart'];
            $end  = $rw5['fldEnd'];
            $sHr  = date("H",strtotime($strt));
            $sMin = date("i",strtotime($strt)); 
            $eHr  = date("H",strtotime($end));
            $eMin = date("i",strtotime($end)); 
            $sHr  -= $sHr*60 >=780?1:0;
            $eHr  -= $sHr*60 >=780?1:0;
            $strt  = ($sHr*60)+$sMin;
            $end   = ($eHr*60)+$eMin;
            $addMargin   = ($strt-$base)/90;
            $marginTop = $strt-$base+$addMargin;
            $marginTop .= "px;";
            $height    =  $end-$strt;
            $height    .= "px;";
            
            $MTH .= "<div class='sched' style='$width1;margin-top:$marginTop;height:$height  '><table border=0 style='height:100%; width:100%;' ><tr><td style='text-align:center;height:100%'>";
            $MTH .= "<strong style='font-size:13px;'>".$rw6['fldCode']."</strong>"; 
            $MTH .= "<br /><span style='font-size:10px;'>(".$rw6['fldDesc'].")</span>";
            $MTH .= "<br /><span style='font-size:10px;'>$faculty</span>";
            $MTH .= "<br /><span style='font-size:10px;'>$room</span>";
            $MTH .= "<br /><span style='font-size:10px;'>$note</span>";
            $MTH .= "<button class='btn btn-primary btn-xs' $disabled ><i class='fa fa-edit'></i></button>";
            $MTH .= "<button class='btn btn-warning btn-xs'><i class='fa fa-share' $disabled ></i></button>";
            $MTH .= "<button class='btn btn-success btn-xs'><i class='fa fa-envelope' $disabled ></i></button>";
            $MTH .= "</td></tr></table></div>"; 
        }
        
        
        $TF        = "";
        $qry5 = mysqli_query($conn,"SELECT * FROM tblSubjectOffer WHERE fldSectNo='$sectNo' AND ((fldStart !='00:00:00' AND fldEnd !='00:00:00 ') AND (fldTue='1' || fldFri='1')) ")or die(mysqli_error($conn));
        $base = 450; 
        while($rw5 = mysqli_fetch_assoc($qry5)){
            $subNo = $rw5['fldSubNo'];
            $fcNo = $rw5['fldFcNo'];
            $faculty = "No faculty";
            $room    = "No room";
            $qry6   = mysqli_query($conn,"SELECT * FROM tblSubject WHERE fldNo='$subNo' ")or die(mysqli_error($conn));
            $rw6    = mysqli_fetch_assoc($qry6);
            
            $qry7   = mysqli_query($conn,"SELECT * FROM tblFaculty WHERE fldNo='$fcNo' ")or die(mysqli_error($conn));
            $rw7    = mysqli_fetch_assoc($qry7); 

            $strt = $rw5['fldStart'];
            $sHr  = date("H",strtotime($strt));
            $sMin = date("i",strtotime($strt)); 
            $sHr  -= $sHr*60 >=780?1:0;
            $strt  = ($sHr*60)+$sMin;
            $addMargin   = ($strt-$base)/90;
            $marginTop = $strt-$base+$addMargin;
            $marginTop .= "px;";
            $height    = "90px;";
            $TF .= "<div class='sched' style='$width1;margin-top:$marginTop;height:$height  '>";
            $TF .= "<strong style='font-size:13px;'>".$rw6['fldCode']."</strong>"; 
            $TF .= "<br /><span style='font-size:10px;'>(".$rw6['fldDesc'].")</span>";
            $TF .= "<br /><span style='font-size:10px;'>$faculty</span>";
            $TF .= "<br /><span style='font-size:10px;'>$room</span>";
            $TF .= "</div>"; 
        }
        
        
        $WED        = "";
        $qry5 = mysqli_query($conn,"SELECT * FROM tblSubjectOffer WHERE fldSectNo='$sectNo' AND ((fldStart !='00:00:00' AND fldEnd !='00:00:00 ') AND (fldWed='1')) ")or die(mysqli_error($conn));
        $base = 450; 
        while($rw5 = mysqli_fetch_assoc($qry5)){
            $subNo = $rw5['fldSubNo'];
            $fcNo = $rw5['fldFcNo'];
            $faculty = "No faculty";
            $room    = "No room";
            $qry6   = mysqli_query($conn,"SELECT * FROM tblSubject WHERE fldNo='$subNo' ")or die(mysqli_error($conn));
            $rw6    = mysqli_fetch_assoc($qry6);
            
            $qry7   = mysqli_query($conn,"SELECT * FROM tblFaculty WHERE fldNo='$fcNo' ")or die(mysqli_error($conn));
            $rw7    = mysqli_fetch_assoc($qry7); 

            $strt = $rw5['fldStart'];
            $sHr  = date("H",strtotime($strt));
            $sMin = date("i",strtotime($strt)); 
            $sHr  -= $sHr*60 >=780?1:0;
            $strt  = ($sHr*60)+$sMin;
            $addMargin   = ($strt-$base)/90;
            $marginTop = $strt-$base+$addMargin;
            $marginTop .= "px;";
            $height    = "90px;";
            $WED .= "<div class='sched' style='$width1;margin-top:$marginTop;height:$height  '>";
            $WED .= "<strong style='font-size:13px;'>".$rw6['fldCode']."</strong>"; 
            $WED .= "<br /><span style='font-size:10px;'>(".$rw6['fldDesc'].")</span>";
            $WED .= "<br /><span style='font-size:10px;'>$faculty</span>";
            $WED .= "<br /><span style='font-size:10px;'>$room</span>";
            $WED .= "</div>"; 
        }
        ?>
        <div class='row'>
            <div class='col-sm-12'  style='border:1px solid black;padding-top:20px;padding-bottom:20px;margin-top:10px;'>
                <div class='row'>
                <div class='col-sm-12'>
                    <center>
                        <strong style='font-size:18px;text-transform:uppercase;'><?php echo $rw2['fldName'];?> DEPARTMENT</strong>    
                        <br />
                        <strong style='font-size:18px;text-transform:uppercase;'><?php $yr = $rw0['fldYrLvl']+1; echo $rw1['fldAbbrv']." ".$yr."".$rw0['fldSect'];?></strong>   
                    </center>
                    <br />
                </div> 
                <div class='col-sm-2' > 
                    <div class='row'>
                        <div class='col-sm-12'>  
                        <div class='col-sm-12' style='border-bottom:1px solid steelblue'> 
                            <strong style='color:steelblue;font-size:14px;'>Subjects</strong></strong> 
                        </div>
                    </div>
                    <div class='col-sm-12'>  
                    <br />
                        <table style='width:100%;'>
                        <?php 
                            $qry3 = mysqli_query($conn,"SELECT * FROM tblSubjectOffer WHERE fldSectNo='$sectNo' AND ((fldStart='00:00:00' AND fldEnd='00:00:00') || (fldMon='0' AND fldTue='0' AND fldWed='0' AND fldThu='0' AND fldFri='0' AND fldSat='0')) ")or die(mysqli_error($conn));
                            while($rw3 = mysqli_fetch_assoc($qry3)){
                                $subOffNo  = $rw3['fldNo'];
                                $subNo  = $rw3['fldSubNo'];
                                $qry4   = mysqli_query($conn,"SELECT * FROM tblSubject WHERE fldNo='$subNo' ")or die(mysqli_error($conn));
                                $rw4    = mysqli_fetch_assoc($qry4); 
                                echo "<tr>";
                                echo "<td style='font-size:14px;'>".$rw4['fldCode']."</td>";
                                echo "</tr>";
                                echo "<tr>";
                                echo "<td style='width:20px;font-size:14px;'>";
                                echo "<button type='button' $disabled  class='btn btn-primary btn-xs' onclick='plotSubject($sectNo, $subOffNo);' ><i class='fa fa-edit'></i> Plot<//button>";
                                echo "<button type='button' $disabled class='btn btn-warning btn-xs' onclick='plotSubject($sectNo, $subOffNo);' ><i class='fa fa-share'></i> c/o<//button>";
                                echo "</td>";
                                echo "</tr>";
                            }
                        ?>
                            <tr></tr>
                        </table> 
                    </div>
                    <div class='col-sm-12'>
                        <br />
                        <br />
                        <button class='btn btn-danger btn-block'>Disband Section</button>
                        
                    </div>
                        
                    <div class='col-sm-12'>
                        <br />
                        History Log 
                    </div>
                    <div class='col-sm-12'>
                        <table class='table-list' style='width:100%'>
                            <tr>
                                <td>Date& Time</td>
                                <td>Action</td>
                            </tr>
                        </table>
                    </div>
                    </div>
                </div>
                <div class='col-sm-10'>
                    <div class='col-sm-12'>
                        <table style='border:2px solid black; ' border=1>
                            <tr>
                                <td rowspan=2 style='text-align:center;font-weight:bold;'>Time</td>
                                <td colspan=<?php echo $cols;?> style='text-align:center;font-weight:bold;'>Day</td> 
                            </tr>
                            <tr>
                                <td style='text-align:center;font-weight:bold;'>MTh</td>
                                <td style='text-align:center;font-weight:bold;'>Wed</td>
                                <td style='text-align:center;font-weight:bold;'>TF</td> 
                                <?php if($yrLvl==0){ ?>
                                <td style='text-align:center;font-weight:bold;'>SAT </td> 
                                <?php } ?>
                            </tr>
                            <tr>
                                <td style='<?php echo $width;?>'>
                                    <div style='height:90px;text-align:center;font-weight:bold;'>7:30-9:00</div>
                                </td>
                                <td   style='padding:0xp;vertical-align:top;<?php echo $width;?>padding:0px;text-align:center'>
                                     <center>
                                         <div style='<?php echo $width;?>;   ' class='td-div'> 
                                                <?php echo $MTH;?> 
                                        </div>
                                     </center> 
                                </td>  
                                <td  style='padding:0px;vertical-align:top;<?php echo $width;?>;padding:0px;text-align:center'> 
                                     <center>
                                         <div style='<?php echo $width;?>;   ' class='td-div'> 
                                                <?php echo $WED;?> 
                                        </div>
                                     </center> 
                                </td>  
                                <td style='vertical-align:top;<?php echo $width;?>;padding:0px;text-align:center'> 
                                     <center>
                                         <div style='<?php echo $width;?>;   ' class='td-div'> 
                                                <?php echo $TF;?> 
                                        </div>
                                     </center> 
                                </td>  
                                <?php if($yrLvl==0){ ?>
                                <td style='vertical-align:top;<?php echo $width;?>;padding:0px;text-align:center'> 
                                </td>  
                                <?php } ?>
                            </tr>
                            <tr>
                                <td style='vertical-align:middle;'>
                                    <div style='height:90px;text-align:center;font-weight:bold;'>9:00-10:30</div>
                                </td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <?php if($yrLvl==0){ ?>
                                <td></td
                                <?php } ?>
                            </tr>
                            <tr>
                                <td style='vertical-align:middle;'>
                                    <div style='height:90px;text-align:center;font-weight:bold;'>10:30-12:00</div>
                                </td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <?php if($yrLvl==0){ ?>
                                <td></td
                                <?php } ?>
                            </tr>
                            <tr>
                                <td style='vertical-align:middle;'>
                                    <div style='height:90px;text-align:center;font-weight:bold;'>1:00-2:30</div>
                                </td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <?php if($yrLvl==0){ ?>
                                <td></td
                                <?php } ?>
                            </tr>
                            <tr>
                                <td style='vertical-align:middle;'>
                                    <div style='height:90px;text-align:center;font-weight:bold;'>2:30-4:00</div>
                                </td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <?php if($yrLvl==0){ ?>
                                <td></td
                                <?php } ?>
                            </tr>
                            <tr>
                                <td style='vertical-align:middle;'>
                                    <div style='height:90px;text-align:center;font-weight:bold;'>4:00-5:30</div>
                                </td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <?php if($yrLvl==0){ ?>
                                <td></td
                                <?php } ?>
                            </tr>
                            <tr>
                                <td style='vertical-align:middle;'>
                                    <div style='height:90px;text-align:center;font-weight:bold;'>5:30-7:00</div>
                                </td
                                <td></td>
                                <td></td>
                                <td></td>
                                <?php if($yrLvl==0){ ?>
                                <td></td
                                <?php } ?>
                            </tr>
                        </table>
                    </div>
                </div>
                </div>
            </div>
        </div>
<?php  }  ?>
<br />
<br />
<br />
</div>
 

<script>
function plotSubject(sectNo, subOffNo){  
        showModal("Plot Subject","", 1, 600);
        $("#modalContent").load("../form/form-subject-plot.php?sectNo="+sectNo+"&subOffNo="+subOffNo); 
}  
function deleteForm(fcNo){ 
        showModal("Faculty Information","", 1, 600);
        $("#modalContent").load("../form/form-faculty-remove.php?fcNo="+fcNo); 
}    
</script>



