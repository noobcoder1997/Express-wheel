<?php 
    include '../components/comp-conn.php';  
     
    $qry0 = mysqli_query($conn,"SELECT * FROM tblDepartment ORDER BY fldName ")or die(mysqli_error($conn));
?>

<br /> 
<div class='col-sm-12' style='height:90%;overflow:auto;'> 
    <table class='table-list' border=1>
        <tr>
            <td></td>
            <td>Department Name</td>
            <td>Abbreviation</td>  
            <td>Options</td> 
        </tr>
        <?php
            $no  = 1;
            while($rw0 = mysqli_fetch_assoc($qry0)){  
                $deptNo = $rw0['fldNo']; 
                echo "<tr>";
                echo "<td>$no.</td>";
               
                echo "<td>".$rw0['fldName']."</td>";
                echo "<td>".$rw0['fldAbbrv']."</td>";  
                echo "<td>";
                echo "<button class='btn btn-default btn-xs ' onclick='editForm($deptNo)' ><i class='fa fa-edit'></i> Edit</button>";
                echo "<button class='btn btn-danger btn-xs ' onclick='deleteForm($deptNo)' ><i class='fa fa-trash'></i> Remove</button>";
                echo "</td>";
                echo "</tr>";
                $no++;
            }
        ?>
    </table>
</div> 

<script>
function editForm(deptNo){ 
        showModal("Department","", 1, 600);
        $("#modalContent").load("../form/form-department-edit.php?deptNo="+deptNo); 
}  
function deleteForm(deptNo){ 
        showModal("Department","", 1, 600);
        $("#modalContent").load("../form/form-department-remove.php?deptNo="+deptNo); 
}    
</script>



