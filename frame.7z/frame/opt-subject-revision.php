<?php 
    include '../components/comp-conn.php';  
    
    $prNo = $_GET['prNo']; 
    $qry0 = mysqli_query($conn,"SELECT * FROM tblSubject WHERE fldPrgNo='$prNo' GROUP BY fldRev  ")or die(mysqli_error($conn));
      
?>
<strong>Revision</strong>
<select class='form-control' id='rv'  > 
    <?php 
        while($rw0=mysqli_fetch_assoc($qry0)){
            echo "<option value='".$rw0['fldRev']."'>".$rw0['fldRev']."</option>  ";
        }
    ?>
</select>