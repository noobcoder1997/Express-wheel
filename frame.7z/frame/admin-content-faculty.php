<?php 
    include '../components/comp-conn.php';  
    
    $condition = "";
    if($_POST['srch']!=''){
        $srch       = $_POST['srch'];
        $condition  .= "WHERE fldName LIKE '%$srch%'";
    }
    
    if($_POST['dptNo']!=0){
        $dptNo      = $_POST['dptNo'];
        $condition .= $condition==""?"WHERE fldDeptNo='$dptNo'":" AND fldDeptNo='$dptNo'";
    }
    if($_POST['emp']!=''){
        $emp        = $_POST['emp'];
        $condition .= $condition==""?"WHERE fldEmpStatus='$emp'":" AND fldEmpStatus='$emp'";
    } 
    $qry0 = mysqli_query($conn,"SELECT * FROM tblFaculty $condition ORDER BY fldDeptNo, fldName ")or die(mysqli_error($conn));
?>

<br /> 
<div class='col-sm-12'  > 
    <table class='table-list' border=0>
        <tr>
            <td></td>
            <td>Faculty Name</td>
            <td>Academic Rank</td> 
            <td>Employment Status</td> 
            <td>Department</td> 
            <td>Options</td> 
        </tr>
        <?php
            $no  = 1;
            while($rw0 = mysqli_fetch_assoc($qry0)){
                $fcNo   = $rw0['fldNo'];
                $deptNo = $rw0['fldDeptNo'];
                $qry1  = mysqli_query($conn,"SELECT * FROM tblDepartment WHERE fldNo='$deptNo'  ")or die(mysqli_error($conn));
                $rw1   = mysqli_fetch_assoc($qry1);
                $empSts = $rw0['fldEmpStatus']==0?"Regular Faculty":"Part-timer Faculty";
                echo "<tr>";
                echo "<td>$no.</td>";
               
                echo "<td>".$rw0['fldName']."</td>";
                echo "<td>".$rw0['fldAcadRank']."</td>";
                echo "<td>$empSts</td>";
                echo "<td>".$rw1['fldName']."</td>";
                echo "<td>";
                echo "<button class='btn btn-default btn-xs ' onclick='editForm($fcNo)' ><i class='fa fa-edit'></i> Edit</button>";
                echo "<button class='btn btn-danger btn-xs ' onclick='deleteForm($fcNo)' ><i class='fa fa-trash'></i> Remove</button>";
                echo "</td>";
                echo "</tr>";
                $no++;
            }
        ?>
    </table>
    <br />
    <br />
</div> 

<script>
function editForm(fcNo){ 
        showModal("Faculty Information","", 1, 600);
        $("#modalContent").load("../form/form-faculty-edit.php?fcNo="+fcNo); 
}  
function deleteForm(fcNo){ 
        showModal("Faculty Information","", 1, 600);
        $("#modalContent").load("../form/form-faculty-remove.php?fcNo="+fcNo); 
}    
</script>



