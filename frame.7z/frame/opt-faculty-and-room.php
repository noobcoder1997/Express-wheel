<?php 
    include '../components/comp-conn.php';  
    
    $semNo = $_GET['semNo']; 
    $strt  = $_GET['strt']; 
    $end   = $_GET['end']; 
    $mon   = $_GET['mon']; 
    $tue   = $_GET['tue']; 
    $wed   = $_GET['wed']; 
    $thu   = $_GET['thu']; 
    $fri   = $_GET['fri']; 
    $sat   = $_GET['sat']; 
      
    $flds = ['fldMon', 'fldTue', 'fldWed', 'fldThu', 'fldFri', 'fldSat'];
    $DAY  = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
    $days = [$mon, $tue, $wed, $thu, $fri, $sat ];
    
?>
<div class='row'> 
    <div class='col-sm-6'>
        <strong>Faculty</strong>
        <select class='form-control input-sm' id='fcty' > 
            <option value='0'>TBA</option> 
            <?php 
                $qry0 = mysqli_query($conn,"SELECT * FROM tblFaculty ORDER BY fldName, fldDeptNo ")or die(mysqli_error($conn));
                while($rw0=mysqli_fetch_assoc($qry0)){
                    $fcNo = $rw0['fldNo'];
                    $monQry  = mysqli_query($conn,"SELECT * FROM tblSubjectOffer WHERE fldSemNo='$semNo' AND fldFcNo='$fcNo' AND ((fldStart<='$strt' AND fldEnd>='$strt') ||(fldStart<='$end' AND fldEnd <'$end')) AND (fldMon='1' AND fldMon='$mon') ")or die(mysqli_error($conn));
                    $tueQry  = mysqli_query($conn,"SELECT * FROM tblSubjectOffer WHERE fldSemNo='$semNo' AND fldFcNo='$fcNo' AND ((fldStart<='$strt' AND fldEnd>='$strt') ||(fldStart<='$end' AND fldEnd <'$end')) AND (fldTue='1' AND fldTue='$tue') ")or die(mysqli_error($conn));
                    $wedQry  = mysqli_query($conn,"SELECT * FROM tblSubjectOffer WHERE fldSemNo='$semNo' AND fldFcNo='$fcNo' AND ((fldStart<='$strt' AND fldEnd>='$strt') ||(fldStart<='$end' AND fldEnd <'$end')) AND (fldWed='1' AND fldWed='$wed') ")or die(mysqli_error($conn));
                    $thuQry  = mysqli_query($conn,"SELECT * FROM tblSubjectOffer WHERE fldSemNo='$semNo' AND fldFcNo='$fcNo' AND ((fldStart<='$strt' AND fldEnd>='$strt') ||(fldStart<='$end' AND fldEnd <'$end')) AND (fldThu='1' AND fldThu='$thu') ")or die(mysqli_error($conn));
                    $friQry  = mysqli_query($conn,"SELECT * FROM tblSubjectOffer WHERE fldSemNo='$semNo' AND fldFcNo='$fcNo' AND ((fldStart<='$strt' AND fldEnd>='$strt') ||(fldStart<='$end' AND fldEnd <'$end')) AND (fldFri='1' AND fldFri='$fri') ")or die(mysqli_error($conn));
                    $satQry  = mysqli_query($conn,"SELECT * FROM tblSubjectOffer WHERE fldSemNo='$semNo' AND fldFcNo='$fcNo' AND ((fldStart<='$strt' AND fldEnd>='$strt') ||(fldStart<='$end' AND fldEnd <'$end')) AND (fldSat='1' AND fldSat='$sat') ")or die(mysqli_error($conn));
                    
                    if(mysqli_num_rows($monQry)==0 && mysqli_num_rows($tueQry)==0 && mysqli_num_rows($wedQry)==0  && mysqli_num_rows($thuQry)==0 && mysqli_num_rows($friQry)==0  && mysqli_num_rows($satQry)==0){
                        echo "<option value='$fcNo'>".$rw0['fldName']."</option>";
                    } else{
                        echo $rw0['fldName'];
                    }
                }
                     
            ?>
            
        </select> 
    </div>
    <div class='col-sm-6'>
        <strong>Room No</strong>
        <select class='form-control input-sm' id='rmNo' > 
            
        </select> 
    </div>
</div>