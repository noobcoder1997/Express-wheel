<?php 
    include '../components/comp-conn.php';  
    
    $prNo   = $_POST['prNo']; 
    $rev    = $_POST['rv']; 
    $srch   = $_POST['srch'];
    $yr     = $_POST['yr']; 
    $sem    = $_POST['sem'];  
    $condition = "WHERE fldRev='$rev' AND fldPrgNo='$prNo' AND fldYrLvl='$yr' AND fldSem='$sem'  ";
     
    $yearLevel = ['First Year', 'Second Year', 'Third Year', 'Fourth Year'];
    $semester = ['First Semester', 'Second Semester', 'Summer 1', 'Summer 2'];
    
     
?>

<br />    
<?php   
    $qry0 = mysqli_query($conn,"SELECT * FROM tblSubject $condition   ")or die(mysqli_error($conn));
    if(mysqli_num_rows($qry0)>0){ 
?>
<div class='col-sm-12'  >
    <center>  
        <strong style='text-transform:uppercase; color:steelblue; font-size:15px;'><?php echo $yearLevel[$yrLvl];?></strong>
        
    </center>
</div> 
<div class='col-sm-12'  > 
    <center>  
        <table class='table-list' border=0>
            <tr>
                <td></td>
                <td>Code Name</td>
                <td>Subject Title</td>   
                <td style='text-align:center'> Unit</td>  
                <td style='text-align:center'>Credited Unit</td> 
                <td style='text-align:center'>Hr per week</td> 
                <td>Copy</td> 
            </tr>
            <?php 
                $no  = 1;
                while($rw0 = mysqli_fetch_assoc($qry0)){
                    $subNo   = $rw0['fldNo']; 
                    $mjr     = $rw0['fldMajor']==0?"Major":"Minor";
                    echo "<tr>";
                    echo "<td>$no.</td>"; 
                    echo "<td style='width:120px;text-align:left' >".$rw0['fldCode']."</td>";
                    echo "<td style='width:350px;text-align:left' >".$rw0['fldDesc']."</td>";  
                    echo "<td style='width:60px;text-align:center' >".$rw0['fldUnit']."</td>";
                    echo "<td style='width:60px;text-align:center' >".$rw0['fldCUnit']."</td>";
                    echo "<td style='width:60px;text-align:center' >".$rw0['fldHr']."</td>";
                    echo "<td  style='width:40px;text-align:left' >";
                    echo "<button type='button' class='btn btn-default btn-xs ' onclick='copySubject($subNo)' ><i class='fa fa-share'></i> </button>";  
                    echo "</td>";
                    echo "</tr>"; 
                    $no++;
                }
            ?>
        </table>
    </center>
    <br />
    <br />
</div> 

<?php } ?> 
 
<script>  
</script>



