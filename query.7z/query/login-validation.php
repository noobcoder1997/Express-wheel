<?php 
    include "../components/comp-conn.php"; 
    
    $user = $_POST['user'];
    $pass = $_POST['pass'];
    
    $pass = md5($pass);

    $qry0 = mysqli_query($conn,"SELECT * FROM tbl_user WHERE user='$user' AND pass='$pass' ")or die(mysqli_error($conn)); 
    
    // $qry1 = mysqli_query($conn,"SELECT * FROM tbl_admin WHERE username='$user' AND password='$pass' ")or die(mysqli_error($conn));
    
    // $qry2 = mysqli_query($conn,"SELECT * FROM tbl_sup_admin WHERE username='$user' AND password='$pass' ")or die(mysqli_error($conn));
    
    // $qry3 = mysqli_query($conn,"SELECT * FROM tbl_riders WHERE username='$user' AND password='$pass' ")or die(mysqli_error($conn));
    
    if(mysqli_num_rows($qry0)==1){ //user
        $rw0 = mysqli_fetch_assoc($qry0);
        if($rw0['position'] == '0'){
            $_SESSION['userNo'] = $rw0['no'];
            $_SESSION['user_status'] = true;
            $_SESSION['position'] = $rw0['position'];
        ?>
        <script>
            setTimeout(function(){ window.location.href="pages-user/index.php"; }, 500);   
        </script>
        <?php              
        }
        if($rw0['position'] == '1'){ //rider
            $_SESSION['userNo'] = $rw0['no'];
            $_SESSION['admin_status'] = true;
            $_SESSION['position'] = $rw0['position'];
        ?>
        <script>
            setTimeout(function(){ window.location.href="pages-admin/index.php"; }, 500);   
        </script>  
        <?php
        }
        if($rw0['position'] == '2'){ //super admin
            $_SESSION['userNo'] = $rw0['no'];
            $_SESSION['sup_admin_status'] = true;
            $_SESSION['position'] = $rw0['position'];
        ?>
        <script>
            setTimeout(function(){ window.location.href="pages-sup-admin/index.php"; }, 500);   
        </script>  
        <?php
        }  
    }
    else{
        echo "<div class='alert alert-danger'>";
        echo "<strong>Access Denied:</strong> Incorrect username and/or password. Please try again.";
        echo "</div>";
    }
?>