<?php 
    include "../components/comp-conn.php"; 
    session_start();
    $userNo =  $_SESSION['userNo'];
    $itemNum = $_POST['num'];
    for($p=0;$p<$itemNum;$p++){
        $prodNo = $_POST['prodNo'.$p];
        $qty    = $_POST['qty'.$p]; 
        $prc    = $_POST['prc'.$p]; 
        $strNo  = $_POST['strNo'.$p]; 
        
        $qry0 = mysqli_query($conn,"SELECT * FROM tbl_order WHERE userNo='$userNo' AND prodNo='$prodNo' ")or die(mysqli_error($conn));
        
        if(mysqli_num_rows($qry0)>0){
            $rw0  = mysqli_fetch_assoc($qry0);
            $rqty  = $rw0['qty'];
            $qty  += $eqty;
            mysqli_query($conn,"UPDATE tbl_order SET qty='$qty', price='$prc'  WHERE userNo='$userNo' AND prodNo='$prodNo'  ")or die(mysqli_error($conn));
            
        }else{
            mysqli_query($conn,"INSERT INTO tbl_order (userNo, prodNo, qty, price, strNo ) VALUES ('$userNo', '$prodNo', '$qty', '$prc', '$strNo' ) ")or die(mysqli_error($conn));
        }
        
    }
    
    
    echo "Order placed. Please wait for seller confirmation. Thank you!";
?>