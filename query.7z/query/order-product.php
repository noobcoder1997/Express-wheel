<?php 
    include "../components/comp-conn.php"; 
    session_start();
    $userNo =  $_SESSION['userNo'];
    $prodNo = $_POST['prodNo'];
    $qty    = $_POST['qty']; 
    $prc    = $_POST['prc']; 
    $strNo  = $_POST['strNo']; 
    
    $qry0 = mysqli_query($conn,"SELECT * FROM tbl_order WHERE userNo='$userNo' AND prodNo='$prodNo' ")or die(mysqli_error($conn));
    
    if(mysqli_num_rows($qry0)>0){
        $rw0  = mysqli_fetch_assoc($qry0);
        $rqty  = $rw0['qty'];
        $qty  += $eqty;
        mysqli_query($conn,"UPDATE tbl_order SET qty='$qty', price='$prc'  WHERE userNo='$userNo' AND prodNo='$prodNo'  ")or die(mysqli_error($conn));
        
    }else{
        mysqli_query($conn,"INSERT INTO tbl_order (userNo, prodNo, qty, price, strNo ) VALUES ('$userNo', '$prodNo', '$qty', '$prc', '$strNo' ) ")or die(mysqli_error($conn));
    }
    
    echo "Order placed. Please wait for seller confirmation. Thank you!";
?>