<?php 
    include "../components/comp-conn.php"; 
    $userNo = $_POST['userNo'];
    $userIdFront = explode(".",$_FILES["userIdFront"]["name"] );
    $userIdBack  = explode(".",$_FILES["userIdBack"]["name"] );
    
	$userIdFrontExtension = end($userIdFront);  
	$userIdBackExtension  = end($userIdBack);  
    
    
	$userIdFront_name = time().".".$userIdFrontExtension;
	$userIdBack_name  = time().".".$userIdBackExtension;
	
	$location0 = "../assets/image/".$userIdFront_name;
	$location1 = "../assets/image/".$userIdBack_name;
	
	move_uploaded_file($_FILES["userIdFront"]["tmp_name"],$location0); 
	move_uploaded_file($_FILES["userIdBack"]["tmp_name"],$location1); 
	
	mysqli_query($conn,"UPDATE tbl_user SET img0='$userIdFront_name', img1='$userIdBack_name' WHERE no='$userNo'  ")or die(mysqli_error($conn));
?>