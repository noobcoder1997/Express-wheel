<?php 
    include "../components/comp-conn.php"; 
    session_start();
     
    $ln     = htmlentities(mysqli_real_escape_string($conn, $_POST['ln'])); 
    $fn     = htmlentities(mysqli_real_escape_string($conn, $_POST['fn'])); 
    $mn     = htmlentities(mysqli_real_escape_string($conn, $_POST['mn'])); 
    $sex    = htmlentities(mysqli_real_escape_string($conn, $_POST['sex'])); 
    $bday   = htmlentities(mysqli_real_escape_string($conn, $_POST['bday'])); 
    $cpNo   = htmlentities(mysqli_real_escape_string($conn, $_POST['cpNo'])); 
    $email  = htmlentities(mysqli_real_escape_string($conn, $_POST['email'])); 
    $muni   = htmlentities(mysqli_real_escape_string($conn, $_POST['muni'])); 
    $brgy   = htmlentities(mysqli_real_escape_string($conn, $_POST['brgy'])); 
    $prk    = htmlentities(mysqli_real_escape_string($conn, $_POST['prk']));
    $hh     = htmlentities(mysqli_real_escape_string($conn, $_POST['hh']));
    $zip    = htmlentities(mysqli_real_escape_string($conn, $_POST['zip']));
    $lndMrk = htmlentities(mysqli_real_escape_string($conn, $_POST['lndMrk'])); 
    $user   = htmlentities(mysqli_real_escape_string($conn, $_POST['user']));
    $pass   = htmlentities(mysqli_real_escape_string($conn, $_POST['pass'])); 
    $pass   = htmlentities(mysqli_real_escape_string($conn, stripcslashes(trim(md5($pass)))));
    $message = "";
    
    //CHECK FOR USERNAME OR PASSWORD AVAILABILITY
    $qry0 = mysqli_query($conn,"SELECT * FROM tbl_user WHERE user='$user' OR pass='$pass' ")or die(mysqli_error($conn));
    if(mysqli_num_rows($qry0)>0){
        $message = "<div class='alert alert-danger'>";
        $message .= "<strong>Notice:</strong> Please choose another username or password ";
        $message .= "</div>";
    }else{
        mysqli_query($conn,"INSERT INTO tbl_user (`user`, `pass`, `ln`, `fn`, `mn`, `sex`, `bday`, `contact`, `email`, `household`, `purok`, `barangay`, `municipal`, `zipcode`, `landmark`, `verified`) VALUES ('$user', '$pass', '$ln', '$fn', '$mn', '$sex', '$bday', '$cpNo', '$email', '$hh', '$prk', '$brgy', '$muni', '$zip', '$lndMrk', '0') ")or die(mysqli_error($conn));
        
        $message =  "<div class='alert alert-success'>";
        $message .= "<strong>SUCCESS:</strong> You have success registered to Express wheel.";
        $message .= "</div>";
    }

    
    echo $message;   
?>