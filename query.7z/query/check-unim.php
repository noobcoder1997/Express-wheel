<?php
// Your PHP code starts here
    include '../components/comp-conn.php';

    $unim = $_POST['usernim'];

    $query = mysqli_query($conn, "SELECT * FROM tbl_user WHERE user = '$unim' LIMIT 1");
    $row = mysqli_fetch_array($query);

    $count = mysqli_num_rows($query);
    if($count > 0){
        echo 1;
    }
    else{
        echo "<div class='alert alert-danger'>";
        echo "<strong>Invalid Username:</strong> You have entered an invalid username.";    
        echo "</div>";
    }
?>