<div class='nav' style='padding-left:5px;padding-top:10px;'>  
        <table>
            <tr>
                <td rowspan="3" style='border-right:2px solid #666;padding:5px;'><img src='../assets/image/logo.png' class='nav-logo '/></td>
                <td style='color:white;vertical-align:top;padding-left:5px;font-size:16px;font-weight:normal;'>COMPUTERIZED STUDENT RECORD SYSTEM</td>
            </tr>
            <tr>
                <td style='vertical-align:bottom;padding-left:5px;font-size:35px;font-weight:bold;'> <u>SOUTHERN LEYTE STATE UNIVERSITY</u></td>
            </tr>
            <tr>
                <td style='color:#ddd;vertical-align:top;padding-left:5px;font-size:12px;font-weight:normal;'>San Juan Campus, San Juan, Southern Leyte</td>
            </tr>
        </table> 
</div> 
<div class='sidebar'> 
    <div class='sidebar-btn'  style='border-top:1px solid white;'  onclick='gotoPage("index.php")'>
        <i class='fa fa-clipboard'></i> 
        <div class='sb-btn-title'>DASHBOARD</div>
    </div>   
    <div class='sidebar-btn' onclick='gotoPage("page-student.php")'>
        <i class='fa fa-users'></i> 
        <div class='sb-btn-title'>STUDENTS</div>
    </div>     
    <div class='sidebar-btn' onclick='gotoPage("page-classes.php")'>
        <i class='fa fa-book-reader'></i> 
        <div class='sb-btn-title'>MY&nbsp;CLASSES</div>
    </div>      
    <div class='sidebar-btn' onclick='gotoPage("page-gradesheet.php")'>
        <i class='fa fa-file-alt'></i> 
        <div class='sb-btn-title'>GRADE&nbsp;SHEET</div>
    </div>         
    <div class='sidebar-btn' onclick='gotoPage("page-prospectus.php")'>
        <i class='fa fa-file'></i> 
        <div class='sb-btn-title'>PROSPECTUS</div>
    </div>   
    <div class='sidebar-btn' onclick='addFrom()'>
        <i class='fa fa-edit'></i> 
        <div class='sb-btn-title'>PREFERENCE</div>
    </div>  
    <div class='sidebar-btn' onclick='addFrom()'>
        <i class='fa fa-cog'></i> 
        <div class='sb-btn-title'>SETTING</div>
    </div> 
    <div class='sidebar-btn' onclick='gotoPage("../index.php")'>
        <i class='fa fa-sign-out-alt'></i> 
        <div class='sb-btn-title'>SIGN&nbsp;OUT</div>
    </div>   
</div>
<script>
    function gotoPage(url){
        window.location.href=url;
    }
</script>