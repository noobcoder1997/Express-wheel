<?php 
    if(!isset($_SESSION['deptNo'])){
        ?>
        <script>
            window.location.href='../';
        </script>
        <?php
        echo "NO ADMIN NUMBER";
    }else{
        echo "WITH ADMIN NUMBER";
    }
    $deptNo = $_SESSION['deptNo']; 
    $qry0 = mysqli_query($conn,"SELECT * FROM tblDepartment WHERE fldNo='$deptNo' ")or die(mysqli_error($conn));
    $rw0  = mysqli_fetch_assoc($qry0);
?>
<style>
    .note{
        position: relative;
        float: left;
        z-index: 999999;
        width:15px;
        height:15px;
        font-size: 10px;
        border-radius:50%;
        text-align: center;
        background-color: red;
        top:-20px;
        left:15px;
    }
</style>
<input type='hidden' id='deptNoId' value='<?php echo $rw0['fldNo']; ?>' />
<div class='nav' style='padding-left:5px;padding-top:5px;height:50px;' id='nav'>  
     <table style="width:100%;">
        <tr>
            <td style="width:40%">
               <table  >
                    <tr>  
                        <td rowspan="3" style='border-right:2px solid #666;padding:5px;'>
                             <img src='../assets/image/user-1.png' class='nav-logo 'style='width:30px;height:30px;'/> 
                        </td>   
                        <td style='color:white;vertical-align:top;padding-left:5px;font-size:19px;font-weight:bold;'>
                            <img src="../assets/image/2.gif" class='loading' />
                            <?php echo $rw0['fldName']; ?> Department
                        </td>
                    </tr> 
                    <tr>
                        <td style='color:#ddd;vertical-align:top;padding-left:5px;font-size:12px;font-weight:normal;'>Southern Leyte State University-San Juan Campus </td>
                    </tr>
                </table> 
            
            </td>
            <td style="width:40%">
               <table  >
                    <tr>  
                        <td rowspan="3" style='border-right:2px solid #666;padding:5px;'>
                             <img src='../assets/image/logo.png' class='nav-logo 'style='width:30px;height:30px;'/> 
                        </td>   
                        <td style='color:white;vertical-align:top;padding-left:5px;font-size:19px;font-weight:bold;'>
                            <img src="../assets/image/2.gif" class='loading' />
                            CLASS SCHEDULING SYSTEM
                        </td>
                    </tr> 
                    <tr>
                        <td style='color:#ddd;vertical-align:top;padding-left:5px;font-size:12px;font-weight:normal;'>Southern Leyte State University-San Juan Campus </td>
                    </tr>
                </table> 
            
            </td>
            <td style=''> 
                <table  > 
                    <tr>
                        <td style='text-align:right;color:#ddd;vertical-align:top;padding-right:5px;font-size:10px;font-weight:normal;border-right:1px solid #ddd;'> Developer </td>
                        <td style='text-align:left;color:#ddd;vertical-align:top;padding-left:5px;font-size:10px;font-weight:normal;'>ABDEL KHAN B. SAMPANG</td>
                    
                    </tr>
                    <tr>
                        <td style='text-align:right;color:#ddd;vertical-align:top;padding-right:5px;font-size:10px;font-weight:normal;border-right:1px solid #ddd;'> Date </td>
                        <td style='text-align:left;color:#ddd;vertical-align:top;padding-left:5px;font-size:10px;font-weight:normal;'> July 5, 2024</td>
                    </tr>
                </table> 
            </td>
         </tr>
    </table>
</div> 

<div class='sidebar' style="top:50px;"> 
    <div class='sidebar-btn'  style='border-top:1px solid white;'  onclick='gotoPage("index.php")'>
        <i class='fa fa-clipboard'></i> 
        <div class='sb-btn-title'>DASHBOARD</div>
    </div>      
    <div class='sidebar-btn' onclick='window.location.href="faculty.php";'>
        <i class='fa fa-users'></i> 
        <div class='sb-btn-title'>FACULTY</div>
    </div>   
    <div class='sidebar-btn' onclick='window.location.href="section.php";'>
        <i class='fa fa-home'></i> 
        <div class='sb-btn-title'>SECTION</div>
    </div>
    <div class='sidebar-btn' onclick='window.location.href="class-schedule.php";'>
        <i class='fa fa-calendar'></i> 
        <div class='sb-btn-title'>CLASS&nbsp;SCHEDULE</div>
    </div>
    <div class='sidebar-btn' onclick='window.location.href="page-sign-off.php";'>
        <i class='fa fa-sign-out-alt'></i> 
        <div class='sb-btn-title'>SIGN&nbsp;OUT</div>
    </div>   
</div>
<script> 
    
function loading(n){
    if(n==0){
        $(".loading").hide();
    }else{

        $(".loading").show();
    }
}
function toPage(no){ 
    $(".page").slideUp()
    $("#page"+no).slideDown()
}
</script>