<div class='nav' style='padding-left:5px;padding-top:10px;'> 
   <div class='row'>
       <div class='col-sm-12'>
           <table style='width:90%;'  >
               <tr> 
                   <td><img src='assets/image/logo.ico' class='nav-logo ' alt='logo' id='logo1'/></td>
                    
                   <td>
                        <span style='color:white;vertical-align:top;padding-left:5px;font-size:16px;font-weight:normal;'>Southern Leyte State University-San Juan Campus</span>
                         <br />
                         <span style='vertical-align:bottom;padding-left:5px;font-size:30px;font-weight:bold;color:#fff'>ONLINE WEB-BASED COMPUTERIZED CLASS RECORD v.<?php echo $version; ?></span>
                         <br />
                         <span style='color:#ddd;vertical-align:top;padding-left:5px;font-size:12px;font-weight:normal;'></span>
                   </td>
                   <td style='text-align:right;' > 
                       <table  >
                           <tr>
                               <td style='color:white;text-align:right;font-size:12px;border-right:1px solid white;padding:0px 5px;'>Date</td>
                               <td style='color:white;text-align:left;font-size:12px;padding:0px 5px;'>August 21, 2020 </td>
                           </tr>
                           <td style='color:white;text-align:right;font-size:12px;border-right:1px solid white;padding:0px 5px;'>  Developed by </td>
                           <td style='color:white;text-align:left;font-size:12px;padding:0px 5px;'>
                               Abdel Kha B. Sampang
                           </td>
                       </table>
                   </td>
               </tr>
           </table>
            <br />
       </div> 
   </div>
    
    
    
</div>
<script>
    var width = 60;
    var reverse = false;
    setInterval(function(){
        if(width<0){
            reverse = true;
        }else if(width>60){
            reverse = false;
        }
          
        width = reverse?width+5:width-5; 
        $("#logo").css("width",width+"px")
        $("#logo").css("box-shadow","2px 2px 2px rgba(0,0,0,.5)")
    },100);
</script>