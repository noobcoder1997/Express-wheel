<?php 
    if(!isset($_SESSION['adminNo'])){
        ?>
        <script>
            window.location.href='../';
        </script>
        <?php
        echo "NO ADMIN NUMBER";
    }else{
        echo "WITH ADMIN NUMBER";
    }
    $adminNo = $_SESSION['adminNo'];  
?>
<style>
    .note{
        position: relative;
        float: left;
        z-index: 999999;
        width:15px;
        height:15px;
        font-size: 10px;
        border-radius:50%;
        text-align: center;
        background-color: red;
        top:-20px;
        left:15px;
    }
</style>
<div class='nav' style='padding-left:5px;padding-top:5px;height:50px;' id='nav'>  
     <table style="width:100%;">
        <tr>
            <td style="width:70%">
               <table  >
                    <tr>  
                        <td rowspan="3" style='border-right:2px solid #666;padding:5px;'>
                             <img src='../assets/image/logo.png' class='nav-logo 'style='width:20px;height:20px;'/> 
                        </td>   
                        <td style='color:white;vertical-align:top;padding-left:5px;font-size:19px;font-weight:bold;'>
                            <img src="../assets/image/2.gif" class='loading' />
                            CLASS SCHEDULING SYSTEM
                        </td>
                    </tr> 
                    <tr>
                        <td style='color:#ddd;vertical-align:top;padding-left:5px;font-size:12px;font-weight:normal;'>Southern Leyte State University-San Juan Campus </td>
                    </tr>
                </table> 
            
            </td>
            <td> 
                <table style="width:90%;"> 
                    <tr>
                        <td style='text-align:right;color:#ddd;vertical-align:top;padding-left:5px;font-size:10px;font-weight:normal;'>ABDEL KHAN B. SAMPANG</td>
                    </tr>
                    <tr>
                        <td style='text-align:right;color:#ddd;vertical-align:top;padding-left:5px;font-size:10px;font-weight:normal;'> July 5, 2024</td>
                    </tr>
                </table> 
            </td>
         </tr>
    </table>
</div> 

<div class='sidebar' style="top:50px;"> 
    <div class='sidebar-btn'  style='border-top:1px solid white;'  onclick='gotoPage("index.php")'>
        <i class='fa fa-clipboard'></i> 
        <div class='sb-btn-title'>DASHBOARD</div>
    </div>     
    <div class='sidebar-btn' onclick='window.location.href="department.php";'>
        <i class='fa fa-home'></i> 
        <div class='sb-btn-title'>DEPARTMENT</div>
    </div>   
    <div class='sidebar-btn' onclick='window.location.href="faculty.php";'>
        <i class='fa fa-users'></i> 
        <div class='sb-btn-title'>FACULTY</div>
    </div>  
    <div class='sidebar-btn' onclick='window.location.href="program-major.php";'>
        <i class='fa fa-file'></i> 
        <div class='sb-btn-title'>PROGRAM&nbsp;&&nbsp;MAJORS</div>
    </div>     
    <div class='sidebar-btn' onclick='window.location.href="subject.php";'>
        <i class='fa fa-book'></i> 
        <div class='sb-btn-title'>SUBJECT</div>
    </div>     
    <div class='sidebar-btn' onclick='window.location.href="plotting.php";'>
        <i class='fa fa-calendar'></i> 
        <div class='sb-btn-title'>PLOTTING&nbsp;SCHEDULE</div>
    </div>
    <div class='sidebar-btn' onclick='window.location.href="page-sign-off.php";'>
        <i class='fa fa-sign-out-alt'></i> 
        <div class='sb-btn-title'>SIGN&nbsp;OUT</div>
    </div>   
</div>
<script> 
    
function loading(n){
    if(n==0){
        $(".loading").hide();
    }else{

        $(".loading").show();
    }
}
function toPage(no){ 
    $(".page").slideUp()
    $("#page"+no).slideDown()
}
</script>