<?php

    if(!isset($_SESSION['stdNo'])){
        ?>
        <script>
            window.location.href='../';
        </script>
        <?php
    }
?>
<div class='nav' style='padding-left:5px;padding-top:5px;height:50px;'>  
     <table style="width:100%;">
        <tr>
            <td style="width:70%">
               <table  >
                    <tr>
                        <td rowspan="3" style='border-right:2px solid #666;padding:5px;'><img src='../assets/image/logo.png' class='nav-logo 'style='width:20px;height:20px;'/></td>
                        <td style='color:white;vertical-align:top;padding-left:5px;font-size:16px;font-weight:normal;'>
                            <img src="../assets/image/2.gif" class='loading' />
                            COMPUTERIZED CLASS RECORD v.<?php echo $version; ?></td>
                    </tr> 
                    <tr>
                        <td style='color:#ddd;vertical-align:top;padding-left:5px;font-size:12px;font-weight:normal;'>Southern Leyte State University - San Juan Campus | San Jose, San Juan, Southern Leyte</td>
                    </tr>
                </table> 
            
            </td>
            <td>
                
                  <table style="width:90%;"> 
                    <tr>
                        <td style='text-align:right;color:#ddd;vertical-align:top;padding-left:5px;font-size:10px;font-weight:normal;'><br /></td>
                    </tr>
                    <tr>
                        <td style='text-align:right;color:#ddd;vertical-align:top;padding-left:5px;font-size:10px;font-weight:normal;'> August 21, 2020</td>
                    </tr>
                </table> 
            </td>
         </tr>
    </table>
</div> 
<div class='sidebar' style="top:50px;"> 
    <div class='sidebar-btn'  style='border-top:1px solid white;'  onclick='gotoPage("index.php")'>
        <i class='fa fa-clipboard'></i> 
        <div class='sb-btn-title'>DASHBOARD</div>
    </div>     
    <div class='sidebar-btn' onclick='gotoPage("page-classes.php")'>
        <i class='fa fa-book-reader'></i> 
        <div class='sb-btn-title'>MY&nbsp;CLASSES</div>
    </div>   
    <div class='sidebar-btn' onclick='gotoPage("page-account.php")'>
        <i class='fa fa-user'></i> 
        <div class='sb-btn-title'>MY&nbsp;ACCOUNT</div>
    </div>  
    <div class='sidebar-btn' onclick='gotoPage("../index.php")'>
        <i class='fa fa-sign-out-alt'></i> 
        <div class='sb-btn-title'>SIGN&nbsp;OUT</div>
    </div>   
</div>
<script> 
function gotoPage(url){
     
        window.location.href=url; 
}  
function loading(n){
    if(n==0){
        $(".loading").hide();
    }else{

        $(".loading").show();
    }
}
function toPage(no){ 
    $(".page").slideUp()
    $("#page"+no).slideDown()
}

document.addEventListener("keyup", function (e) {
    var keyCode = e.keyCode ? e.keyCode : e.which;
            if (keyCode == 44) {
                stopPrntScr();
                msgShow("Warning: Screenshot has been detected","It is strictly prohibited for student to take a screenshot of this page..",2)
            }else{
                console.log(keyCode)
            }
        });
function stopPrntScr() {
            
            var inpFld = document.createElement("input");
            inpFld.setAttribute("value", ".");
            inpFld.setAttribute("width", "0");
            inpFld.style.height = "0px";
            inpFld.style.width = "0px";
            inpFld.style.border = "0px";
            document.body.appendChild(inpFld);
            inpFld.select();
            document.execCommand("copy");
            inpFld.remove(inpFld);
        }
       function AccessClipboardData() {
            try {
                window.clipboardData.setData('text', "Access   Restricted");
            } catch (err) {
            }
        }
        setInterval("AccessClipboardData()", 300);
</script>