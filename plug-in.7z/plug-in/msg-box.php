 <style> 
.msg-container{
    position: fixed;
    width: 0px;  
    top:0;
    right:0;
    background-color: red;
    z-index: 999999;
    height: 100vh;
    overflow: visible;
    cursor: pointer;
}
.msg-box{
    width: 485px;
    left:-485px;
    position: relative;
    margin-top:8px; 
    padding: 5px 10px;
    border-radius: 0px 0px 0px 0px;
    border:1px solid steelblue;
    border-left:10px solid steelblue;
    background-color: white;
    box-shadow: -1px 2px 2px rgba(0,0,0,.5);
}
.msg-heading{ 
    border-bottom:1px solid #d3d3d3;
    width:100%;
 }
.msg-box:hover{ 
    animation-duration: 0.9s;
}
.msg-info{ 
    color: #31708f; 
    border-left:10px solid steelblue;
}
.msg-success{
    color: #3c763d; 
    border-left:10px solid steelblue;
}
.msg-danger{
    color: #a94442; 
    border-left:10px solid steelblue;
}
.msg-warning{
    color: #8a6d3b; 
    border-left:10px solid steelblue;
}
.msg-title{
    font-weight: bold;
}
.msg-close{
    cursor: pointer;
}
.msg-close:hover{
    opacity: 0.7;
}
.msg-content{ 
    text-indent: 0px;
}
</style>
<div class='msg-container'></div>
<script> 
    var msgNo = 0;
    var msgs = [];
    function msgShow(title, content,type=0,extra=""){ 
        var types = ['success','info','warning','danger'];
        var faClasses= ['fa-check','fa-info','fa-clipboard','fa-times'];
        var faClass  = faClasses[type];
        var msg = " <div class='msg-box msg-"+types[type]+"' id='msgBox"+msgNo+"'><div class='row'><div class='col-sm-1' style='font-size:30px;'><i class='fa "+faClass+" '></i></div><div class='col-sm-11'><div class='msg-heading'><span class='msg-title'>"+title+"</span><i class='msg-close fa fa-times fa-fw pull-right' onclick='msgClose("+msgNo+")'></i></div><div class='msg-content'>"+content+"</div></div></div></div>";
        $(".msg-container").append(msg);
        $(".msg-container").append(extra);
        var n =msgNo;
        setTimeout(function(){
            msgClose(n)
        },8000);
        msgNo++; 
    } 
    function msgClose(no){
        $("#msgBox"+no).slideUp('fast');
    } 
</script>