
<style>
    .modal-container{ 
        position: fixed;
        top:0;
        width: 100%;
        height: 100%;
        background-color: rgba(0,0,0,0.8); 
        z-index: 10000;
        display: none; 
    }
    .modal-body{
        position: fixed; 
        width: 600px; 
        background-color: white;
        border-radius: 0px; 
        margin-top:20px;
        border:1px solid darkgreen;
        border-left:15px solid darkgreen;
    }
    .modal-heading{
        border-bottom: 1px solid #d3d3d3;
        padding: 0px;
        font-size: 18px;
        font-weight: bold;
        color: steelblue;
    }
    .modal-box{ 
        padding: 15px 5px;
        padding-bottom:0px;
        font-weight: normal;
        color: #666;
    }
    .modal-footing{ 
        border-top: 1px solid #d3d3d3;
        padding: 5px; 
        font-weight: bold;
        color: #666;
    }
    .modal-heading .fa:hover{
        cursor:pointer;
        opacity: 0.7;
    } 
</style>
<div class='modal-container' id='modal-container'  > 
    <div class='modal-body' id='modal-body'> 
    </div>
</div>

<script> 
    var prevHeight = document.getElementById("body").clientHeight; 
    function screenObserver(){
        var width = document.getElementById("body").clientWidth;
        var height = document.getElementById("body").clientHeight;
       //console.log(width,settedWidth)
        adjustModal(width,height);
        $(".page-content").css("height",(height-50)+"px");
        $("#index-page-conent").css("height",(height-100)+"px");
        $(".page-content").css("width",(width-35)+"px");
        $(".loading").css("left",((width/2)-50)+"px")
    } 
    var settedWidth = 600;
    function showModal(title,content,type, wd=0){
        $("#modal-body").css("height","auto");
        if(wd>0){
            settedWidth = wd;
            wd=0; 
            w = document.getElementById("body").clientWidth;
            var h = document.getElementById("body").clientHeight;
          //  adjustModal(w,h)
        }else{
            settedWidth = 600;
        }
        var cont = "<div class='modal-heading' id='modal' ><i class='fa fa-times fa-fw pull-right' onclick='closeModal()'></i><span id='modalTitle' >"+title+"</span></div><div class='modal-box' id='modalContent'>"+content+"</div>";
        var footer = "<div class='modal-footing text-right'><button class='btn btn-dafault btn-md' onclick='closeModal()'><i class='fa fa-times fa-fw'></i> Close</button></div>"; 
         
        $(".modal-container").slideDown(0);
        $(".modal-body").html(cont)
    } 
    
    function adjustModal(w,h){
        var ml = parseInt((w - settedWidth )/2); 
        var mdlHeight =  document.getElementById("modal-body").clientHeight; 
        //ml = 35;
        if(ml < 0 ){ 
            ml = 10;
            w  = w-20;
            $(".modal-body").css("width",w+"px");
            $(".modal-body").css("left",ml); 
        }else{
            $(".modal-body").css("left",ml); 
            $(".modal-body").css("width",settedWidth+"px");
        } 
        var top = h*0.02; 
        var bottom = h*0.2;
        if(prevHeight!=h||(top+mdlHeight)>=(h-(h*0.02))){ 
            prevHeight = h;
            if((top+mdlHeight)>=(h-(h*0.02))){  
                bottom =  (h*0.04);  
                mdlHeight = h - (top + bottom); 
                $("#modal-body").css("height",mdlHeight+"px");
                $("#modal-body").css("overflow-y","auto");

            }else{ 
                $("#modal-body").css("height","auto");
            }  
            setTimeout(function(){
                $("#modal-body").css("margin-top",top+"px")
            },100);
        }
    }
    
    setInterval(screenObserver,100);
     
    function closeModal(){
        $(".modal-container").slideUp(0);
    }
</script>