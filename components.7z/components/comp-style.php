<style>
    body{
        font-family: 'century gothic';
        font-size:12px; 
    }
    .no-rd, .btn{
        border-radius: 0px !important; 
    }
    .nav{
        position: fixed;
        z-index: 9999;
        background-color: steelblue; 
        padding-left: 30px;
        top:0;
        width:100%; 
    }
    .nav-btn-box{
        width:120px;
        height:100%;
        position: relative; 
        padding:5px;
        float: left;
    }
    
    .nav-btn{
        width:100%;
        height:100%;
        position: relative;
        border:2px solid black;
        background-color: white;
        border-radius: 5px;
        float: left;
        font-size: 40px;
        text-align: center;
        color: steelblue;
        text-shadow: 2px 2px 2px black;
        padding:5px;
    }
    .nav-btn div{
        font-size:12px;
        color: black;
        text-transform: uppercase;
        margin-top:4px;
        text-shadow: 2px 1px 2px steelblue;
        border-top: 1px solid steelblue;
        
        font-weight: bold;
    }
    .nav-btn:hover{
        transition-duration: 0.5s;
        cursor: pointer;
        background-color: lightsteelblue; 
    } 
    .nav-logo{
        border-radius: 50%;
        height:60px;
        width:60px;
    }
    .sidebar{
        width:35px; 
        height:100%;
        top:100px;
        position: fixed;
        left: 0;
        z-index: 9998;
        background-color: steelblue; 
        
    }
    .sidebar-btn{
        width:100%;
        position: relative;
        color: white;
        padding: 10px; 
        border-bottom:1px solid #d3d3d3;
        text-transform: uppercase;  
    }
    .sidebar-btn-active{
        width:100%;
        position: relative;
        color: white;
        padding: 10px; 
        border-bottom:1px solid #ffffff; 
        text-transform: uppercase;  
        background-color: #ffffff;
        color: black;
    }
    .sidebar-btn:hover,  .sidebar-btn-active:hover{
        cursor: pointer;
        background-color: white;  
        color: steelblue;
        font-weight: bold;
        transition-duration: 0.8s;
    }
    .sb-btn-title{
        background-color: steelblue;
        position:absolute;
        top: -1;
        left: 35px; 
        padding: 7px;
        padding-left:5px;
        border-bottom: 1px solid white; 
        display: none;
        border-radius: 0px 15px 0px 0px;
    }
    .sidebar-btn:hover .sb-btn-title{
        display: block;
        background-color:white;
        color: steelblue;
        font-weight: bold;
        transition-duration: 0.8s;
        border:1px solid steelblue;
        border-left:0px solid steelblue;
    }
    .page-content{
        top: 50px;
        padding:5px;
        padding-bottom:25px;
        margin-left:35px;
        background-color: #ffffff;
        position: fixed;
        left:0px;   
        width:100%;   
    }
    .page-label{
        font-size: 20px;
        font-weight: bold;
        color: steelblue;
        border-bottom: 3px solid steelblue;
        width: 100%;
    }
    .loading{ 
        position: fixed;
        top:200px;
        width: 105px;
        height: 105px; 
    }
    .table-list{
        font-size:13px; 
    }
    .td-freezed{
        top: 0;
        position: sticky;
        z-index: 20;
    }
    .table-list tr:first-child td{
        font-weight: bold;
        border-bottom: 2px solid steelblue;
        color: steelblue;
    }
    .table-list td{
        padding:2px 3px;
        border-bottom: 1px solid steelblue;
    }
    .tr:hover{
        transition-duration: 0.3s;
        cursor: pointer;
        background-color: lightgray;
        color: black;
    }
    .td-input{
        outline: none;
        border: none;
        border-radius: 0px;
        width:100%; 
    }
    .td-ruler:hover td{
        border-bottom:2px solid black;
        border-top:2px solid black;
        cursor: pointer;
    }
    .no-rd{
        border-radius: 0px;
    }
    .no-brd{
        border: none;
    }
    .ctr{
        text-align: center;
        
    } 
    .right{
        text-align: right;
        
    } 
    .left{
        text-align: left;
        
    }
    .br{
        height:5px;
    }
    .bld{
        font-weight: bold;
    }
    .input{
       border:1px solid steelblue;
      padding:5px;
    }
    .input:focus{
       border:1px solid steelblue;
       padding:5px; 
       outline: none;
    } 
    .ver {
      transform: rotate(180deg);
      -webkit-transform: rotate(180deg);
      -ms-transform: rotate(180deg);
      -moz-transform: rotate(180deg); 
      writing-mode: tb-rl; 
      text-align: center; 
    }
   .num{
        height:10px;
        width: 8px;
    }
    /* .pHide{ 
    } */
    @media print{
        .nav, .sidebar, .pHide{
            display: none;
        }
        .td-ruler{
            border:none;
        }
    }
</style>