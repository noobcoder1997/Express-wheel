
<?php 
    //satrting session 
    session_start();
    
    //SET DEFAULT TIME ZONE
    date_default_timezone_set("Asia/Manila");
    $date0  = date("m-d-y");
    $date1  = date("m-d-Y"); 
    $date2  = date("Y-m-d"); 
    $month0 = date("F");
    
    //DATABASE CONNECTION 
    $db_hostname = "localhost";//sql304.infinityfree.com
    $db_name = "u998327346_noobcoder";//if0_36597474_db_expresswheel
    $db_user = "root";//if0_36597474  u998327346_noobcoder  
    $db_pass = ""; //noobCoder1234      opF056xYR6cget
    
    $conn = mysqli_connect($db_hostname, $db_user, $db_pass, $db_name) OR die(mysqli_error($this->conn));
    
    //echo "INCLUDED";
?> 