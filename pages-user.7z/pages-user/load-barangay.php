<?php
//  session_start();
    include( '../components/comp-conn.php');

    // $municipal_code = htmlentities($_POST['city']);

    $id = htmlentities($_POST['brgy']);
    $municipal_code0 = '086414'; 
    $municipal_code1 = '086412';
    
    $query0 = mysqli_query($conn, "select * from tbl_brgy_position where brgy_id <> '$id' ");
    while($row0 = mysqli_fetch_assoc($query0)){

        $query = "select * from tbl_brgy where (citymunCode = '$municipal_code0' or citymunCode = '$municipal_code1') and id = '$row0[brgy_id]'";
        $brgy = mysqli_query($conn, $query);
        
        while($row = mysqli_fetch_assoc($brgy)){
            echo "<option value='$row[id]'>$row[brgyDesc]</option>";
        }
    }
    
?>