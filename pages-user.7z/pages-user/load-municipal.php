<?php
//  session_start();
    include( '../components/comp-conn.php');

    // $province_code = htmlentities($_POST['province']); 
    // citymunCode = 086414 -> san juan cabalian 
    
    $query = "select * from refcitymun where citymunCode = '086414'";
    $province = mysqli_query($conn, $query);
    
    while($row = mysqli_fetch_assoc($province)){
        echo "<option value='$row[citymunCode]'>$row[citymunDesc]</option>";
    }
?>