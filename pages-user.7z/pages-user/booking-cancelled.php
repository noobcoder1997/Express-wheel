<?php
    include '../components/comp-conn.php';
    
    $q = mysqli_query($conn, "select * from tbl_book_ride where status = '3' and rider_status = '3' and id = '$_POST[id]' ");
    if(mysqli_num_rows($q) > 0){
        echo 1;
    }

?>