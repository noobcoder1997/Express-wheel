<?php
    include '../components/comp-conn.php';
    
    $q = mysqli_query($conn, "select * from tbl_book_ride where id = '$_POST[id]' ");
    while($row = mysqli_fetch_assoc($q)){
        
        if($row['status'] == '3' && $row['rider_status'] == '3' && $row['cancel_code'] == '1'){
            echo 1;
        }        
    }

?>