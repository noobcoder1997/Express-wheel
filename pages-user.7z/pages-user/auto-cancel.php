<?php
    include '../components/comp-conn.php';
    
    $id = $_POST['passenger_id'];
    $latest_id = $_POST['latest_id'];
    
    $query = mysqli_query($conn, "select * from tbl_book_ride where passenger_id = '$id' and rider_id = '' and  status='0' and rider_status='0' and  id = '$latest_id' ");
    if(mysqli_num_rows($query) > 0){
        while($row=mysqli_fetch_assoc($query)){
            // mysqli_query($conn, "delete from tbl_book_ride where id = '$row[id]' ");
            mysqli_query($conn, "update tbl_book_ride set status = '3', rider_status ='3' where id = '$row[id]' ");
        }
    }
?>