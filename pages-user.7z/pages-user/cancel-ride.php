<?php
    include '../components/comp-conn.php';
    
    $latest_id = $_POST['latest_id'];
    $from = $_POST['from'];
    $to = $_POST['to'];
    $date = date('y-m-d').' '.date('h:i:s');
    $passenger_id = $_POST['passenger_id'];

    mysqli_query($conn, "update tbl_book_ride set status = '3', rider_status = '3', cancel_code = '0' where id = '$latest_id' and passenger_id = '$passenger_id' ");

    if(!empty($_POST['rider_id']) || $_POST['rider_id'] != ''){
        mysqli_query($conn, "insert into tbl_transactions (passenger_id,_from,_to,date,rider_id) values ('$passenger_id','$from','$to','$date','$_POST[rider_id]' "); 
    }
    else{
        mysqli_query($conn, "insert into tbl_transactions (passenger_id,_from,_to,date,status) values ('$passenger_id','$from','$to','$date','-1') ");    
    }
?>