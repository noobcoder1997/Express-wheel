<?php
    include "../components/comp-conn.php";
    $success=0;
    $number=0;
    $sender_id = htmlentities($_POST['sender-id']);
    $sender_name = htmlentities($_POST['sender-name']);
    $sender_contact = htmlentities($_POST['sender-contact']);
    $sender_brgy = htmlentities($_POST['sender-barangay']);
    $sender_city = htmlentities($_POST['sender-city']); 
    $sender_prov = htmlentities($_POST['sender-province']);
    $sender_landmark = htmlentities($_POST['sender-landmark']);
    
    $recipient_name = htmlentities($_POST['recipient-name']);
    $recipient_contact = htmlentities($_POST['recipient-contact']);
    $recipient_brgy = htmlentities($_POST['recipient-barangay']);
    $recipient_city = htmlentities($_POST['recipient-city']); 
    $recipient_prov = htmlentities($_POST['recipient-province']);
    $recipient_landmark = htmlentities($_POST['recipient-landmark']);
    
    $item_name = htmlentities($_POST['item-name']);
    $item_others = htmlentities($_POST['item-others']);
    $item_weight = htmlentities($_POST['item-weight']);
    $item_quantity = htmlentities($_POST['item-quantity']);
    
    $item_value = htmlentities($_POST['item-value']);
    $item_length = htmlentities($_POST['item-length']);
    $item_width = htmlentities($_POST['item-width']);
    
    $item_height = htmlentities($_POST['item-height']);
    $item_service_type = htmlentities($_POST['item-service-type']);
    $item_package_type = htmlentities($_POST['item-package-type']); // selected option text in select tag
    
    $item_delivery_type = htmlentities($_POST['item-delivery-type']); // selected option text in select tag
    $item_scheduled = htmlentities($_POST['item-scheduled']);   // date for schedule
    $item_fee = htmlentities($_POST['item-fee']);
    
    $item_remarks = htmlentities($_POST['item-remarks']);
    // $branch_id = htmlentities($_POST['branch-id']);
    
    $message = "";
    
    if(strlen($recipient_contact) != 11 && $recipient_contact <> ''){
        $message = "<div class='alert alert-warning'>";
        $message .= "<strong>Warning:</strong> Invalid Contact Number! Please try again.";
        $message .= "</div>";
    }
    else if($item_weight > 50){
        $message = "<div class='alert alert-warning'>";
        $message .= "<strong>Warning:</strong> You have reached the maximum maximum of 50KG.";
        $message .= "</div>";
    }
    else if($item_height > 30 || $item_width > 30 || $item_length > 30){
        $message = "<div class='alert alert-warning'>";
        $message .= "<strong>Warning:</strong> You have reached the maximum of 30CM.";
        $message .= "</div>";
    }
    else if($item_delivery_type == 'Scheduled' && ($item_scheduled == null || ($item_scheduled == ''))){
        $message = "<div class='alert alert-warning'>";
        $message .= "<strong>Warning:</strong> Please enter date of delivery!";
        $message .= "</div>";
    }
    else if($item_name == 'Others;' && ($item_others == '' || $item_others == null)){
        $message = "<div class='alert alert-warning'>";
        $message .= "<strong>Warning:</strong> Please enter description of the item!";
        $message .= "</div>";
    }
    else if($sender_name == '' || 
            $sender_contact == '' ||
            $sender_brgy == '' || 
            $sender_city == '' || 
            $sender_prov == '' ||
            $recipient_name == '' || 
            $recipient_contact == '' ||
            $recipient_brgy == '' || 
            $recipient_city == '' || 
            $recipient_prov == '' || 
            $item_name == '' || 
            $item_weight == '' ||
            $item_quantity == '' ||
            $item_value == '' || 
            $item_length == '' ||
            $item_width == '' ||
            $item_height == '' || 
            $item_service_type == '' ||
            $item_package_type == '' ||
            $item_delivery_type == '' ||
            $item_fee == '' || 
            $item_remarks == ''){
                
        $message = "<div class='alert alert-warning'>";
        $message .= "<strong>Warning:</strong> Fields should not leave empty! Please try again.";
        $message .= '<a class="close" data-dismiss="alert">&times</a>';
        $message .= "</div>";
    }
    else{    
        $number = rand(1000000,5000000);
        
        $stmt = $conn->prepare("INSERT INTO tbl_user_make_order (order_number, sender_id, sender_name, sender_contact, sender_barangay, sender_city, sender_province, recipient_name, recipient_contact, recipient_barangay, recipient_city, recipient_province, item_name, item_others_desc, item_quantity, 	item_weight, item_value, item_length, item_width, item_height, service_type, package_type, delivery_type, item_scheduled, fee, remarks, sender_landmark, recipient_landmark) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?) ");
        $stmt->bind_param("ssssssssssssssssssssssssssss",$number,$sender_id,$sender_name,$sender_contact,$sender_brgy, $sender_city, $sender_prov,$recipient_name,$recipient_contact,$recipient_brgy, $recipient_city, $recipient_prov,$item_name,$item_others,$item_quantity,$item_weight,$item_value,$item_length,$item_width,$item_height,$item_service_type,$item_package_type,$item_delivery_type,$item_scheduled,$item_fee,$item_remarks,$sender_landmark,$recipient_landmark);
        $stmt->execute();
        
        $message = "<div class='alert alert-success'><input style='display: none' value='$number' id='myInput'>";
        $message .= "<strong>Order Successful:</strong> You have created an order! <br> Your Order Number:";
        $message .= "<h1 style='font-weight:bolder' id='text-to-copy'>".$number."<a class='btn btn-default badge' onclick='copyToClipboard()'><span class='fa fa-copy' ></span> copy</a></h1>";
        $message .= "<h4><strong style='color:#000'>Your Order is still pending! Please save your Order number as your tracking reference.</strong></h4>";
        $message .= "</div>";
        $success=1;
    }
    
    echo json_encode([$message, $success, $number]);
?>

