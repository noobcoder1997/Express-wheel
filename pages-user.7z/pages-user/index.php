<!DOCTYPE html>
<HTML> 
<head> 
<TITLE>Wheel Express</TITLE>  
<link rel="icon" href="../assets/image/eMove.png">
<meta name="viewport" content="width=device-width, initial-scale=1.0"> 
<link rel="stylesheet" href="../lib/bootstrap/css/bootstrap.css">
<link rel="stylesheet" href="../lib/bootstrap/css/bootstrap.min.css">
<link rel="stylesheet" href="../lib/font-awesome-5/css/all.css">
<link rel="stylesheet" href="https://cdn.datatables.net/2.2.1/css/dataTables.dataTables.min.css">
<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.3/dist/leaflet.css" integrity="sha256-kLaT2GOSpHechhsozzB+flnD+zUyjE2LlfWPgU04xyI=" crossorigin="" />
<link rel="stylesheet" href="https://unpkg.com/leaflet-routing-machine@latest/dist/leaflet-routing-machine.css" />
<script src="../lib/jquery/jquery-1.11.3.js"></script>
<script src="../lib/bootstrap/js/bootstrap.min.js"></script>
<script src="https://cdn.datatables.net/2.2.1/js/dataTables.min.js"></script>
<script src="https://unpkg.com/leaflet@1.9.3/dist/leaflet.js" integrity="sha256-WBkoXOwTeyKclOHuWtc+i2uENFpDZ9YPdf5Hf+D7ewM=" crossorigin=""></script>
<script src="https://unpkg.com/leaflet-routing-machine@latest/dist/leaflet-routing-machine.js"></script>
<?php
    include "../components/comp-conn.php"; 
    // session_start();
    if(!isset($_SESSION['user_status'])){
        header('location: ../');
    }
    else{
        $userNo = $_SESSION['userNo'];
    } 
    
    $userQry = mysqli_query($conn,"SELECT * FROM tbl_user WHERE no='$userNo' ")or die(mysqli_error($conn));
    $userRw  = mysqli_fetch_assoc($userQry);
?>
</head>
<style>
    #map, #covermap { 
        height: 350px;
        background: #fff;
        box-shadow: 0 0 15px 0 #000;
        border-radius: 5px;
    }
    
    img.end_huechange { filter: hue-rotate(270deg); }
    img.start_huechange { filter: hue-rotate(150deg); }
</style>
 <style>
  body {
    font: 400 15px Lato, sans-serif;
    line-height: 1.8;
    color: #818181;
    font-family: 'century gothic';
  }
  h2 {
    font-size: 24px;
    text-transform: uppercase;
    color: #303030;
    font-weight: 600;
    margin-bottom: 30px;
  }
  h4 {
    font-size: 19px;
    line-height: 1.375em;
    color: #303030;
    font-weight: 400;
    margin-bottom: 30px;
  }  
  .jumbotron {
    background-color: #414c50;
    color: #192428;
    padding: 40px 25px;
    padding-top:70px;
    font-family: Montserrat, sans-serif;
  }
  .container-fluid {
    padding: 40px 50px;
    width:100%;
    margin:0;
    position: relative;
  }
  .bg-grey {
    background-color: #414c50;
    color: #39ace7;
  }
  .logo-small {
    color: #192428;
    font-size: 50px;
  }
  .logo {
    color: darkgreen;
    font-size: 200px;
  }
  .thumbnail {
    padding: 0 0 15px 0;
    border: none;
    border-radius: 0;
  }
  .thumbnail img {
    width: 100%;
    height: 100%;
    margin-bottom: 10px;
  }
  .prod:hover{
     border:2px solid grey;
      cursor: pointer;
      transition-duration: .5s;
  }
  .carousel-control.right, .carousel-control.left {
    background-image: none;
    color: darkgreen;
  }
  .carousel-indicators li {
    border-color: darkgreen;
  }
  .carousel-indicators li.active {
    background-color: darkgreen;
  }
  .item h4 {
    font-size: 19px;
    line-height: 1.375em;
    font-weight: 400;
    font-style: italic;
    margin: 70px 0;
  }
  .item span {
    font-style: normal;
  }
  .panel {
    border: 1px solid darkgreen; 
    border-radius:0 !important;
    transition: box-shadow 0.5s;
  }
  .panel:hover {
    box-shadow: 5px 0px 40px rgba(0,0,0, .2);
  }
  .panel-footer .btn:hover {
    border: 1px solid darkgreen;
    background-color: #fff !important;
    color: darkgreen;
  }
  .panel-heading {
    color: #fff !important;
    background-color:darkgreen !important;
    padding: 25px;
    border-bottom: 1px solid transparent;
    border-top-left-radius: 0px;
    border-top-right-radius: 0px;
    border-bottom-left-radius: 0px;
    border-bottom-right-radius: 0px;
  }
  .panel-footer {
    background-color: white !important;
  }
  .panel-footer h3 {
    font-size: 32px;
  }
  .panel-footer h4 {
    color: #aaa;
    font-size: 14px;
  }
  .panel-footer .btn {
    margin: 15px 0;
    background-color:darkgreen;
    color: #fff;
  }
  .navbar {
    margin-bottom: 0;
    background-color: #192428;
    z-index: 9999;
    border: 0;
    font-size: 12px !important;
    line-height: 1.42857143 !important;
    letter-spacing: 4px;
    border-radius: 0;
    font-family: Montserrat, sans-serif;
  }
  .navbar li a, .navbar .navbar-brand {
    color: #fff !important;
  }
  .navbar-nav li a:hover, .navbar-nav li.active a {
    color: #192428 !important;
    background-color: #fff !important;
  }
  .navbar-default .navbar-toggle {
    border-color: transparent;
    color: #fff !important;
  }
  footer .glyphicon {
    font-size: 20px;
    margin-bottom: 10px;
    color: #192428;
  }
  .slideanim {visibility:hidden;}
  .slide {
    animation-name: slide;
    -webkit-animation-name: slide;
    animation-duration: 1s;
    -webkit-animation-duration: 1s;
    visibility: visible;
  }
  @keyframes slide {
    0% {
      opacity: 0;
      transform: translateY(70%);
    } 
    100% {
      opacity: 1;
      transform: translateY(0%);
    }
  }
  @-webkit-keyframes slide {
    0% {
      opacity: 0;
      -webkit-transform: translateY(70%);
    } 
    100% {
      opacity: 1;
      -webkit-transform: translateY(0%);
    }
  } 
    p#order, p#track{
        margin: 50px 0;font-weight:bold; font-size:60px;
    }
    .order-icon, .track-icon, .ride-icon{
        font-size:70px
    }
    .card{
        background: #fff;
        border: 1px solid grey;
        border-radius: 15px;
        box-shadow: 0 0 15px 0 #000;
    }
  @media screen and (max-width: 480px) {
    .logo {
      font-size: 150px;
    }
    body{
        width: 100%;
    }
    .order{
        margin:15px 0 0 0 ;
    }
    p#order, p#track{
        font-size:50px;
        margin: 0;
    }
    .order-icon, .track-icon, .ride-icon{
        font-size:50px
    }
  }
  
    .cat-btn{
        background-color: white;
    }
    .cat-btn:hover{ 
        border:1px solid black;
        background-color: lightgreen;
        cursor: pointer;
        transition-duration: 1s;
        
    }
    .star-checked{
        color: #0784b5;
    }
    .stars{
        font-size: 30px;
    }
    .btn-block{
        width: 100%;
    }
    .btn:hover, .btn:active{
        transform: scale(1.03);
    }
    .my-btn:active, .my-btn:hover{
        transform: scale(1.06);
    }
    .nav-btn:active, .nav-btn:hover{
        transform: scale(1.5);
    }
    .btn{
        font-weight: bold;
    }
    .ratings{ display:none; color:#fff }
</style>
</head>
<!-- -->
<body id="myPage" data-spy="scroll" data-target=".navbar" data-offset="60">

<nav class="navbar navbar-default navbar-fixed-top">
  <div class="container">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
      <a class="navbar-brand" href="#myPage">
          <table>
              <tr>
                  <td> 
                    <img src='../assets/image/eMove.png' style=' height:25px; border-radius:50%;' /> 
                     
                  </td>
                  <td style='color:white;font-weight:bold;'>&nbsp;<?php  echo $userRw['user'];?></td>
                  <input type='hidden' id='userNo' value='<?php echo $userNo;?>' /> 
              </tr>
          </table>
      </a>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
        <ul class="nav navbar-nav navbar-right">
            <li><a class="my-btn" href="index.php"><span class='fa fa-home fa-fw'></span>&nbsp;HOME</a></li>
            <li><a class="my-btn" href="my-trasaction.php"><span class='fas fa-clipboard-check fa-fw'></span>&nbsp;HISTORY<sup id="sup_history"></sup></a></li>
            <li><a class="my-btn" href="my-notifications.php"><span class='fas fa-bell fa-fw'></span>&nbsp;NOTIFICATIONS<sup id="sup_notif"></sup></a></li>
            <li><a class="my-btn" href="my-account.php"><span class='fa fa-user fa-fw'></span>&nbsp;ME</a></li>
            <li><a class="my-btn" data-target="#logout-modal" data-toggle="modal"><span class='fa fa-sign-out-alt fa-fw'></span>&nbsp;EXIT</a></li>
        </ul>
    </div>
  </div>
</nav>

<div class="jumbotron text-center">
    <BR />
    <br />
    <div class='row'>
        <div class='col-sm-6' >   
        <img src='../assets/image/eMove.png' style='height:100px; border-radius:50%;margin-top:-30px;' />
        <strong style='font-size:45px;color:#39ace7'>Express&nbsp;Wheel</strong> 
        </div>
        <div class='col-sm-6'> 
            <div class='row' style='font-size:2em; font-family: "Comic Sans MS"; color: white '>
                <div class='col-sm-12'> 
                Connecting communities, delivering convenience
                </div> 
            </div>
        </div>
    </div> 
</div> 
<script>
var pickup_at;
var dropoff_at;
var note;
var instruction;
var fare;
</script>

<!-- Container () -->
<div id="order" class="container-fluid bg-grey"  style="margin:0; padding:0">
    <div class="row" style="margin-bottom: 20px;margin-top:20px;margin-left:5px;margin-right:5px">
        <div class="col-sm-4" style="color:#0784b5">
            <div class="card">
              <!--<div class="card-header" style='background:darkgrey; margin:0;padding:0'>-->
              <!--    <h1>&nbsp;</h1>-->
              <!--</div>-->
              <div class="card-body text-center">
                <div class="row">   
                    <div class="col-sm-12">
                        <div class="form-group">
                            <span class="btn my-btn" data-toggle="modal" data-target="#book-ride">
                                <p id="order"><span class='fas fa-map-marker-alt ride-icon'></span> Ride
                                <br>
                                <i style="font-size: 18px;font-weight:normal;margin-left: 10px">Book a ride</i>
                                </p> 
                            </span> 
                                <!-- The Modal -->
                                <div class="modal" id="book-ride" style='z-index:999999; color:#0784b5' data-keyboard="false" data-backdrop="false">
                                  <div class="modal-dialog">
                                    <div class="modal-content">
                                
                                      <!-- Modal Header -->
                                      <div class="modal-header">
                                         <!--<button type="button" class="close" data-dismiss="modal">&times;</button>-->
                                        <h4 class="modal-title" style='font-weight:bold; color:#192428'>
                                            <img src='../assets/image/eMove.png' style='height:40px; border-radius:50%;' />
                                            Express Wheel | Book a ride
                                        </h4>
                                      </div>
                                       
                                      <!-- Modal body -->
                                      <div class="modal-body" style="text-align:Left">
                                        <div class="row"> 
                                            <div class="col-sm-12">
                                                <p>Pick up at:</p>
                                                <select id="_select-barangay-0" class="form-control" onchange="load_barangay()">
                                                    <option value="42031">San Juan Bus Terminal</option>
                                                    <option value="42032">St. Bernard Bus Terminal</option>
                                                </select>
                                                <script>
                                                    $(document).ready(() => {
                                                        load_barangay();
                                                    });
                                                    
                                                    function rideSelect(){
                                                        pickup_at = $("#_select-barangay-0").val();
                                                        dropoff_at = $("#_select-barangay-1").val();
                                                        form = new FormData();
                                                        form.append('pickup',pickup_at);
                                                        form.append('dropoff',dropoff_at);
                                                        form.append('ride',true);
                                                        $.ajax({
                                                            data:form,
                                                            type:'post',
                                                            url: 'fare.php',
                                                            cache:false,
                                                            contentType:false,
                                                            processData:false,
                                                            beforeSend:()=>{},
                                                            success:(data)=>{
                                                                if(data != ''){
                                                                   $('#ride-fare').val(data);
                                                                    fare = data; 
                                                                }
                                                            },
                                                            error: (data)=>{
                                                                console.log(data);
                                                            }
                                                        }).done(() => {
                                                            $('#submit-book-rider-btn').removeProp('disabled');
                                                        });
                                                    }
                                                    
                                                    // Load barangay based on selected city
                                                    function load_barangay(){
                                                        $.ajax({
                                                            url: 'load-barangay.php',
                                                            type: 'post',
                                                            data: { 'brgy': $('#_select-barangay-0').val() },
                                                            success: (data) => {
                                                                $('#_select-barangay-1').html(data);
                                                                rideSelect();
                                                            }
                                                        });
                                                    }
                                                </script>
                                                <p>Drop off at:
                                                <select id="_select-barangay-1" class="form-control" onchange="rideSelect()"></select>
                                                <p>Fare:</p>
                                                <span style="position:fixed;padding-left:10px;margin:3px;color:#000" style="font-size:16px">&#8369;</span>
                                                <input id="ride-fare" class="form-control" style="text-indent: 10px;" disabled/>
                                                <p>Note:</p>
                                                <textarea class="form-control" rows="3" id="br-note" placeholder="E.g. a landmark, or beside a building"></textarea>
                                                <p>Instruction:</p>
                                                <textarea class="form-control" rows="3" id="br-instruction" placeholder="E.g. Bring raincoat"></textarea>
                                            </div>
                                        </div>
                                        <br>
                                        <span id="book-ride-message"></span>
                                    </div>
                                        <!-- Modal footer -->
                                      <div class="modal-footer">
                                        <div class="row">
                                            <div class="col-sm-12">
                                                <button type="button" class="btn btn-danger btn-block" id="submit-book-rider-btn" disabled>Book</button> 
                                                <button type="button" class="btn btn-default btn-block" data-dismiss="modal">Close</button> 
                                                <script>
                                                    
                                                    $("#submit-book-rider-btn").on('click', ()=>{
                                                        $('#fare').html('Final Fare: &#8369;'+fare);
                                                        note = $("#br-note").val();
                                                        instruction = $("#br-instruction").val();
                                                        // $('#book-ride-alert').html("<div class='alert alert-warning'><strong>Finding your Rider:</strong> Please wait for a moment!</div>");    
                                                        $('#book-ride').modal('toggle');
                                                        $('#find-rider').modal('toggle');
                                                        
                                                        $('#pickup').html("Pick up at: "+$("#_select-barangay-0 :selected").text());
                                                        $('#dropoff').html("Drop off at: "+$("#_select-barangay-1 :selected").text());
                                                        
                                                    }).attr("data-dismiss","modal");
                                                </script>
                                            </div>
                                        </div>
                                      </div>
                                  </div>
                                </div>
                            </div>
                            
                                <!-- The Modal -->
                                <div class="modal" id="find-rider" style='z-index:999999'  data-keyboard="false" data-backdrop="false">
                                  <div class="modal-dialog">
                                    <div class="modal-content">
                                
                                      <!-- Modal Header -->
                                      <div class="modal-header">
                                         <!--<button type="button" class="close" data-dismiss="modal">&times;</button>-->
                                        <h4 class="modal-title" style='font-weight:bold; color:#192428'>
                                            <img src='../assets/image/eMove.png' style='height:40px; border-radius:50%;' />
                                            Express Wheel | Book a ride
                                        </h4>
                                      </div>
                                
                                      <!-- Modal body -->
                                      <div class="modal-body to-arrive" style="text-align:Left">
                                        <div class="row">
                                            <div class="col-sm-4 text-center">
                                                <img src="../assets/image/user.png" class="img-circle elevation-2" alt="Profile Photo" style="width:100px; height:100px; object-fit: fill; position: flex; margin-left: 10px;"> 
                                                <div style="margin-left: 10px;" class="ratings">
                                                    <span class="fa fa-star" id="s1"></span>
                                                    <span class="fa fa-star" id="s2"></span>
                                                    <span class="fa fa-star" id="s3"></span>
                                                    <span class="fa fa-star" id="s4"></span>
                                                    <span class="fa fa-star" id="s5"></span>
                                                </div> 
                                            </div>
                                            <div class="col-sm-12">
                                                <p></p>
                                                <p id="rider">Rider Name:</p>
                                                <!--<p id="">Tip your rider</p>-->
                                                <p id="pickup">Pick up at:</p>
                                                <p id="dropoff">Drop off at:</p>
                                                <p id="fare">Final Fare: &#8369; <?php echo number_format((float)$fare, 2, '.', ''); ?></p>
                                            </div>
                                        </div>

                                        <span id="book-ride-alert"></span>

                                        <div id="map"></div>
                                
                                     </div>
                                      <!-- Modal footer -->
                                      <div class="modal-footer">
                                            <div class="row">
                                                <div class="col-sm-12">
                                                    <button type="button" class="btn btn-default btn-block" data-dismiss="modal" id="btn_cancelBooking">Cancel Booking</button>
                                                </div>
                                            </div>
                                      </div>
                                  </div>
                                </div>
                            </div>
                            <script>
                                var timeleft;
                                var downloadTimer;
                                
                                //Finding rider 
                                $('#find-rider').on('shown.bs.modal', () => {
                                    
                                    timeleft=0;
                                    
                                    findRider(); //Insert data to table tbl_book_ride
                                    
                                    $("#book-ride-alert").html('');
                                    
                                    downloadTimer = setInterval(function(){ 
                                    
                                        $("#book-ride-alert").html("<div class='alert alert-warning'><strong>Finding your Rider:</strong> Please wait for a moment!</div>");
                                        
                                        //cancel the booking if no rider has accepted the booking in 30 seconds
                                        if(timeleft >= 30){
                                            clearInterval(downloadTimer);
                                            
                                            form = new FormData();
                                            form.append('passenger_id',<?php echo $userNo; ?>);
                                            form.append('latest_id',$('#last_id').val());
                                            $.ajax({
                                                data: form,
                                                type: 'post',
                                                url: 'auto-cancel.php',
                                                processData:false,
                                                contentType:false,
                                                cache:false,
                                            }).done(()=>{
                                                $('#find-rider').modal('toggle');
                                                alert('No Rider is around!');
                                                history.go(0);                                                
                                            });
                                        }
                                        
                                        timeleft += 1;
                                    }, 1000);
                                });
                                
                                // booking cancellation process
                                $("#btn_cancelBooking").on('click', () => {

                                    clearInterval(downloadTimer);

                                    pickup_at=$("#_select-barangay-0 :selected").text();
                                    dropoff_at=$("#_select-barangay-1 :selected").text()

                                    form = new FormData();
                                    form.append('passenger_id',<?php echo $userNo; ?>);
                                    form.append('latest_id',$('#last_id').val())
                                    form.append('from',pickup_at)
                                    form.append('to',dropoff_at)
                                    form.append('rider_id', $('#rider_id').val())
                                    $.ajax({
                                        data:form,
                                        type:'post',
                                        url:'cancel-ride.php',
                                        processData:false,
                                        contentType:false,
                                        cache:false,
                                    }).done(()=>{
                                        alert('You have cancelled the booking...');
                                        history.go(0);
                                    });      
                                })
                                  
                                // Rider accepts the booking
                                i=1;
                                setInterval(() => {
                                    pickup_at = $("#_select-barangay-0").val();
                                    dropoff_at = $("#_select-barangay-1").val();
                                    note = $("#br-note").val();
                                    instruction = $("#br-instruction").val();
                                    
                                    form = new FormData(); 
                                    form.append('id',<?php echo $userNo; ?>);
                                    form.append('pick-up',pickup_at);
                                    form.append('drop-off',dropoff_at);
                                    form.append('note',note);
                                    form.append('instruction',instruction);
                                    $.ajax({
                                        data:form,
                                        url: 'accept-booking.php',
                                        method: 'post',
                                        contentType: false,
                                        processData: false,
                                        cache:false,
                                        dataType: 'json',
                                        success: (data)=>{
                                            $('#book-ride-alert').html(data[1]);
                                            $('#rider').html('Rider Name: '+data[0])
                                            $('#tbl_id').val(data[2]); // table id of the row
                                            $('#rider_id').val(data[3]);
                                            $('#do_lat').val(data[4]);
                                            $("#do_lng").val(data[5]);
                                            $('#pu_lat').val(data[6]);
                                            $("#pu_lng").val(data[7]);

                                            $('.ratings').css('display', 'block');

                                            if(data[3] != null){ // rider is not null
                                                clearInterval(downloadTimer);
                                            }
                                        }
                                    }).done((data)=>{
                                        $('.ratings').css('display', 'block');

                                        if(data[8] != 0){

                                            while(i <= 5){
                                                
                                                (i > data[8]) ? $('#s'+i).css('color', 'lightgray') : $('#s'+i).css('color', '#0784b5');
                                                i++;
                                            }
                                        }
                                        else{
                                            while(i <= 5){
                                                
                                                $('#s'+i).css('color', 'lightgray');
                                                i++;
                                            }
                                        }
                                    });
                                    
                                }, 1000);
                                
                                // watch rider positioning every 5 seconds
                                setInterval(() => {
                                    
                                    if($('#rider_id').val() != ''){
                                        form = new FormData(); 
                                        form.append('id',$('#rider_id').val());
                                        $.ajax({
                                            data:form,
                                            url: 'watch-rider.php',
                                            method: 'post',
                                            contentType: false,
                                            processData: false,
                                            cache:false,
                                            dataType: 'json',
                                            success: (data)=>{
                                                $('#rider_lat').val(data[0]);
                                                $('#rider_lng').val(data[1]);
                                            },
                                        }).done((data)=>{
                                            $('#map').load(self)
                                            track_rider_map.invalidateSize();
                                            navigator.geolocation.getCurrentPosition(success, error)
                                        }); 
                                    }
                                }, 5000); //updates every 5 seconds
                                
                                // Removes the cancel button if the passenger is on board...
                                endTimer = setInterval(()=>{
                                    if($('#rider_id').val() != ''){
                                        $.ajax({
                                            data:'id='+$('#tbl_id').val(),
                                            type:'post',
                                            url:'cancel-out.php',
                                            cache:false,
                                        }).done((data)=>{
                                            if(data == 1){
                                                $("#btn_cancelBooking").fadeOut(1000);
                                                clearInterval(endTimer);
                                            }
                                        })    
                                    }
                                },100);
                                
                                // Checks if the rider has cancelled the booking or not
                                endTimer1=setInterval(()=>{
                                    if($('#rider_id').val() != ''){
                                        $.ajax({
                                            data:'id='+$('#tbl_id').val(),
                                            url:'check-status.php',
                                            type:'post',
                                            cache:false,
                                        }).done((data)=>{
                                            if(data == 1){
                                                clearInterval(endTimer1);
                                                $('#find-rider').modal('toggle');
                                                $('#hasCancel-modal').modal('toggle')
                                            }
                                        })
                                    }
                                }, 500);
                                
                                // findRider function
                                function findRider(){
                                    pickup_at = $("#_select-barangay-0").val();
                                    dropoff_at = $("#_select-barangay-1").val();
                                    note = $("#br-note").val();
                                    instruction = $("#br-instruction").val();
                                    fare = $('#ride-fare').val();
                                    form = new FormData();
                                    form.append('id', <?php echo $userNo; ?>);
                                    form.append('pick-up', pickup_at)
                                    form.append('drop-off', dropoff_at)
                                    form.append('note', note)
                                    form.append('instruction', instruction)
                                    form.append('fare', fare)
                                    
                                    $.ajax({
                                        data:form,
                                        type:'post',
                                        url: 'book-ride.php',
                                        contentType:false,
                                        processData:false,
                                        cache:false,
                                    }).done((data)=>{
                                        $('#last_id').val(data)
                                    });
                                }
                            </script>
                            <script>
                                const track_rider_map = L.map('map',{ attributionControl: false }); 
                                // Initializes map
                            
                                track_rider_map.setView([51.505, -0.09], 13); 
                                // Sets initial coordinates and zoom level
                            
                                L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
                                    maxZoom: 19,
                                    minZoom: 10,
                                    attribution: '© OpenStreetMap'
                                }).addTo(track_rider_map); 
                                // Sets map data source and associates with map
                            
                                let marker0, marker1, marker2, circle, zoomed;
                            
                                function success(pos) {
                            
                                    const r_lat = $('#rider_lat').val();
                                    const r_lng = $('#rider_lng').val();
                                    
                                    const pu_lat = $('#pu_lat').val();
                                    const pu_lng = $("#pu_lng").val();
                                    
                                    const do_lat = $('#do_lat').val();
                                    const do_lng = $("#do_lng").val();
                                    
                                    const accuracy = pos.coords.accuracy;

                                    if (marker0 || marker1 || marker2) {
                                        track_rider_map.removeLayer(marker0);
                                        track_rider_map.removeLayer(marker1);
                                        track_rider_map.removeLayer(marker2);
                                        track_rider_map.removeLayer(circle);
                                    }
                                    // Removes any existing marker and circule (new ones about to be set)
                                    marker0 = L.marker([r_lat, r_lng]).bindTooltip("RIDER", 
                                        {
                                            permanent: true, 
                                            direction: 'right'
                                        }
                                    ).addTo(track_rider_map).openPopup(); 
                                    
                                    marker1 = L.marker([pu_lat, pu_lng]).bindTooltip("YOU", 
                                        {
                                            permanent: true, 
                                            direction: 'right'
                                        }
                                    ).addTo(track_rider_map).openPopup(); 
                                    marker1._icon.classList.add("start_huechange");
                                    
                                    marker2 = L.marker([do_lat, do_lng]).bindTooltip("DROP OFF", 
                                        {
                                            permanent: true, 
                                            direction: 'right'
                                        }
                                    ).addTo(track_rider_map).openPopup();
                                    marker2._icon.classList.add("end_huechange");
                                    
                                    circle = L.circle([r_lat, r_lng], { radius: accuracy }).addTo(track_rider_map);
                                    // Adds marker to the map and a circle for accuracy
                            
                                    if (!zoomed) {
                                        zoomed = track_rider_map.fitBounds(circle.getBounds()); 
                                    }
                                    // Set zoom to boundaries of accuracy circle
                            
                                    track_rider_map.setView([r_lat, r_lng]);
                                    // Set map focus to current user position
                            
                                }
                            
                                function error(err) {
                            
                                    if (err.code === 1) {
                                        alert("Please allow geolocation access");
                                    } else {
                                        alert("Cannot get current location");
                                    }
                            
                                }
                                
                            </script>
                            
                            <input type="hidden" id="last_id" />
                            <input type="hidden" id="tbl_id" />
                            <input type="hidden" id="rider_id" />
                            <input type="hidden" id="rider_lat" />
                            <input type="hidden" id="rider_lng" />
                            <input type="hidden" id="do_lat" />
                            <input type="hidden" id="do_lng" />
                            <input type="hidden" id="pu_lat" />
                            <input type="hidden" id="pu_lng" />
                        </div>
                    </div>
                </div>
              </div>
              <!--<div class="card-footer"></div>-->
          </div>
        </div> 
        <div class="col-sm-4 order" style="color:#0784b5">
            <div class="card">
              <!--<div class="card-header" style='background:darkgrey; margin:0;padding:0'>-->
              <!--    <h1>&nbsp;</h1>-->
              <!--</div>-->
              <div class="card-body text-center">
                <div class="row">   
                    <div class="col-sm-12">
                        <div class="form-group">
                            <span class="btn my-btn" data-toggle="modal" data-target="#make-order">
                                <p id="order"><span class='fas fa-shopping-cart order-icon'></span> Order <br><i style="font-size: 18px;font-weight:normal;margin-left: 10px">Make an order</i>
                                </p> 
                            </span> 
                            
                            <!-- The Modal -->
                            <div class="modal" id="make-order" style='z-index:999999; color:#0784b5' data-keyboard="false" data-backdrop="false">
                              <div class="modal-dialog">
                                <div class="modal-content">
                            
                                  <!-- Modal Header -->
                                  <div class="modal-header">
                                     <!-- <button type="button" class="close" data-dismiss="modal">&times;</button> -->
                                    <h4 class="modal-title" style='font-weight:bold; color:#192428'>
                                        <img src='../assets/image/eMove.png' style='height:40px; border-radius:50%;' />
                                        Express Wheel | Make an order
                                    </h4>
                                  </div>
                            
                                  <!-- Modal body -->
                                  <div class="modal-body" style="text-align:left">
                                        <div class="row">
                                            <div class="col-sm-6">
                                                <p>Sender Name: </p> 
                                                <input class="form-control" id="sender-name">
                                                
                                                <p>Contact Number:</p>
                                                <input class="form-control" type="number" id="sender-contact"  min="0" step="1" maxlength="11">
                                                <sup id="error-sender-contact"></sup>
                                                
                                                <p>Address:</p>
                                                <div class="row">
                                                    <div class="col-sm-4" style="display:none">
                                                        <p>Province</p>
                                                        <select id="select-province-0" class="form-control">
                                                            <?php
                                                                $query = "select * from refprovince WHERE provCode = '0864' order by provDesc ASC ";
                                                                $province = mysqli_query($conn, $query);
                                                                while($row = mysqli_fetch_assoc($province)){
                                                                    echo "<option value='$row[provCode]'>$row[provDesc]</option>";
                                                                }
                                                            ?>
                                                        </select>
                                                    </div>
                                                    <div class="col-sm-12" style="display:none">
                                                        <p>City</p>
                                                        <select id="select-citymun-0" class="form-control"></select>
                                                    </div>
                                                    <div class="col-sm-12">
                                                        <!--<p>Barangay</p>-->
                                                        <select id="select-barangay-0" class="form-control"></select>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="col-sm-12">
                                                        <p>Landmark:</p>
                                                        <textarea class="form-control"  id="sender-landmark" rows='4' style="resize: none" placeholder="Things that are near in your area"></textarea>    
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-sm-6">
                                                <p>Recipient Name: </p> 
                                                <input class="form-control" id="recipient-name">
                                                
                                                <p>Contact Number:</p>
                                                <input class="form-control" type="number"  id="recipient-contact"  min="0" step="1" maxlength="11">
                                                <sup id="error-recipient-contact"></sup>
                                                
                                                <p>Destination:</p>
                                                <div class="row">
                                                    <div class="col-sm-4" style="display:none">
                                                        <p>Province</p>
                                                        <select id="select-province-1" class="form-control">
                                                            <?php
                                                                $query = "select * from refprovince WHERE provCode = '0864' order by provDesc ASC";
                                                                $province = mysqli_query($conn, $query);
                                                                while($row = mysqli_fetch_assoc($province)){
                                                                    echo "<option value='$row[provCode]'>$row[provDesc]</option>";
                                                                }
                                                            ?>
                                                        </select>
                                                    </div>
                                                    <div class="col-sm-4" style="display:none">
                                                        <p>City</p>
                                                        <select id="select-citymun-1" class="form-control"></select>
                                                    </div>
                                                    <div class="col-sm-12">
                                                        <!--<p>Barangay</p>-->
                                                        <select id="select-barangay-1" class="form-control"></select>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="col-sm-12">
                                                        <p>Landmark:</p>
                                                        <textarea class="form-control"  id="recipient-landmark" rows='4' style="resize: none" placeholder="Things that are near in your area"></textarea>
                                                    </div>
                                                </div>
                                            </div>
                                        </div> 
                                        <div class="row">
                                            <div class="col-sm-12">
                                                <p>Item Name:</p>
                                                <select  class="form-control" id="item-name" onchange="$(this).val() == 'Others'? $('#item-others').css('display', 'block'):  $('#item-others').css('display', 'none') ; ">
                                                    <option value="Documents">Documents</option>
                                                    <option value="Medicine">Medicine</option>
                                                    <option value="Hardware/Supplies">Hardware/Supplies</option>
                                                    <option value="Groceries">Groceries</option>
                                                    <option value="Meals">Meals</option>
                                                    <option value="Others">Others;</option>
                                                </select>
                                                <input class="form-control" id="item-others" style="display:none" placeholder="Please describe your Item..."/>
                                                
                                                <p>Weight(KG):</p>
                                                <input class="form-control" id="item-weight" min="1" step="0.01" max="50" maxlength="2" onkeypress="return event.charCode != 45"><sup id="error-item-weight">Maximum of 50KG</sup>
                                                
                                                <p>Quantity:</p>
                                                <input class="form-control" id="item-quantity" type="number" min="1" step="1" oninput="validity.valid||(value='');">
                                                
                                                <p>Item Value:</p>
                                                <input class="form-control" id="item-value" type="number" min="1" step="0.1"  onkeypress="return event.charCode != 45">
                                                
                                                <p>Length(CM):</p>
                                                <input class="form-control" id="item-length" type="number" min="1" step="0.01"  onkeypress="return event.charCode != 45"><sup>Maximum of 30CM</sup>
                                                
                                                <p>Width(CM):</p>
                                                <input class="form-control" id="item-width" type="number" min="1" step="0.01"  onkeypress="return event.charCode != 45"><sup>Maximum of 30CM</sup>
                                                
                                                <p>Height(CM):</p>
                                                <input class="form-control" id="item-height" type="number" min="1" step="0.01"  onkeypress="return event.charCode != 45"><sup>Maximum of 30CM</sup>
                                                
                                                <p>Service type:</p>
                                                <input class="form-control" value="Standard" readonly id="item-service-type">
                                                
                                                <p>Package type:</p>
                                                <select class="form-control" id="item-package-type">
                                                    <option value="0">No Package</option>
                                                    <option value="1">Box</option>
                                                    <option value="2">Pouch</option>
                                                </select>
                                                
                                                <p>Delivery</p>
                                                <select class="form-control" id="item-delivery-type" onchange="$(this).val() == 1 ? $('#item-scheduled').css('display', 'block') : $('#item-scheduled').css('display', 'none')">
                                                    <option value="0">Same day</option>
                                                    <option value="1">Scheduled</option>
                                                </select>
                                                <input class="form-control" type="date" id="item-scheduled" style="display:none"/>
                                                
                                                <p>Fee:</p>
                                                <!--Currency Symbol-->
                                                <span style="position:fixed;padding-left:10px;margin:3px;color:#000" style="font-size:16px">&#8369;</span>
                                                <input class="form-control" id="item-fee" type="text" style="text-indent: 10px;" disabled>

                                                <p>Remarks:</p>
                                                <textarea class="form-control" id="item-remarks" placeholder="Put some instructions or notes here..."></textarea>
                                                
                                                <!--<p>Branch</p>-->
                                                <!--<select id="select-branch" class="form-control">-->
                                                    <?php
                                                        // $query = "select * from tbl_branch order by branch_name";
                                                        // $result = mysqli_query($conn, $query);
                                                        // while($row = mysqli_fetch_assoc($result)){
                                                        //     echo "<option value='$row[id]'>$row[branch_name]</option>";
                                                        // }
                                                    ?>
                                                <!--</select>-->
                                            </div>
                                        </div>
                                        
                                        <br>
                                        <span id="response-message"></span>
                                  </div>
                            
                                  <!-- Modal footer -->
                                  <div class="modal-footer">
                                    <div class="row">
                                        <div class="col-sm-12">
                                            <button type="submit" class="btn btn-danger btn-block" id="submit-order-btn" >Book</button> 
                                            <button type="button" class="btn btn-default btn-block" data-dismiss="modal" id="order-close-btn">Close</button>                                           
                                        </div>
                                    </div>
                                  </div>
                            
                                </div>
                              </div>
                            </div>
                                <script>
                                    var fee='';
                                    // Submit Order
                                    $("#submit-order-btn").on("click", function(){
                                        form = new FormData()
                                        form.append("sender-id",'<?php echo $userNo; ?>')
                                        form.append("sender-name",$("#sender-name").val())
                                        form.append("sender-contact",$("#sender-contact").val())
                                        form.append("sender-barangay",$("#select-barangay-0 :selected").text())
                                        form.append("sender-city",$("#select-citymun-0 :selected").text())
                                        form.append("sender-province",$("#select-province-0 :selected").text())
                                        form.append("recipient-name",$("#recipient-name").val())
                                        form.append("recipient-contact",$("#recipient-contact").val())
                                        form.append("recipient-barangay",$("#select-barangay-1 :selected").text())
                                        form.append("recipient-city",$("#select-citymun-1 :selected").text())
                                        form.append("recipient-province",$("#select-province-1 :selected").text())
                                        form.append("item-name",$("#item-name").val())
                                        $('#item-name').val() == 'Others' ? form.append("item-others",$("#item-others").val()) : form.append("item-others", '');
                                        form.append("item-weight",$("#item-weight").val())
                                        form.append("item-quantity",$("#item-quantity").val())
                                        form.append("item-value",$("#item-value").val())
                                        form.append("item-length",$("#item-length").val())
                                        form.append("item-width",$("#item-width").val())
                                        form.append("item-height",$("#item-height").val())
                                        form.append("item-service-type",$("#item-service-type").val())
                                        form.append("item-package-type",$("#item-package-type :selected").text())
                                        form.append("item-delivery-type",$("#item-delivery-type :selected").text())
                                        form.append("item-scheduled",$("#item-scheduled").val()) //date type
                                        form.append("item-fee",$('#item-fee').val())
                                        form.append("item-remarks",$("#item-remarks").val())
                                        form.append('sender-landmark',$('#sender-landmark').val())
                                        form.append('recipient-landmark',$('#recipient-landmark').val())
                                        // form.append("branch-id",$("#select-branch").val())
                                        
                                        $.ajax({
                                            url: "user-make-order.php",
                                            method: "POST",
                                            data: form,
                                            dataType:'json',
                                            contentType: false,
                                            processData: false,
                                            cache:false,
                                        }).done( function(data){
                                            console.log(data)
                                            if(data[1] == 1){
                                                $("#order-close-btn").prop('disabled','true');
                                            }
                                            
                                            // $('#response-message').html(data[0]);
                                            $('#order_number').val(data[2]);

                                            $('#make-order').modal('toggle');
                                            $('#order-number-modal').modal('toggle');

                                            $('#note').html(data[0]);
                                        })
                                    })
                                    
                                    $('#make-order').on('shown.bs.modal',() => {
                                        orderSelect();
                                    });                                        
                                    
                                    $("#select-barangay-0, #select-barangay-1").on('change', () => {
                                        orderSelect();
                                    }) 
                                    
                                    function orderSelect(){
                                        pickup_at = $("#select-barangay-0").val();
                                        dropoff_at = $("#select-barangay-1").val();
                                        
                                        form = new FormData();
                                        form.append('pickup',pickup_at);
                                        form.append('dropoff',dropoff_at);
                                        form.append('order',true); //boolean that will separate the two fare
                                        $.ajax({
                                            data:form,
                                            type:'post',
                                            url: 'fare.php',
                                            contentType:false,
                                            processData:false,
                                            cache:false,
                                            beforeSend:()=>{},
                                            success:(data)=>{
                                                $('#item-fee').val('')  
                                                $('#item-fee').val(data)
                                                fee = data;
                                            },
                                            error: (data)=>{
                                                console.log(data)
                                            }
                                        }) 
                                    }
                                    
                                    // Checks if the rider has cancelled the order...
                                    endOrderTimer = setInterval(()=>{
                                        if($('#order_number').val() != ""){ 
                                            form = new FormData();
                                            form.append('order_number',$('#order_number').val());
                                            form.append('sender',<?php echo $userNo; ?>);
                                            $.ajax({
                                                data:form,
                                                url:'check-order-status.php',
                                                type:'post',
                                                contentType:false,
                                                processData:false,
                                                cache:false,
                                            }).done((data)=>{
                                                if(data==1){ //if true; checking will stop...
                                                    clearInterval( endOrderTimer);
                                                    $('#"hasCancel-modal2').modal('toggle');
                                                }
                                            });    
                                        }
                                    }, 500)
                                    
                                </script>
                                <script>
                                    $(document).ready(function(){
                                        // Contact Number Validation 
                                        $("#sender-contact").on("input", function(){
                                            let value = $(this).val();
                                            
                                            // Remove non-numeric characters
                                            value = value.replace(/\D/g, ""); 
                                            
                                            //validate number starts in zero
                                            if(value[0] != '0' || value[0] == ''){
                                                value='';
                                            }
                                            // Limit to 11 digits
                                            if (value.length >= 11) {
                                                value = value.substring(0, 11);
                                                
                                                $("#error-sender-contact").text("").css("color", "");
                                                $("#sender-contact").css('color','');
                                            }
                                            else{
                                                $("#error-sender-contact").text("Please enter 11-digit contact number!").css("color", "red");
                                                $("#sender-contact").css('color','red');
                                            }
                                
                                            $(this).val(value);
                                        });
                                        
                                        $("#recipient-contact").on("input", function(){
                                            let value = $(this).val();
                                            
                                            // Remove non-numeric characters
                                            value = value.replace(/\D/g, ""); 
                                            
                                            //validate number starts in zero
                                            if(value[0] != '0' || value[0] == ''){
                                                value='';
                                            }
                                            // Limit to 11 digits
                                            if (value.length >= 11) {
                                                value = value.substring(0, 11);
                                                
                                                $("#error-recipient-contact").text("").css("color", "");
                                                $("#recipient-contact").css('color','');
                                            }
                                            else{
                                                $("#error-recipient-contact").text("Please enter 11-digit contact number!   ").css("color", "red");
                                                $("#recipient-contact").css('color','red');
                                            }
                                            
                                            $(this).val(value);
                                        });
                                    });
                                </script>
                            <input type='hidden' id="order_number"/>
                        </div>
                    </div>
                </div>
              </div>
              <!--<div class="card-footer"></div>-->
          </div>
        </div> 
        <div class="col-sm-4 order" style="color:#0784b5">
            <div class="card">
                <div class="card-body text-center">
                    <div class="row">   
                        <div class="col-sm-12">
                            <div class="form-group">
                                <span class="btn my-btn" data-toggle="modal" data-target="#track-order">
                                    <p id="track"><span class='fas fa-map-marked-alt track-icon'></span> Track <br><i style="font-size: 18px;font-weight:normal;margin-left: 10px">Track your order</i>
                                    </p>
                                </span>  
                                <!-- The Modal -->
                                <div class="modal" id="track-order" style='z-index:999999; color:#0784b5'>
                                  <div class="modal-dialog">
                                    <div class="modal-content">
                                
                                      <!-- Modal Header -->
                                      <div class="modal-header">
                                         <!-- <button type="button" class="close" data-dismiss="modal">&times;</button> -->
                                        <h4 class="modal-title" style='font-weight:bold; color:#192428'>
                                            <img src='../assets/image/eMove.png' style='height:40px; border-radius:50%;' />
                                            Express Wheel | Track your order
                                        </h4>
                                      </div>
                                
                                      <!-- Modal body -->
                                      <div class="modal-body" style="text-align:Left">
                                        <div class="row">
                                            <div class="col-sm-12">
                                                <p>Search Order Receipt Number</p>
                                                <input class="form-control" id="order-number" placeholder="Order number">
                                            </div>
                                        </div>
                                        <br>
                                        <div id="track-order-map" style="width:100%; height:350px; border-radius:5px; box-shadow: 0 0 15px 0 #000"></div>
                                        <br>
                                        <span id="track-response-message"></span>
                                      </div>
                                
                                      <!-- Modal footer -->
                                      <div class="modal-footer">
                                            <div class="row">
                                                <div class="col-sm-12">
                                                    <button type="submit" class="btn btn-danger btn-block" id="submit-track-btn" >Track</button>
                                                    <button type="button" class="btn btn-default btn-block" data-dismiss="modal">Close</button>
                                                </div>
                                            </div>
                                      </div>
                                
                                    </div>
                                  </div>
                                </div>
                            
                        </div>
                    </div>
                    </div>
                </div>
            </div>  
        </div>
    </div> 
</div>

<footer class="container-fluid text-center mobile-view" style='background-color:#0784b5;'>
    <a href="#myPage" title="To Top" class="toTop">
        <span class="glyphicon glyphicon-chevron-up"></span>
    </a>                                
    <div class="row home-mobile-view" style="display: none">
       <a href="index.php" style="color:#000; margin:0 5%; font-size: 25px"><span class="fa fa-home fa-fw nav-btn"></span></a>
       <a href="my-trasaction.php" style="color:#000; margin:0 5%; font-size: 25px"><span class="fas fa-clipboard-check fa-fw nav-btn"></span></a>
       <a href="my-notifications.php" style="color:#000; margin:0 5%; font-size: 25px"><span class="fas fa-bell fa-fw nav-btn"></span></a>
       <a href="my-account.php" style="color:#000; margin:0 5%; font-size: 25px"><span class="fa fa-user fa-fw nav-btn"></span></a>
       <a href="#logout-modal" data-toggle="modal" style="color:#000; margin:0 5%; font-size: 25px"><span class="fa fa-sign-out-alt fa-fw nav-btn"></span></a>
    </div>
    <script>
       setInterval(()=>{
           if(screen.width <= 480){
                $('.mobile-view').removeClass('container-fluid').addClass('container').css({'padding':'10px 20px','bottom':'0','position':'fixed','width':'100%'});
                $('.home-mobile-view').css('display','block')
                $('.toTop').css('display','none')
                $('div#order').css('margin-bottom', '65px')
                $('.navbar-toggle').css('display','none');
           } 
           else{
                $('.mobile-view').addClass('container-fluid').removeClass('container');
                $('.home-mobile-view').css('display','none')
                $('.toTop').css('display','block')
           }
       },100)
    </script>
</footer>

<!-- Rate Rider Modal -->
<div class="modal" id="rate-rider" style='z-index:999999' data-keyboard="false" data-backdrop="false">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header text-center">
                <!--<button type="button" class="close" data-dismiss="modal">&times;</button>-->
                <h4 class="modal-title" style='font-weight:bold; color:#192428'>
                    <img src='../assets/image/eMove.png' style='height:40px; border-radius:50%;' />
                    Express Wheel | Ride Booking
                </h4>   
            </div>
            <div class="modal-body">
                <div class="row">
                    <div class="col-sm-12 text-center">
                        <div style="margin:50px 0 50px 0;;" class="">
                            <span class="fa fa-star" onclick="rateRider0()" id="r1" name="rating"></span>
                            <span class="fa fa-star" onclick="rateRider1()" id="r2" name="rating"></span>
                            <span class="fa fa-star" onclick="rateRider2()" id="r3" name="rating"></span>
                            <span class="fa fa-star" onclick="rateRider3()" id="r4" name="rating"></span>
                            <span class="fa fa-star" onclick="rateRider4()" id="r5" name="rating"></span>
                            <br>
                            <p style="color:#39ace7">Rate Your Rider<p> 
                            <script>
                                stars = $('[name="rating"]');
                                var rating=0; //
                                
                                function rateRider0(){
                                    $('#r1').addClass("star-checked stars");
                                    $('#r2').removeClass("star-checked stars");
                                    $('#r3').removeClass("star-checked stars");
                                    $('#r4').removeClass("star-checked stars");
                                    $('#r5').removeClass("star-checked stars");

                                    rating = 1;
                                }
                                function rateRider1(){
                                    $('#r1').addClass("star-checked stars");
                                    $('#r2').addClass("star-checked stars");
                                    $('#r3').removeClass("star-checked stars");
                                    $('#r4').removeClass("star-checked stars");
                                    $('#r5').removeClass("star-checked stars");

                                    rating = 2;
                                }
                                function rateRider2(){
                                    $('#r1').addClass("star-checked stars");
                                    $('#r2').addClass("star-checked stars");
                                    $('#r3').addClass("star-checked stars");
                                    $('#r4').removeClass("star-checked stars");
                                    $('#r5').removeClass("star-checked stars");

                                    rating = 3;
                                }
                                function rateRider3(){
                                    $('#r1').addClass("star-checked stars");
                                    $('#r2').addClass("star-checked stars");
                                    $('#r3').addClass("star-checked stars");
                                    $('#r4').addClass("star-checked stars");
                                    $('#r5').removeClass("star-checked stars");

                                    rating = 4;
                                }
                                function rateRider4(){
                                    stars.addClass('star-checked stars')
                                    
                                    rating = 5;
                                }

                                function rateRider(){
                                    form =new FormData();
                                    form.append('rate', rating);
                                    form.append('id', <?php echo $userNo; ?>);
                                    form.append('rider', $('#rider_id').val());
                                    form.append('comment', $('#review').val());
                                    $.ajax({
                                        data:form,
                                        url:'rider-rating.php',
                                        type:'post',
                                        processData:false,
                                        contentType:false,
                                        cache:false,
                                    }).done(()=>{
                                        history.go(0);
                                    });
                                }
                            </script>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-sm-12 text-left">
                        <p>Review:</p>
                        <textarea class="form-control" id="review" rows="3" style="resize:none" placeholder="Give a review to the rider." ></textarea>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <div class="row">
                    <div class="col-sm-12">
                        <button type="submit" class="btn btn-default btn-block" data-dismiss="modal" onclick="location.reload()">Remind me later</button>
                        <button type="submit" class="btn btn-danger btn-block" onclick="rateRider()">Submit</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!--//do not delete-->
<div id="modal"></div>

<!-- Show Order Number Modal-->
<div id="order-number-modal" class="modal fade" role="dialog" style='z-index:999999'>
    <div class="modal-dialog  modal-md"  >  
        <div class="modal-content">
            <div class="modal-header text-center">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title" style='font-weight:bold; color:#192428'>
                    <img src='../assets/image/eMove.png' style='height:40px; border-radius:50%;' />
                    Express Wheel | Make an order
                </h4>
            </div>
            <div class="modal-body">  
                <div class='row'> 
                    <div class='col-sm-12'> 
                        <h1 id="order_number"></h1> 
                        <span id="note"></span> 
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <div class='row'>
                    <div class='col-sm-12'>
                        <!-- <a type="button" class="btn btn-default btn-block" data-dismiss="modal">Cancel</a> -->
                        <a type="button" class="btn btn-success btn-block" onclick="if (document.querySelector('#myInput')) { copyToClipboard(); } else { history.go(); }" >OK</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!--The Rider hasCancel Modal-->
<div id="hasCancel-modal" class="modal fade" role="dialog" style='z-index:999999' data-keyboard="false" data-backdrop="false">
    <div class="modal-dialog  modal-md">  
        <div class="modal-content">
            <div class="modal-header text-center">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title" style='font-weight:bold; color:#192428'>
                    <img src='../assets/image/eMove.png' style='height:40px; border-radius:50%;' />
                    Express Wheel | Booking Cancelled
                </h4>
            </div>
            <div class="modal-body">  
                <div class='row'> 
                    <div class='col-sm-12 text-center' style="height:70vh"> 
                        <br>
                        <h1 style="color:#0784b5;font-weight:bold">We are sorry! </h1>
                        <br>
                        <br>
                        <h3 style="color:#0784b5;">Your Rider has cancelled the booking...</h3>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <div class='row'>
                    <div class='col-sm-12'>
                        <a type="button" class="btn btn-danger btn-block" data-dismiss="modal" onclick="history.go(0)">OK</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!--The Rider hasCancel Modal2-->
<div id="hasCancel-modal2" class="modal fade" role="dialog" style='z-index:999999' data-keyboard="false" data-backdrop="false">
    <div class="modal-dialog  modal-md">  
        <div class="modal-content">
            <div class="modal-header text-center">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title" style='font-weight:bold; color:#192428'>
                    <img src='../assets/image/eMove.png' style='height:40px; border-radius:50%;' />
                    Express Wheel | Order Cancelled
                </h4>
            </div>
            <div class="modal-body">  
                <div class='row'> 
                    <div class='col-sm-12 text-center' style="height:70vh"> 
                        <br>
                        <h1 style="color:#0784b5;font-weight:bold">We are sorry! </h1>
                        <br>
                        <br>
                        <h3 style="color:#0784b5;">Your Rider has cancelled your order...</h3>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <div class='row'>
                    <div class='col-sm-12'>
                        <a type="button" class="btn btn-danger btn-block" data-dismiss="modal" onclick="history.go(0)">OK</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div> 

<!--The Logout Modal-->
<div id="logout-modal" class="modal fade" role="dialog" style='z-index:999999'>
    <div class="modal-dialog  modal-md"  >  
        <div class="modal-content">
            <div class="modal-header text-center">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title" style='font-weight:bold; color:#192428'>
                    <img src='../assets/image/eMove.png' style='height:40px; border-radius:50%;' />
                    Express Wheel | Sign out
                </h4>
            </div>
            <div class="modal-body">  
                <div class='row'> 
                    <div class='col-sm-12'> 
                         Do you really want to continue?   
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <div class='row'>
                    <div class='col-sm-12'>
                        <a type="button" class="btn btn-default btn-block" data-dismiss="modal">Cancel</a>
                        <a type="button" class="btn btn-success btn-block" href="logout.php" >Sign out</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div> 

<script type="text/javascript">
    $( document ).ready( function(){ 
        history.pushState(null,  document.title, location.href);        
    });
</script>
<script>
$(document).ready(function(){
  // Add smooth scrolling to all links in navbar + footer link
  $(".navbar a, footer a[href='#myPage']").on('click', function(event) {
    // Make sure this.hash has a value before overriding default behavior
    if (this.hash !== "") {
      // Prevent default anchor click behavior
      event.preventDefault();

      // Store hash
      var hash = this.hash;

      // Using jQuery's animate() method to add smooth page scroll
      // The optional number (900) specifies the number of milliseconds it takes to scroll to the specified area
      $('html, body').animate({
        scrollTop: $(hash).offset().top
      }, 900, function(){
   
        // Add hash (#) to URL when done scrolling (default click behavior)
        window.location.hash = hash;
      });
    } // End if
  });
  
  $(window).scroll(function() {
    $(".slideanim").each(function(){
      var pos = $(this).offset().top;

      var winTop = $(window).scrollTop();
        if (pos < winTop + 600) {
          $(this).addClass("slide");
        }
    });
  });
})

function copyToClipboard() {
    // Get the text field
    var copyText = document.getElementById("myInput");
    
    // Select the text field
    copyText.select();
    copyText.setSelectionRange(0, 99999); // For mobile devices
    
    // Copy the text inside the text field
    navigator.clipboard.writeText(copyText.value);
    
    // Alert the copied text
    alert("Text Copied: " + copyText.value);
    // alert('text copied!');
    
    history.go(0);
}
            
const track_order_map = L.map('track-order-map', { attributionControl: false } );
// Initializes map

// Track Order
$("#submit-track-btn").on("click", function (){
    $.ajax({
        url: 'user-track-order.php',
        data: 'order-number='+$('#order-number').val(),
        method: 'POST',
        dataType: 'json',
        cache:false,
        success: (data) => { console.log(data) },
        error:(data) => { console.log(data) }
    }).done((data) => {
        // $('#track-response-message').html(data[4]+ ", " +data[5]);
        if(data == 0){
            $('#track-response-message').html('<div class="alert alert-danger">\
                                                    <strong>Error: </strong> Invalid Order number! Please try again.\
                                                    <a class="close" data-dismiss="alert">&times</a>\
                                                </div>');
        }
        else if(data[4] != null && data[5] != null){
            
            track_order_map.setView([51.505, -0.09], 13); 
            // Sets initial coordinates and zoom level
            
            L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
                maxZoom: 19,
                minZoom: 10,
                attribution: '© OpenStreetMap',
                attributionControl: false
            }).addTo(track_order_map); 
            // Sets map data source and associates with map
            
            track_order_map.invalidateSize();
            
            setInterval( navigator.geolocation.getCurrentPosition(success, error), 2000);
            
            let track_order_marker, track_order_circle, track_order_zoomed;
            
            function success(pos) {
                
                const lat =  data[4];
                const lng =  data[5];
                const accuracy = pos.coords.accuracy;
                
                var position = [
                            ['Rider', data[4], data[5]],
                            ['Recipient', data[2], data[3]],
                            ['You', data[0], data[1]],
                        ];
                
                if (track_order_marker) {
                    track_order_map.removeLayer(track_order_marker);
                    track_order_map.removeLayer(track_order_circle);
                }
                for(let x = 0; x < position.length; x++){
                    track_order_marker = L.marker([position[x][1], position[x][2]]).bindTooltip(position[x][0], { permanent: true, direction: 'right'}).addTo(track_order_map).openPopup();
                }
                // marker = L.marker([lat, lng]).bindTooltip().addTo(map).openPopup();
                track_order_circle = L.circle([lat, lng], { radius: accuracy }).addTo(track_order_map);
                // Adds marker to the map and a circle for accuracy
            
                if (!track_order_zoomed) {
                    track_order_zoomed = track_order_map.fitBounds(track_order_circle.getBounds()); 
                }
                // Set zoom to boundaries of accuracy circle
            
                track_order_map.setView([lat, lng]);
                // Set map focus to current user position
            
            }
            
            function error(err) {
            
                if (err.code === 1) {
                    alert("Please allow geolocation access");
                } else {
                    alert("Cannot get current location");
                }
            
            }
        }
        else{
            $('#track-response-message').html('<div class="alert alert-warning">\
                                                    <strong>Warning: </strong> Your Order is still pending! Please wait for a moment.\
                                                    <a class="close" data-dismiss="alert">&times</a>\
                                                </div>');
        }
    })
})
</script>

<script>
    $("#order-id").css("cursor","pointer");
</script>

<script>
    //  Sender's Address
    $(document).ready( function(){
        // loads the municipals that belongs under the selected province
        ajax = $.ajax({
            url: 'load-municipal.php',
            method: "POST",
            data: "province="+$("#select-province-0").val(),
            cache:false,
        })
        $.when(ajax).done( function(ajax){
            $('#select-citymun-0').html(ajax);
            
            // loads the barangays that belongs under the selected municipal
            $.ajax({
                url: 'load-barangay.php',
                method: "POST",
                data: "city="+$("#select-citymun-0").val(),
                cache:false,
            }).done( function(data){
                $('#select-barangay-0').html(data);
                // $('#_select-barangay-0').html(data);
                
                $.ajax({
                    url: 'load-barangay0.php',
                    method: "POST",
                    cache:false,
                }).done( function(data){
                    $('#_select-barangay-0').append(data);
                });
            })
        });
    })
    //  Recipient's Address
    $(document).ready( function(){
        // loads the municipals that belongs under the selected province
        ajax = $.ajax({
            url: 'load-municipal.php',
            method: "POST",
            data: "province="+$("#select-province-1").val(),
            cache:false,
        })
        $.when(ajax).done( function(data){
            $('#select-citymun-1').html(data);
            
            // loads the barangays that belongs under the selected municipal
            $.ajax({
                url: 'load-barangay.php',
                method: "POST",
                data: "city="+$("#select-citymun-1").val(),
                cache:false,
            }).done( function(data){
                $('#select-barangay-1').html(data);
                // $('#_select-barangay-1').html(data);
            })
        })
    })
</script>

<script>
    // tracks current position
    
    function _success(pos) {
        const lat = pos.coords.latitude;
        const lng = pos.coords.longitude;
        const accuracy = pos.coords.accuracy;
        // console.log(lat,lng)
        
        setInterval( updateMyLocation(lat, lng), 2000 );
    }
    
    function _error(err) {
        if (err.code === 1) {
            alert("Please allow geolocation access");
        } else {
            alert("Cannot get current location");
        }
    }
    
    setInterval( ()=>{ navigator.geolocation.getCurrentPosition(_success, _error) }, 1000);

    function updateMyLocation(lat, lng){
        $.ajax({
            data: {
                    'latitude' : lat,
                    'longitude' : lng,
                    'id' : <?php echo $userNo; ?>
                },
            method: 'post',
            url: 'update-my-location.php',
            cache: false,
        });
    }
</script>

<script>
    setInterval(()=>{
        if($('#last_id').val() != '' ){
            form=new FormData();
            form.append('tbl-id', $('#last_id').val())
            $.ajax({
                url: 'arrival.php',
                data:form,
                type: 'post',
                contentType: false,
                processData: false,
                cache:false,
                success:(data)=>{
                    if(data != 0){
                        $('.to-arrive').html(data)
                    }
                }
                // dataType: 'json',
            });
        }
    }, 500) 
</script>

<script>
    setInterval(function() {
        // unread notifications
        $.ajax({
            url: 'update-notifications.php',
            method: 'POST',
            data: { 
                'user_id': <?php echo $userNo; ?> 
            },
            success: function(data) {
                if(data == 0){
                    $('#sup_notif').hide();
                }
                else{
                    $('#sup_notif').show().css({"color":"white", "background-color":"#0784b5", "padding":"2px 3px 2px 0", "border-radius":"2px"}).html(data);
                }
            }
        });
        // $.ajax({
        //     url: 'update-history.php',
        //     method: 'POST',
        //     data: { 
        //         'user_id': <?php echo $userNo; ?> 
        //     },
        //     success: function(data) {
        //         if(data == 0){
        //             $('#sup_history').hide();
        //         }
        //         else{
        //             $('#sup_history').show().css({"color":"white", "background-color":"#0784b5", "padding":"2px 3px 2px 0", "border-radius":"2px"}).html(data);
        //         }
        //     }
        // });  
    }, 500);
</script>
</body>
</html>