<?php
    include('../components/comp-conn.php');

    $brgys=[];
    $fare=0;
    $pickup_id='';
    $dropoff_id='';

    $query0= mysqli_query($conn, "select * from tbl_brgy_position where brgy_id = '$_POST[dropoff]' ");
    $row0=mysqli_fetch_assoc($query0);

    if(isset($_POST['order'])){
        // $fare=70.25;//fare for order delivery

        $query1 = mysqli_query($conn, "SELECT * FROM tbl_brgy WHERE id = '$_POST[pickup]' ");
        $cityCode = mysqli_fetch_assoc($query1);
        $municipal_code = $cityCode['citymunCode'];
        $query2 = mysqli_query($conn, "SELECT * FROM tbl_brgy WHERE id = '$_POST[dropoff]' ");
        $cityCode1 = mysqli_fetch_assoc($query2);
        $municipal_code1 = $cityCode1['citymunCode'];

        if( $municipal_code <> $municipal_code1){

            if($municipal_code == '086412'){

                $fare=$row0['sb_inter_mun_delivery_fee'];
            }
            else{

                $fare=$row0['sj_inter_mun_delivery_fee'];
            }
        }
        else{

            $fare=$row0['delivery_fee']; 
        }
    }
    else if(isset($_POST['ride'])){
        // $fare=40.75;//fare for ride hailing
        
        $query1 = mysqli_query($conn, "SELECT * FROM tbl_brgy WHERE id = '$_POST[pickup]' ");
        $cityCode = mysqli_fetch_assoc($query1);
        $municipal_code = $cityCode['citymunCode'];

        $query2 = mysqli_query($conn, "SELECT * FROM tbl_brgy WHERE id = '$_POST[dropoff]' ");
        $cityCode1 = mysqli_fetch_assoc($query2);
        $municipal_code1 = $cityCode1['citymunCode'];
        

        if( $municipal_code <> $municipal_code1){

            if($municipal_code == '086412'){

                $fare=$row0['sb_inter_mun_ride_fee']; //starting point st. bernard
            }
            else{

                $fare=$row0['sj_inter_mun_ride_fee']; //starting point san juan
            }
        }
        // else if($municipal_code <> '086414' || $municipal_code <> '086412'){

        //     $fare=$row0['sj_round_ride_fee']; //rounders san juan
        // }
        else{
            
            $fare=$row0['ride_fee']; 
        }
    } 
    
    echo number_format((float)$fare, 2, '.', '');
?>

<?php 


    // if($_POST['pickup'] == $_POST['dropoff']){
    //     // $fare *= 1;
    // }
    // else{
    //     // $query0= mysqli_query($conn, "select * from tbl_brgy_position where brgy_id= '$_POST[pickup]' ");
    //     // $row0=mysqli_fetch_assoc($query0);
    //     // $pickup_id=$row0['id'];
        
    //     // $query1= mysqli_query($conn, "select * from tbl_brgy_position where brgy_id= '$_POST[dropoff]' ");
    //     // $row1=mysqli_fetch_assoc($query1);
    //     // $dropoff_id=$row1['id'];
        
    //     // $query2 = mysqli_query($conn, "select count(id) as count from tbl_brgy_position where id between '$pickup_id' and '$dropoff_id' ");
    //     // $row0 = mysqli_fetch_assoc($query2);
        
    //     // if($row0['count'] == 0){      
    //     //     $query3 = mysqli_query($conn, "select count(id) as count0 from tbl_brgy_position where id between '$dropoff_id' and '$pickup_id' ");
    //     //     $row1=mysqli_fetch_assoc($query3);
    //     //     $row1['count0']-1;
    //     //     $fare = $row1['count0']*$fare;
    //     // }
    //     // else{
    //     //     $row0['count']-1;
    //     //     $fare = $row0['count']*$fare;
    //     // }
    // }
?>