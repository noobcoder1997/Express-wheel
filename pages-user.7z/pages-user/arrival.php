<?php
    include '../components/comp-conn.php';
    
    $id = $_POST['tbl-id'];
    $fare='';
    
    $query=mysqli_query($conn, "select * from tbl_book_ride where  id = '$id' and status = 2 AND rider_status = 2 ");
    if(mysqli_num_rows($query) > 0){
        while($row = mysqli_fetch_assoc($query)){
            $fare=$row['fare'];
?>
        <span id="book-ride-alert"></span>
        <div class="row" style="margin:0 5%; background-color:#39ace7 ; color:#fff; border-radius:1%;" > 
            <div class="col-sm-12 text-center" style="">
                <img src="../assets/image/user.png" class="img-circle elevation-2" alt="Profile Photo" style="width:120px; height:120px; object-fit: fill; position: flex;margin-top:20%"> 
                <h4>You have arrived!</h4>
                <h1 id="h1fare">&#8369; 
                    <!--Fare-->
                    <?php
                        echo $fare;
                    ?>
                </h1>
                <h4 style="margin-bottom:20%">Total Fare</h4>
            </div>
        </div>
        <div class="row">
            <hr>
            <div class="col-sm-12 text-center">
                <p>This area will allow you to rate and review riders with your riding experience.</p>
                <div class="row">
                    <div class="col-sm-12">
                        <button type="button" class="btn btn-danger btn-block" data-toggle="modal" data-target="#rate-rider" data-dismiss="modal">Rate your rider!</button>
                    </div>
                </div>
            </div>
        </div>
<?php   
        }
    }
    else{
        echo 0;
    }
?>