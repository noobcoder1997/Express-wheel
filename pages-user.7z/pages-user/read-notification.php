<?php
// Database connection
include '../components/comp-conn.php';

    $id = $_POST['id'];

    // Update query to set status to 1
    $sql = "UPDATE tbl_notifications SET status = 1 WHERE id = '$id' ";

    mysqli_query($conn, $sql)

?>