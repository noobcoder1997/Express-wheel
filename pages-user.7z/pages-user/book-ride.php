<?php
    // session_start();
    include '../components/comp-conn.php';
    
    $id = $_POST['id'];
    $pick_up = $_POST['pick-up'];
    $drop_off = $_POST['drop-off'];
    $note = $_POST['note'];
    $instruction = $_POST['instruction'];
    $fare = $_POST['fare'];
    $status = '0';
    $date = date('Y-m-d').' '.date('h:i:s');
    
    mysqli_query( $conn, "INSERT INTO `tbl_book_ride`(`_from`, `_to`, `note`, `instruction`, `passenger_id`, `status`, `fare`, `_timestamp`) VALUES ('$pick_up','$drop_off','$note','$instruction','$id', '$status', '$fare', '$date')" );
	
    //gets the latest id inserted
    echo $last_id = $conn->insert_id;
?>