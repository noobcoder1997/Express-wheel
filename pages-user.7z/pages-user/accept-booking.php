<?php
    include('../components/comp-conn.php');
    
    $id=$_POST['id'];
    $pickup=$_POST['pick-up'];
    $dropoff=$_POST['drop-off'];
    $note=$_POST['note'];
    $instruction=$_POST['instruction'];
    $rider='';
    $str='';
    $msg='';
    $tbl_id='';
    $do_lat='';
    $do_lng='';
    $pu_lat='';
    $pu_lng='';
    $rating=0;
    $sum=0;
    $count=0;

    $query = mysqli_query($conn, "SELECT * FROM tbl_book_ride WHERE passenger_id = '$id' AND _to = '$dropoff' AND _from = '$pickup' AND status = '1' AND note = '$note' AND instruction = '$instruction' AND rider_id <> '' ");
    if(mysqli_num_rows($query) > 0){
        while($result=mysqli_fetch_assoc($query)){
            $rider = $result['rider_id'];
            $tbl_id=$result['id'];
            $query0=mysqli_query($conn, "SELECT * FROM  tbl_user WHERE no = '$rider' ");
            while($result0 =mysqli_fetch_assoc($query0)){
                $str = $result0['fn'];
            }
            $query1=mysqli_query($conn, "SELECT * FROM  tbl_brgy_position WHERE brgy_id = '$dropoff' ");
            while($result0 =mysqli_fetch_assoc($query1)){
                $do_lat=$result0['latitude'];
                $do_lng=$result0['longitude'];
            }
            $query2=mysqli_query($conn, "SELECT * FROM  tbl_brgy_position WHERE brgy_id = '$pickup' ");
            while($result0 =mysqli_fetch_assoc($query2)){
                $pu_lat=$result0['latitude'];
                $pu_lng=$result0['longitude'];
            }

            $count_query = mysqli_query($conn, "select COUNT(id) as counted_rating from tbl_rider_rating where rider_id = '$rider' ");
            if($res_count = mysqli_fetch_assoc($count_query)){
                $count=$res_count['counted_rating'];
            }

            $sum_query = mysqli_query($conn, "select SUM(rating) as summed_rating from tbl_rider_rating where rider_id = '$rider' ");
            if($res_sum = mysqli_fetch_assoc($sum_query)){
                $sum=$res_sum['summed_rating'];
            }
        }

        if($res_count['counted_rating'] != 0 ){
            $rating = intval($res_sum['summed_rating']/ $res_count['counted_rating']);
        }
        

        $str = strtoupper($str);
        $msg = "<div class='alert alert-success'>
                    <strong>Rider Found:</strong> Your Rider is ".$str."! Please wait as your rider will going to get you.
                </div>";
                
        echo json_encode(
            [
                $str,
                $msg,
                $tbl_id,
                $rider,
                $do_lat,
                $do_lng,
                $pu_lat,
                $pu_lng,        
                $rating
            ]
        );
    }
    else{
        $msg = "<div class='alert alert-warning'>
                <strong>Finding your Rider:</strong> Please wait for a moment!
              </div>";
    }
        
?>