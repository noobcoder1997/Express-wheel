<?php 
    include('../components/comp-conn.php');
    
    $query = mysqli_query($conn, "select * from tbl_user_make_order where order_number = '$_POST[order_number]' and sender_id = '$_POST[sender]' and status = 3 and rider_status = 3 ");
    
    if(mysqli_num_rows($query) > 0){
        echo 1;
    }
?>