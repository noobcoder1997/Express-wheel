<?php
    include '../components/comp-conn.php';
    
    if(!empty($_FILES['f-img']['tmp_name']) && !empty($_FILES['b-img']['tmp_name'])){
        
        $fileinfofront=PATHINFO($_FILES["f-img"]["name"]);
        $fileinfoback=PATHINFO($_FILES["b-img"]["name"]);
        
		$newFilenamefront=$fileinfofront['filename'] ."." . $fileinfofront['extension'];
		$newFilenameback=$fileinfoback['filename'] ."." . $fileinfoback['extension'];
		
		move_uploaded_file($_FILES["f-img"]["tmp_name"],"../assets/riders_image/" . $newFilenamefront);
		move_uploaded_file($_FILES["b-img"]["tmp_name"],"../assets/riders_image/" . $newFilenameback);
		
		$front_img="assets/riders_image/" . $newFilenamefront;
		$back_img="assets/riders_image/" . $newFilenameback;
		
		mysqli_query($conn, "update tbl_user set img0 = '$front_img', img1 = '$back_img', applicant = 1 where no = '$_POST[id]' ");
		
        echo   '<div class="alert alert-success">
                  <strong>Upload Success:</strong> Thank you for applying as a rider! We will get back to you soon.
                </div>';
    }
    
?>