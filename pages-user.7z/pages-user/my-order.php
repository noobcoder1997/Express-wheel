<HTML> 
<head> 
<TITLE>e-Baligya</TITLE>  
<link rel="icon" href="../assets/image/agri-logo.png">
<meta name="viewport" content="width=device-width, initial-scale=1.0"> 
<link rel="stylesheet" href="../lib/bootstrap/css/bootstrap.css">
<link rel="stylesheet" href="../lib/bootstrap/css/bootstrap.min.css">
<link rel="stylesheet" href="../lib/font-awesome-5/css/all.css">
<script src="../lib/jquery/jquery-1.11.3.js"></script>
<script src="../lib/bootstrap/js/bootstrap.min.js"></script>
<?php
    include "../components/comp-conn.php"; 
    session_start();
    $userNo =  "NO USER NUMBER".$_SESSION['userNo'];
    if(!isset($_SESSION['userNo'])){
        ?>
        <script>
            window.location.href='../';
        </script>
        <?php
    }else{
        $userNo = $_SESSION['userNo'];
    } 
    
    $userQry = mysqli_query($conn,"SELECT * FROM tbl_user WHERE no='$userNo' ")or die(mysqli_error($conn));
    $userRw  = mysqli_fetch_assoc($userQry);
    $verified = $userRw['verified'];
    if($verified == 2){
        
         ?>
        <script>
            alert("Sorry it seem your account has been deactivated. Please contact the customer service.")
            window.location.href='../';
        </script>
        <?php
    }else if($verified==1){
        $ver = "";
    }else{ 
        $pg  = 'verified-account.php';
        $ver = '<a   data-toggle="modal" data-target="#verify" >Get verify</a>';
    }
    
    
    
    
?>
</head>
 <style>
  body {
    font: 400 15px Lato, sans-serif;
    line-height: 1.8;
    color: #818181;
    font-family: 'century gothic';
    background-color:lightgrey;
  }
  h2 {
    font-size: 24px;
    text-transform: uppercase;
    color: #303030;
    font-weight: 600;
    margin-bottom: 30px;
  }
  h4 {
    font-size: 19px;
    line-height: 1.375em;
    color: #303030;
    font-weight: 400;
    margin-bottom: 30px;
  }  
  .jumbotron {
    background-color: lightgreen;
    color: darkgreen;
    padding: 40px 25px;
    padding-top:70px;
    font-family: Montserrat, sans-serif; 
    
  }
  .container-fluid {
    padding: 40px 50px;
  }
  .bg-grey {
    background-color: #f6f6f6;
  }
  .logo-small {
    color: darkgreen;
    font-size: 50px;
  }
  .logo {
    color: darkgreen;
    font-size: 200px;
  }
  .thumbnail {
    padding: 0 0 15px 0;
    border: none;
    border-radius: 0;
  }
  .thumbnail img {
    width: 100%;
    height: 100%;
    margin-bottom: 10px;
  }
  .prod:hover{
     border:2px solid grey;
      cursor: pointer;
      transition-duration: .5s;
  }
  .carousel-control.right, .carousel-control.left {
    background-image: none;
    color: darkgreen;
  }
  .carousel-indicators li {
    border-color: darkgreen;
  }
  .carousel-indicators li.active {
    background-color: darkgreen;
  }
  .item h4 {
    font-size: 19px;
    line-height: 1.375em;
    font-weight: 400;
    font-style: italic;
    margin: 70px 0;
  }
  .item span {
    font-style: normal;
  }
  .panel {
    border: 1px solid darkgreen; 
    border-radius:0 !important;
    transition: box-shadow 0.5s;
  }
  .panel:hover {
    box-shadow: 5px 0px 40px rgba(0,0,0, .2);
  }
  .panel-footer .btn:hover {
    border: 1px solid darkgreen;
    background-color: #fff !important;
    color: darkgreen;
  }
  .panel-heading {
    color: #fff !important;
    background-color:darkgreen !important;
    padding: 25px;
    border-bottom: 1px solid transparent;
    border-top-left-radius: 0px;
    border-top-right-radius: 0px;
    border-bottom-left-radius: 0px;
    border-bottom-right-radius: 0px;
  }
  .panel-footer {
    background-color: white !important;
  }
  .panel-footer h3 {
    font-size: 32px;
  }
  .panel-footer h4 {
    color: #aaa;
    font-size: 14px;
  }
  .panel-footer .btn {
    margin: 15px 0;
    background-color:darkgreen;
    color: #fff;
  }
  .navbar {
    margin-bottom: 0;
    background-color: darkgreen;
    z-index: 9999;
    border: 0;
    font-size: 12px !important;
    line-height: 1.42857143 !important;
    letter-spacing: 4px;
    border-radius: 0;
    font-family: Montserrat, sans-serif;
  }
  .navbar li a, .navbar .navbar-brand {
    color: #fff !important;
  }
  .navbar-nav li a:hover, .navbar-nav li.active a {
    color: darkgreen !important;
    background-color: #fff !important;
  }
  .navbar-default .navbar-toggle {
    border-color: transparent;
    color: #fff !important;
  }
  footer .glyphicon {
    font-size: 20px;
    margin-bottom: 20px;
    color: darkgreen;
  }
  .slideanim {visibility:hidden;}
  .slide {
    animation-name: slide;
    -webkit-animation-name: slide;
    animation-duration: 1s;
    -webkit-animation-duration: 1s;
    visibility: visible;
  }
  @keyframes slide {
    0% {
      opacity: 0;
      transform: translateY(70%);
    } 
    100% {
      opacity: 1;
      transform: translateY(0%);
    }
  }
  @-webkit-keyframes slide {
    0% {
      opacity: 0;
      -webkit-transform: translateY(70%);
    } 
    100% {
      opacity: 1;
      -webkit-transform: translateY(0%);
    }
  } 
  @media screen and (max-width: 480px) {
    .logo {
      font-size: 150px;
    }
  }
  
 .cat-btn{
     background-color: white;
 }
.cat-btn:hover{ 
    border:1px solid black;
    background-color: lightgreen;
    cursor: pointer;
    transition-duration: 1s;
} 
  </style>
</head>
<body id="myPage" data-spy="scroll" data-target=".navbar" data-offset="60">

<nav class="navbar navbar-default navbar-fixed-top">
  <div class="container">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
      <a class="navbar-brand" href="#myPage">
          <table>
              <tr>
                  <td> 
                    <img src='../assets/image/agri-logo.png' style=' height:25px; border-radius:50%;' /> 
                     
                  </td>
                  <td style='color:white;font-weight:bold;'>&nbsp;<?php  echo $userRw['user']."<small> $ver</small>";?></td>
                  <input type='hidden' id='userNo' value='<?php echo $userNo;?>' /> 
              </tr>
          </table>
      </a>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav navbar-right">
        <?php  
            $cartQry = mysqli_query($conn,"SELECT * FROM tbl_cart WHERE userNo='$userNo'  ")or die(mysqli_error($conn));
            $cartNum = mysqli_num_rows($cartQry);
            $cartNum = $cartNum==0?"":$cartNum;
            
            
            $orderQry = mysqli_query($conn,"SELECT * FROM tbl_order WHERE userNo='$userNo'  ")or die(mysqli_error($conn));
            $orderNum = mysqli_num_rows($orderQry);
            $orderNum = $orderNum==0?"":$orderNum;
        ?>
        <?php if($verified==1){ ?><li><a href="#" data-toggle="modal" data-target="#startBusiness"><span class='fas fa-store-alt' ></span> MY STORE</a></li>  <?php } ?>
        <li><a href="my-cart.php" ><span class='fa fa-shopping-cart' ></span> MY CART <sup style='color:white;'><?php echo $cartNum;?></sup></a></li>  
        <li><a href="my-order.php" ><span class='fas fa-dolly' ></span> MY ORDERS <sup style='color:white;'><?php echo $orderNum;?></sup></a></li>  
        <li><a data-target="#logout-modal" data-toggle="modal"><span class='fa fa-sign-out-alt' ></span>SIGN OUT</a></li>
      </ul>
    </div>
  </div>
</nav>

<div class="jumbotron text-center"  >
    <div class='row'>
        <div class='col-sm-3' style=''>   
        <img src='../assets/image/agri-logo.png' style='height:60px; border-radius:50%;margin-top:-30px;' />
        <strong style='font-size:50px;color:darkgreen'>e-Baligya</strong>
        </div>
        <div class='col-sm-9'> 
            <div class='row' style='margin-top:25px;'>
                <div class='col-sm-12'> 
                    <div class='input-group'> 
                    <?php
                        $srchs  = "";
                        if(isset($_GET['srch'])){
                            $srchs = $_GET['srch']; 
                        } 
                    ?>
                        <input type='text' class='form-control input-lg' id='search' value='<?php echo $srchs;?>' placeholder='Search for the product you are looking for...' />
                        <div class='input-group-btn'>
                            <button class='btn btn-success btn-lg' onclick='searchProduct();'> 
                                &nbsp;
                                <i class='fa fa-search'></i>
                                 &nbsp;
                            </button>
                        </div>
                    </div> 
                </div>
                <div class='col-sm-12' style='text-align:left'> 
                    <span class='btn-cat'>Crops</span> | 
                    <span class='btn-cat'>Livestock products</span> | 
                    <span class='btn-cat'>Processed products</span> |
                    <span class='btn-cat'>Aquatic products</span> |
                    <span class='btn-cat'>Handicrafts products</span>  
                </div>
            </div>
        </div>
    </div> 
</div> 
<script>
    function searchProduct(){
        var srch = $("#search").val();
        window.location.href = "index.php?srch="+srch;
    }
</script> 
 
<!-- Container (products Section) -->
<div id="cart" class="container" style='margin-top:20px;padding-top:0px;'>
    <div class='row'>
        <div class='col-sm-12'> 
            <div class='col-sm-12' style='background-color:white;  overflow;auto'>
                <div class="row ">
                <?php
                      
                    $qry0 = mysqli_query($conn,"SELECT * FROM tbl_order  WHERE userNo='$userNo' GROUP BY (strNo) ")or die(mysqli_error($conn));
                    while($rw0 = mysqli_fetch_assoc($qry0)){
                        $strNo = $rw0['strNo'];
                        
                        $qry1 = mysqli_query($conn,"SELECT * FROM tbl_store WHERE no='$strNo'  ")or die(mysqli_error($conn));
                        $rw1  = mysqli_fetch_assoc($qry1);
                        $total = 0;
                        $store = $rw1['name'];
                    
                ?> 
                <div class='col-sm-12'> 
                        <div class='col-sm-12' style='background-color:white'>
                            
                            <div class='col-sm-12  ' style='overflow-x:auto; font-weight:bold;border-bottom:1px solid grey;padding:10px'>
                                <i class='fa fa-store'></i> <?php echo $store;?>
                            </div>
                            <br />
                            <br /> 
                            
                            <table  border=0 style='width:100%;'> 
                        <?php
                            $qry2 = mysqli_query($conn,"SELECT * FROM tbl_order  WHERE userNo='$userNo' AND strNo='$strNo'   ")or die(mysqli_error($conn));
                            while($rw2 = mysqli_fetch_assoc($qry2)){ 
                                $prodNo = $rw2['prodNo'];
                                $price  = $rw2['price'];
                                $qty    = $rw2['qty'];
                                
                                $qry3 = mysqli_query($conn,"SELECT * FROM tbl_product WHERE no='$prodNo' ")or die(mysqli_error($conn));
                                $rw3  = mysqli_fetch_assoc($qry3);
                                $status = $rw2['status'];
                                if($rw2['status']==0){ 
                                    $status = "<span style='color:orange;' >Waiting for seller to confirm. </span><br /><button class='btn btn-danger btn-xs'>Cancel order</button>";
                                     $total += $price*$qty;
                                     $unitPrice = "<span style=''>".number_format($price*$qty,2)."</span>";
                                }else if($rw2['status']==1){
                                    $status = "<span style='color:green;' >Order confirmed.</span>";
                                    $total += $price*$qty;
                                     $unitPrice = "<span style=''>".number_format($price*$qty,2)."</span>";
                                }else if($rw2['status']==2){
                                    $status = "<span style='color:red;' >Cancelled by you.</span> <br /><button class='btn btn-success btn-xs'>Re-order</button>";
                                     $unitPrice = "<s style='color:red;' >".number_format($price*$qty,2)."</s>";
                                }else if($rw2['status']==3){
                                    $status = "<span style='color:red;' >Cancelled by seller.</span>";
                                     $unitPrice = "<s style='color:red;' >".number_format($price*$qty,2)."</s>";
                                }
                        ?> 
                                <input type='hidden' id='unitPrice<?php echo $prodNo;?>' value='<?php echo $price;?>'> 
                                <input type='hidden' id='strNo<?php echo $prodNo;?>' value='<?php echo $strNo;?>'> 
                                <tr> 
                                    <td  style='padding:5px;width:120px;'>
                                        <img src='../assets/image/<?php echo $rw3['img'];?>' style='width:100px;height:100px;' alt='' />  
                                    </td>
                                    <td style='vertical-align:top;'>
                                        <table>
                                            <tr>
                                                <td style='padding:5px;color:black;'><strong><?php echo $rw3['name'];?></strong></td>
                                            </tr>
                                            <tr>
                                                <td style='padding:5px;font-size:9px;'>
                                                    <strong><?php echo substr($rw3['name'],0,50);?></strong>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td style='padding:5px;font-size:12px;'>x<?php echo $qty;?></td>
                                            </tr>
                                            <tr>
                                                <td style='padding:5px;font-size:12px;color:orange'><?php echo $status;?></td>
                                            </tr>
                                        </table>
                                    </td>  
                                    <td style='padding:5px;font-weight:bold;font-size:12px;vertical-align:middle; width:100px; text-align:right;color:darkgreen ' id='ttl<?php echo $prodNo;?>'> 
                                        &#8369; <?php echo $unitPrice;   ?>
                                    </td>
                                </tr>
                        <?php } ?>
                            </table> 
                            
                            <div class='col-sm-12  ' style='overflow-x:auto; font-weight:bold;border-top:1px solid lightgrey;padding:10px; text-align:right;font-size:20px; '>
                                  Total order: <span style='color:darkgreen'>&#8369; <?php echo number_format($total,2); ?></span>
                            </div>
                    </div> 
                </div>
                <?php
                      
                        
                    } 
                    
                    
                ?> 
                </div> 
                
            </div>
        </div>
    </div>
    
    <br />
    <br />
</div>

<!--LOGOUT MODAL-->
<div id="logout-modal" class="modal fade" role="dialog" style='z-index:999999'>
    <div class="modal-dialog  modal-md"  >  
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title" style='font-weight:bold; color:#192428'>
                    <img src='../assets/image/agri-logo.png' style='height:40px; border-radius:50%;' />
                    Express Wheel | Sign out
                </h4>
            </div>
            <div class="modal-body">  
                <div class='row'> 
                    <div class='col-sm-12'> 
                         Do you really want to continue?   
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <a type="button" class="btn btn-default" data-dismiss="modal">Cancel</a>
                <a type="button" class="btn btn-success" href="../index.php" >Sign out</a>
            </div>
        </div>
    </div>
</div>
<script>
    function buy(prodNo){
        var userNo = $("#userNo").val(); 
    }
    var ORDERLIST = [];
    function addOrder(prodNo){
        var i = ORDERLIST.indexOf(prodNo);
        if(i>=0){
            ORDERLIST.splice(i,1)
        }else{
            ORDERLIST.push(prodNo)
        }
        computeTotal();
    }
    
    function computeTotal(){
        var total = 0;
        for(var p in ORDERLIST ){
            var prodNo = ORDERLIST[p];
            var qty = parseInt($("#qty"+prodNo).val()); 
            var prc = parseFloat($("#unitPrice"+prodNo).val()); 
            console.log(qty, prc)
            total += qty * prc;
        }
        var ttl = total.toFixed(2)
        $("#itemNum").html(ORDERLIST.length)
        $("#total").html("&#8369; "+ttl)
    }
    function addQuatity(v, prodNo){
        var qty = parseInt($("#qty"+prodNo).val()); 
        var prc = parseFloat($("#unitPrice"+prodNo).val()); 
        qty += parseInt(v);
        if(qty<=0){
            qty = 1;
        }
        $("#qty"+prodNo).val(qty);
        var total = qty * prc;
        var ttl   = total.toFixed(2)
        $("#ttl"+prodNo).html("&#8369; "+ttl)
        computeTotal();
    }

     
    function orderProduct(){   
        form_data = new  FormData();  
        for(var p in ORDERLIST ){
            var prodNo = ORDERLIST[p];
            form_data.append("prodNo"+p,prodNo);
            form_data.append("qty"+p,$("#qty"+prodNo).val()); 
            form_data.append("prc"+p,$("#unitPrice"+prodNo).val());
            form_data.append("strNo"+p,$("#strNo"+prodNo).val()); 
        }
        form_data.append("num",ORDERLIST.length);
        $.ajax({
            url: "../query/order-product-from-cart.php",
            method: "POST",
            data: form_data,
            contentType: false,
            cache: false,
            processData: false,
            beforeSend: function(){
            },
            success: function(data){ 
                $("#order").html(data);
            }
        });
        return false;
    }
     
</script>
 

<script>
$(document).ready(function(){
  // Add smooth scrolling to all links in navbar + footer link
  $(".navbar a, footer a[href='#myPage']").on('click', function(event) {
    // Make sure this.hash has a value before overriding default behavior
    if (this.hash !== "") {
      // Prevent default anchor click behavior
      event.preventDefault();

      // Store hash
      var hash = this.hash;

      // Using jQuery's animate() method to add smooth page scroll
      // The optional number (900) specifies the number of milliseconds it takes to scroll to the specified area
      $('html, body').animate({
        scrollTop: $(hash).offset().top
      }, 900, function(){
   
        // Add hash (#) to URL when done scrolling (default click behavior)
        window.location.hash = hash;
      });
    } // End if
  });
  
  $(window).scroll(function() {
    $(".slideanim").each(function(){
      var pos = $(this).offset().top;

      var winTop = $(window).scrollTop();
        if (pos < winTop + 600) {
          $(this).addClass("slide");
        }
    });
  });
})
</script>

</body>
</html>