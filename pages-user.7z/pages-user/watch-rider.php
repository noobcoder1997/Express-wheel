<?php
    include '../components/comp-conn.php';

    $id = $_POST['id'];
    $lat;
    $lng;
    $query = mysqli_query($conn, "select * from tbl_user where no = '$id' ");
    while($row = mysqli_fetch_assoc($query)){
        $lat = $row['lat'];
        $lng = $row['lng'];
    }
    
    echo json_encode([$lat, $lng]);
?>