<?php
    include '../components/comp-conn.php';
    
    $q = mysqli_query($conn, "select status,rider_status from tbl_book_ride where id = ' $_POST[id]' ");
    while($row = mysqli_fetch_assoc($q)){
        
        if($row['status'] == '1' && $row['rider_status'] == '1'){
            echo 1;
        }        
    }

?>