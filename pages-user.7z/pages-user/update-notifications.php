<?php
    // Database connection
    include '../components/comp-conn.php';

    // Get user_id
    $user_id = $_POST['user_id'];
    
    // SQL query to count status = 0
    $sql = "SELECT COUNT(*) as count FROM tbl_notifications WHERE status = 0 AND user_id = '$user_id'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        // Output data of each row
        while($row = $result->fetch_assoc()) {
            $message = $row["count"];
        }
    } 

    echo $message;
?>