<!DOCTYPE html>
<HTML> 
<head> 
<TITLE>Wheel Express</TITLE>  
<link rel="icon" href="../assets/image/eMove.png">
<meta name="viewport" content="width=device-width, initial-scale=1.0"> 
<link rel="stylesheet" href="../lib/bootstrap/css/bootstrap.css">
<link rel="stylesheet" href="../lib/bootstrap/css/bootstrap.min.css">
<link rel="stylesheet" href="../lib/font-awesome-5/css/all.css">
<link rel="stylesheet" href="https://cdn.datatables.net/2.2.1/css/dataTables.dataTables.min.css">
<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.3/dist/leaflet.css" integrity="sha256-kLaT2GOSpHechhsozzB+flnD+zUyjE2LlfWPgU04xyI=" crossorigin="" />
<link rel="stylesheet" href="https://unpkg.com/leaflet-routing-machine@latest/dist/leaflet-routing-machine.css" />
<script src="../lib/jquery/jquery-1.11.3.js"></script>
<script src="../lib/bootstrap/js/bootstrap.min.js"></script>
<script src="https://cdn.datatables.net/2.2.1/js/dataTables.min.js"></script>
<script src="https://unpkg.com/leaflet@1.9.3/dist/leaflet.js" integrity="sha256-WBkoXOwTeyKclOHuWtc+i2uENFpDZ9YPdf5Hf+D7ewM=" crossorigin=""></script>
<script src="https://unpkg.com/leaflet-routing-machine@latest/dist/leaflet-routing-machine.js"></script>
<?php
    include "../components/comp-conn.php"; 
    // session_start();
    if(!isset($_SESSION['user_status'])){
        header('location: ../');
    }else{
        $userNo = $_SESSION['userNo'];
    } 
    
    $userQry = mysqli_query($conn,"SELECT * FROM tbl_user WHERE no='$userNo' ")or die(mysqli_error($conn));
    $userRw  = mysqli_fetch_assoc($userQry);
?>
</head>
<style>
    #map, #covermap { 
        height: 350px;
        background: #fff;
        border: 1px solid grey;
        box-shadow: 0 0 15px 0 #000;
    }
    
    img.end_huechange { filter: hue-rotate(270deg); }
    img.start_huechange { filter: hue-rotate(150deg); }
</style>
 <style>
  body {
    font: 400 15px Lato, sans-serif;
    line-height: 1.8;
    color: #818181;
    font-family: 'century gothic';
  }
  h2 {
    font-size: 24px;
    text-transform: uppercase;
    color: #303030;
    font-weight: 600;
    margin-bottom: 30px;
  }
  h4 {
    font-size: 19px;
    line-height: 1.375em;
    color: #303030;
    font-weight: 400;
    margin-bottom: 30px;
  }  
  .jumbotron {
    background-color: #414c50;
    color: #192428;
    padding: 40px 25px;
    padding-top:70px;
    font-family: Montserrat, sans-serif;
  }
  .container-fluid {
    padding: 40px 50px;
    width:100%;
    margin:0;
    position: relative;
  }
  .bg-grey {
    background-color: #414c50;
    color: #39ace7;
  }
  .logo-small {
    color: #192428;
    font-size: 50px;
  }
  .logo {
    color: darkgreen;
    font-size: 200px;
  }
  .thumbnail {
    padding: 0 0 15px 0;
    border: none;
    border-radius: 0;
  }
  .thumbnail img {
    width: 100%;
    height: 100%;
    margin-bottom: 10px;
  }
  .prod:hover{
     border:2px solid grey;
      cursor: pointer;
      transition-duration: .5s;
  }
  .carousel-control.right, .carousel-control.left {
    background-image: none;
    color: darkgreen;
  }
  .carousel-indicators li {
    border-color: darkgreen;
  }
  .carousel-indicators li.active {
    background-color: darkgreen;
  }
  .item h4 {
    font-size: 19px;
    line-height: 1.375em;
    font-weight: 400;
    font-style: italic;
    margin: 70px 0;
  }
  .item span {
    font-style: normal;
  }
  .panel {
    border: 1px solid darkgreen; 
    border-radius:0 !important;
    transition: box-shadow 0.5s;
  }
  .panel:hover {
    box-shadow: 5px 0px 40px rgba(0,0,0, .2);
  }
  .panel-footer .btn:hover {
    border: 1px solid darkgreen;
    background-color: #fff !important;
    color: darkgreen;
  }
  .panel-heading {
    color: #fff !important;
    background-color:darkgreen !important;
    padding: 25px;
    border-bottom: 1px solid transparent;
    border-top-left-radius: 0px;
    border-top-right-radius: 0px;
    border-bottom-left-radius: 0px;
    border-bottom-right-radius: 0px;
  }
  .panel-footer {
    background-color: white !important;
  }
  .panel-footer h3 {
    font-size: 32px;
  }
  .panel-footer h4 {
    color: #aaa;
    font-size: 14px;
  }
  .panel-footer .btn {
    margin: 15px 0;
    background-color:darkgreen;
    color: #fff;
  }
  .navbar {
    margin-bottom: 0;
    background-color: #192428;
    z-index: 9999;
    border: 0;
    font-size: 12px !important;
    line-height: 1.42857143 !important;
    letter-spacing: 4px;
    border-radius: 0;
    font-family: Montserrat, sans-serif;
  }
  .navbar li a, .navbar .navbar-brand {
    color: #fff !important;
  }
  .navbar-nav li a:hover, .navbar-nav li.active a {
    color: #192428 !important;
    background-color: #fff !important;
  }
  .navbar-default .navbar-toggle {
    border-color: transparent;
    color: #fff !important;
  }
  footer .glyphicon {
    font-size: 20px;
    margin-bottom: 10px;
    color: #192428;
  }
  .slideanim {visibility:hidden;}
  .slide {
    animation-name: slide;
    -webkit-animation-name: slide;
    animation-duration: 1s;
    -webkit-animation-duration: 1s;
    visibility: visible;
  }
  @keyframes slide {
    0% {
      opacity: 0;
      transform: translateY(70%);
    } 
    100% {
      opacity: 1;
      transform: translateY(0%);
    }
  }
  @-webkit-keyframes slide {
    0% {
      opacity: 0;
      -webkit-transform: translateY(70%);
    } 
    100% {
      opacity: 1;
      -webkit-transform: translateY(0%);
    }
  } 
    p#order, p#track{
        margin: 50px 0;font-weight:bold; font-size:60px;
    }
    .order-icon, .track-icon, .ride-icon{
        font-size:70px
    }
    .card{
        background: #fff;
        border: 1px solid grey;
        border-radius: 15px;
        box-shadow: 0 0 15px 0 #000;
    }
  @media screen and (max-width: 480px) {
    .logo {
      font-size: 150px;
    }
    body{
        width: 100%;
    }
    .order{
        margin:15px 0 0 0 ;
    }
    p#order, p#track{
        font-size:50px;
        margin: 0;
    }
    .order-icon, .track-icon, .ride-icon{
        font-size:50px
    }
  }
  
 .cat-btn{
     background-color: white;
 }
.cat-btn:hover{ 
    border:1px solid black;
    background-color: lightgreen;
    cursor: pointer;
    transition-duration: 1s;
    
}
.star-checked{
    color: #39ace7;
}
.stars{
    font-size: 30px;
}
.btn-block{
    width: 100%;
}
.btn:hover, .btn:active{
    transform: scale(1.03);
}
.my-btn:hover, .my-btn:active{
    transform: scale(1.03);
}
.alert-default{
    background-color: #fff;
}
.btn{
    font-weight: bolder;
}
  </style>
</head>
<!-- -->
<body id="myPage" data-spy="scroll" data-target=".navbar" data-offset="60">

<nav class="navbar navbar-default navbar-fixed-top">
  <div class="container">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
      <a class="navbar-brand" href="#myPage">
          <table>
              <tr>
                  <td> 
                    <img src='../assets/image/eMove.png' style=' height:25px; border-radius:50%;' /> 
                     
                  </td>
                  <td style='color:white;font-weight:bold;'>&nbsp;<?php  echo $userRw['user'];?></td>
                  <input type='hidden' id='userNo' value='<?php echo $userNo;?>' /> 
              </tr>
          </table>
      </a>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav navbar-right">
        <li><a class="my-btn" href="index.php" ><span class='fa fa-home fa-fw' ></span>&nbsp;HOME </a></li>  
        <li><a class="my-btn" href="my-trasaction.php" ><span class='fas fa-clipboard-check fa-fw' ></span>&nbsp;HISTORY </a></li>  
        <li><a class="my-btn" href="my-notifications.php" ><span class='fa fa-bell' ></span>&nbsp;NOTIFICATIONS </a></li> 
        <li><a class="my-btn" href="my-account.php" ><span class='fa fa-user fa-fw' ></span>&nbsp;ME </a></li>  
        <li><a class="my-btn" data-target="#logout-modal" data-toggle="modal"><span class='fa fa-sign-out-alt fa-fw' ></span>&nbsp;EXIT </a></li>
      </ul>
    </div>
  </div>
</nav>

<div class="jumbotron text-center">
    <BR />
    <br />
    <div class='row'>
        <div class='col-sm-6'>   
        <img src='../assets/image/eMove.png' style='height:100px; border-radius:50%;margin-top:-30px;' />
        <strong style='font-size:45px;color:#39ace7'>Express&nbsp;Wheel</strong> 
        </div>
        <div class='col-sm-6'> 
            <div class='row' style='font-size:2em; font-family: "Comic Sans MS"; color: white '>
                <div class='col-sm-12'> 
                Connecting communities, delivering convenience
                </div> 
            </div>
        </div>
    </div> 
</div> 
<!-- Container () -->
<div id="order" class="container-fluid bg-grey"  style="margin:0; padding:0;color:#0784b5;">
    <div class="row" style="margin-bottom: 20px;margin-top:20px;margin-left:5px;margin-right:5px">
        <?php
            $query = mysqli_query($conn, "select * from tbl_transactions where passenger_id = '$userNo' order by id desc");
            if(mysqli_num_rows($query) > 0){
                while($row = mysqli_fetch_assoc($query)){
                    if($row['status']=='1'){ //Successful ride
                    ?>
                    <div class="col-sm-6 col-sm-offset-3">
                        <div class="alert alert-default" style="border-radius:10px; box-shadow:0 0 15px 0 #000">
                            <h4 style="margin-bottom:0"><strong>SUCCESSFUL</strong></h4>
                            <p style="position: absolute; right:9%;top:15px;font-weight:bold"><?php echo$row['date']; ?></p>
                            <p>From: <?php echo$row['_from']; ?></p>
                            <p>To: <?php echo$row['_to']; ?></p>
                            <hr style="margin:0">
                            <p style="font-weight:bolder;font-size:20px;">Fare: &#8369; <?php echo$row['fare']; ?></p>
                        </div>
                    </div>
                    <?php
                    }
                    else{
                    ?>
                    <div class="col-sm-6 col-sm-offset-3">
                        <div class="alert alert-danger" style="border-radius:10px; box-shadow:0 0 15px 0 #000">
                            <h4 style="margin-bottom:0"><strong>CANCELLED</strong></h4>
                            <p style="position: absolute; right:9%;top:15px;font-weight:bold"><?php echo$row['date']; ?></p>
                            <p>From: <?php echo$row['_from']; ?></p>
                            <p>To: <?php echo$row['_to']; ?></p>
                            <hr style="margin:0">
                            <p style="font-weight:bolder;font-size:20px;">Fare: &#8369; 0.00</p>
                        </div>
                    </div>            
                    <?php
                    }
                }
            }
            else{
            ?>
                <div class="col-sm-6 col-sm-offset-3">
                    <h3>No Transactions yet...</h3>
                </div>
            <?php
            }
        ?>
    </div> 
</div>

<footer class="container-fluid text-center mobile-view" style='background-color:#0784b5;'>
    <a href="#myPage" title="To Top" class="toTop">
        <span class="glyphicon glyphicon-chevron-up"></span>
    </a>
    <div class="row home-mobile-view" style="display: none">
       <a href="index.php" style="color:#000; margin:0 5%; font-size: 25px"><span class="fa fa-home fa-fw"></span></a>
       <a href="my-trasaction.php" style="color:#000; margin:0 5%; font-size: 25px"><span class="fas fa-clipboard-check fa-fw"></span></a>
       <a href="my-notifications.php" style="color:#000; margin:0 5%; font-size: 25px"><span class="fas fa-bell fa-fw"></span></a>
       <a href="my-account.php" style="color:#000; margin:0 5%; font-size: 25px"><span class="fa fa-user fa-fw"></span></a>
       <a href="#logout-modal" data-toggle="modal" style="color:#000; margin:0 5%; font-size: 25px"><span class="fa fa-sign-out-alt fa-fw"></span></a>
    </div>
    <script>
       setInterval(()=>{
           if(screen.width <= 480){
               $('.mobile-view').removeClass('container-fluid').addClass('container').css({'padding':'10px 20px','bottom':'0','position':'fixed','width':'100%'});
               $('.home-mobile-view').css('display','block')
               $('.toTop').css('display','none')
               $('div#order').css('margin-bottom', '65px')
               $('.navbar-toggle').css('display','none');
           } 
           else{
               $('.mobile-view').addClass('container-fluid').removeClass('container');
               $('.home-mobile-view').css('display','none')
               $('.toTop').css('display','block')
           }
       },100)
    </script>
</footer>

<div id="modal"></div>

<!--<button type="button" class="btn btn-danger" data-toggle="modal" data-target="#mymodal">Opnen Modal</button>-->

<!--The Logout Modal-->
<div id="logout-modal" class="modal fade" role="dialog" style='z-index:999999'>
    <div class="modal-dialog  modal-md"  >  
        <div class="modal-content">
            <div class="modal-header text-center">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title" style='font-weight:bold; color:#192428'>
                    <img src='../assets/image/eMove.png' style='height:40px; border-radius:50%;' />
                    Express Wheel | Sign out
                </h4>
            </div>
            <div class="modal-body">  
                <div class='row'> 
                    <div class='col-sm-12'> 
                         Do you really want to continue?   
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <div class='row'>
                    <div class='col-sm-12'>
                        <a type="button" class="btn btn-default btn-block" data-dismiss="modal">Cancel</a>
                        <a type="button" class="btn btn-success btn-block" href="logout.php" >Sign out</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div> 
<script type="text/javascript">
    $( document ).ready( function(){ 
        history.pushState(null,  document.title, location.href);        
    });
</script>
<script>
$(document).ready(function(){
  // Add smooth scrolling to all links in navbar + footer link
  $(".navbar a, footer a[href='#myPage']").on('click', function(event) {
    // Make sure this.hash has a value before overriding default behavior
    if (this.hash !== "") {
      // Prevent default anchor click behavior
      event.preventDefault();

      // Store hash
      var hash = this.hash;

      // Using jQuery's animate() method to add smooth page scroll
      // The optional number (900) specifies the number of milliseconds it takes to scroll to the specified area
      $('html, body').animate({
        scrollTop: $(hash).offset().top
      }, 900, function(){
   
        // Add hash (#) to URL when done scrolling (default click behavior)
        window.location.hash = hash;
      });
    } // End if
  });
  
  $(window).scroll(function() {
    $(".slideanim").each(function(){
      var pos = $(this).offset().top;

      var winTop = $(window).scrollTop();
        if (pos < winTop + 600) {
          $(this).addClass("slide");
        }
    });
  });
})

</script>
</body>
</html>