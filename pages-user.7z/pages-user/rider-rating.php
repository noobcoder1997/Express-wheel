<?php 
    include '../components/comp-conn.php';

    $passenger = $_POST['id']; 
    $rider = $_POST['rider'];
    $review = $_POST['comment'];
    $rate = $_POST['rate'];

    $exist_query = mysqli_query($conn, "select COUNT(*) as existed from tbl_rider_rating where passenger_id = '$passenger' and rider_id = '$rider' ");

    while($result = mysqli_fetch_assoc($exist_query)){
        if($result['existed'] > 0){
            // has an existing data
            mysqli_query($conn, "update tbl_rider_rating set rating = '$rate', comment = '$review' where passenger_id = '$passenger' and rider_id = '$rider' ");
        }
        else{
            //no existing data
            mysqli_query($conn, "insert into tbl_rider_rating (passenger_id, rider_id, rating, comment) values ('$passenger','$rider','$rate','$review')");
        }
    }
?>