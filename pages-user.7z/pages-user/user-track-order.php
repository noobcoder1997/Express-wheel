<?php
    include "../components/comp-conn.php";
        
    $order_number = htmlentities($_POST['order-number']);
    
    $stmt=$conn->prepare("SELECT * FROM tbl_user_make_order WHERE order_number = ? and status <> '2' and rider_status <> '2' order by _timestamp desc");
    $stmt->bind_param("s", $order_number);
    $stmt->execute();
    $result=$stmt->get_result();

    if(mysqli_num_rows($result) > 0){
        
        while($res0 = $result->fetch_assoc()){
            
            $query0 = mysqli_query($conn, "SELECT id FROM tbl_brgy WHERE brgyDesc = '$res0[sender_barangay]' ");
            $query1 = mysqli_query($conn, "SELECT id FROM tbl_brgy WHERE brgyDesc = '$res0[recipient_barangay]' ");
            
            $row0 = mysqli_fetch_assoc($query0);
            $row1 = mysqli_fetch_assoc($query1);
            $row0['id'];

            $query2 = mysqli_query($conn, "SELECT latitude, longitude FROM tbl_brgy_position WHERE brgy_id = '$row0[id]' "); //sender lat,lng
            $query3 = mysqli_query($conn, "SELECT latitude, longitude FROM tbl_brgy_position WHERE brgy_id = '$row1[id]' "); //recipient lat,lng
            
            $row2 = mysqli_fetch_assoc($query2);
            $row3 = mysqli_fetch_assoc($query3);
            
            $sender_lat = $row2['latitude'];
            $sender_lng = $row2['longitude'];
            $recipient_lat = $row3['latitude'];
            $recipient_lng = $row3['longitude'];
            
            $query4 = mysqli_query($conn, "SELECT lat, lng FROM tbl_user WHERE no = '$res0[rider_id]' and position = '1' "); //recipient lat,lang
            $row4 = mysqli_fetch_assoc($query4);
            $rider_lat = $row4['lat'];
            $rider_lng = $row4['lng'];
            
            echo json_encode([
                    $sender_lat,
                    $sender_lng,
                    $recipient_lat,
                    $recipient_lng,
                    $rider_lat,
                    $rider_lng
                            ]);            
        }

    }
    else{
        echo 0; //Invalid Order number
    }
    
?>