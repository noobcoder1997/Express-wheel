<script>
console.log("user-contact.jssss");
function addContactForm(userNo,schlNo){
    var form = "<form action='' onsubmit='return addingContact();' >";
    form +="<div class='row'>";
    form += "<div class='col-sm-4 col-sm-offset-1'>";
    form += "Service Provider";
    form += "<input type='text'   id='sp' required placeholder='Service Provider' class='form-control' />";
    form += "<input type='hidden' id='userNo' value='"+userNo+"' class='form-control' />"; 
    form += "<input type='hidden' id='schlNo' value='"+schlNo+"' class='form-control' />"; 
    form += "</div>"; 
    form += "<div class='col-sm-5'>";
    form += "Cellphone/Telephone";
    form += "<input type='text' id='num'required placeholder='Cellphone/Telephone Number' class='form-control' />";
    form += "</div>";
    form += "</div>";
    form += "<br /><div class='row'>";
    form += "<div class='col-sm-10 text-right'>";
    form += "<button type='button' class='btn btn-default btn-sm' onclick='closeModal()'> <i class='fa fa-times'></i> Cancel</button> ";
    form += "<button  class='btn btn-success btn-sm'> <i class='fa fa-save'></i> Save</button>";
    form += "</div>";  
    form += "</div>";
    form +="</form>";
    showModal("Adding New Contact Number",form,0)

}
  
function editContact(userNo,schlNo,no,sp,num){
        var form = "<form action='' onsubmit='return updateContact();' >";
        form +="<div class='row'>";
        form += "<div class='col-sm-4 col-sm-offset-1'>";
        form += "Service Provider";
        form += "<input type='text'   id='sp' value='"+sp+"' class='form-control' />";
        form += "<input type='hidden' id='userNo' value='"+userNo+"' class='form-control' />";
        form += "<input type='hidden' id='schlNo' value='"+schlNo+"' class='form-control' />";
        form += "<input type='hidden' id='rNo' value='"+no+"' class='form-control' />";
        form += "</div>"; 
        form += "<div class='col-sm-5'>";
        form += "Cellphone/Telephone";
        form += "<input type='text' id='num' value='"+num+"' class='form-control' />";
        form += "</div>";
        form += "</div>";
        form += "<br /><div class='row'>";
        form += "<div class='col-sm-10 text-right'>";
        form += "<button type='button' class='btn btn-default btn-sm' onclick='closeModal()'> <i class='fa fa-times'></i> Cancel</button> ";
        form += "<button  class='btn btn-success btn-sm'> <i class='fa fa-save'></i> Save</button>";
        form += "</div>";  
        form += "</div>";
        form +="</form>";
        showModal("Editing Contact Number",form,0)
    }

function deleteContactForm(userNo,schlNo,no,sp,num){ 
        var form = "<form action='' onsubmit='return deleteContact();' >";
        form += "<div class='row'>";
        form += "<div class='col-sm-4 col-sm-offset-1'>";
        form += "</div></div><br />"
        form += "<div class='row'>";
        form += "<div class='col-sm-4 col-sm-offset-1'>";
        form += "Service Provider";
        form += "<input type='text' readonly  id='sp' value='"+sp+"' class='form-control' />"; 
        form += "<input type='hidden' id='rNo' value='"+no+"' class='form-control' />";
        form += "<input type='hidden' id='userNo' value='"+userNo+"' class='form-control' />";
        form += "<input type='hidden' id='schlNo' value='"+schlNo+"' class='form-control' />";
        form += "</div>"; 
        form += "<div class='col-sm-5'>";
        form += "Cellphone/Telephone";
        form += "<input type='text' readonly id='num' value='"+num+"' class='form-control' />";
        form += "</div>";
        form += "</div>";
        form += "<br /><div class='row'>";
        form += "<div class='col-sm-10 text-right'>";
        form += "<button type='button' class='btn btn-default btn-sm' onclick='closeModal()'> <i class='fa fa-times'></i> Cancel</button> ";
        form += "<button  class='btn btn-danger btn-sm'> <i class='fa fa-trash'></i> Delete</button>";
        form += "</div>";  
        form += "</div>";
        form +="</form>";
        showModal("Deleting Contact Number",form,0)
    }



function deleteContact(){
     var form_data = new  FormData();  
        form_data.append("no",$("#rNo").val()); 
        form_data.append("userNo",$("#userNo").val());
        form_data.append("schlNo",$("#schlNo").val());
    $.ajax({
            url: "../include/delete-contact-number.php",
            method: "POST",
            data: form_data,
            contentType: false,
            cache: false,
            processData: false,
            beforeSend: function(){ 
            },
            success: function(data){ 
                var rslt    = data.toString();
                rslt        = rslt.split("+"); 
                messageBox(rslt[0],rslt[1],rslt[2]);
                closeModal()
            },
            error:function(){

            }
        });
    return false;
}
    


function updateContact(){  
    var form_data = new  FormData(); 
        form_data.append("sp",$("#sp").val());
        form_data.append("num",$("#num").val()); 
        form_data.append("userNo",$("#userNo").val());
        form_data.append("schlNo",$("#schlNo").val());
        form_data.append("no",$("#rNo").val()); 
    $.ajax({
            url: "../include/update-contact-number.php",
            method: "POST",
            data: form_data,
            contentType: false,
            cache: false,
            processData: false,
            beforeSend: function(){ 
            },
            success: function(data){ 
                var rslt    = data.toString();
                rslt        = rslt.split("+"); 
                messageBox(rslt[0],rslt[1],rslt[2]);
                closeModal()
            },
            error:function(){

            }
        });
    return false;
}



function addingContact(){  
    console.log($("#schlNo").val())
    var form_data = new  FormData(); 
        form_data.append("sp",$("#sp").val());
        form_data.append("num",$("#num").val()); 
        form_data.append("userNo",$("#userNo").val()); 
        form_data.append("schlNo",$("#schlNo").val()); 
    $.ajax({
            url: "../include/adding-contact-number.php",
            method: "POST",
            data: form_data,
            contentType: false,
            cache: false,
            processData: false,
            beforeSend: function(){ 
            },
            success: function(data){ 
                var rslt    = data.toString();
                rslt        = rslt.split("+"); 
                messageBox(rslt[0],rslt[1],rslt[2]);
                closeModal()
            },
            error:function(){

            }
        });
    return false;
}
</script>