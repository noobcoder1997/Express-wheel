<?php
    include "../components/comp-conn.php";
    session_start();
    
    $ufnim=$_POST['ufnim'];
    $umnim=$_POST['umnim'];
    $ulnim=$_POST['ulnim'];
    $ubday=$_POST['ubday'];
    $ucno=$_POST['ucno'];
    $upurok=$_POST['upurok'];
    $ubrgy=$_POST['ubrgy'];
    $umun=$_POST['umun'];
    $uzcode=$_POST['uzcode'];
    $ulmark=$_POST['ulmark'];
    $upass=$_POST['upass'];
    $ucpass=$_POST['ucpass'];
    $uemail=$_POST['uemail'];
    $uunim=$_POST['uunim'];
    $usex=$_POST['usex'];
    $id=$_POST['id'];
    $message;
    
    if($ufnim == null || $ulnim == null){
        $message='<div class="alert alert-warning">
                    <strong>Error Input:</strong>
                    Fields should not leave empty! Please try again.
                </div>';
    }
    else if($upass != $ucpass){
        $message='<div class="alert alert-warning">
            <strong>Error Password:</strong>
            Password did not match! Please try again.
        </div>';
    }
    else{
        $md5pass = md5($upass);
        $query = "select * from tbl_user where user = '$uunim' and pass = '$md5pass' and no <> '$id'";
        $result = mysqli_query($conn, $query);
        if(mysqli_num_rows($result)>0){
            $message='<div class="alert alert-warning">
                    <strong>Error user id:</strong>
                    Username and password is already in use. Please make another username and password.
                </div>';
        }
        else{
            if(!empty($upass)){
                $upass = md5($upass);
                $string="update tbl_user set fn = '$ufnim', mn = '$umnim', ln = '$ulnim', bday = '$ubday', contact = '$ucno', sex = '$usex', purok = '$upurok', municipal = '$umun', zipcode = '$uzcode', landmark = '$ulmark', email = '$uemail', user = '$uunim', pass = '$upass' where no = '$id'";
                mysqli_query($conn, $string);

                $message='<div class="alert alert-success">
                            <strong>User updated:</strong>
                            You have updated a user!
                        </div>';
                $sucess=0;
            }
            else{
                $string="update tbl_user set fn = '$ufnim', mn = '$umnim', ln = '$ulnim', bday = '$ubday', contact = '$ucno', sex = '$usex', purok = '$upurok', municipal = '$umun', zipcode = '$uzcode', landmark = '$ulmark', email = '$uemail', user = '$uunim' where no = '$id' ";
                mysqli_query($conn, $string);
                $message='<div class="alert alert-success">
                            <strong>User updated:</strong>
                            You have updated a user!
                        </div>'; 
                $sucess=0;        
            }  
        }
    }

    echo json_encode([$message, $sucess]);
?>