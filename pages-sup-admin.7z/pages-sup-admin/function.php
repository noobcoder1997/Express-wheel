

<script>
    function send_package(order_id){
        $('#send-package-'+order_id).modal('toggle');
    }
    
    function package_arrive(order_id){
        $("#arrival-branch"+order_id).modal('toggle');
    }
    
    function out_for_delivery(order_id){
        $("#out-for-delivery"+order_id).modal('toggle');
    }
    
    function package_arrived(order_id){
        $.ajax({
            data: "order_id="+$('#order-id'+order_id).val()+"&branch_id="+$('#select-branch-arrival'+order_id+' :selected').text(),
            method: "POST",
            url: "package-arrived.php",
        }).done( function(data) {
            $("#package-update-message-0-"+order_id).html(data);
            // console.log(data);
        })
    }
    
    function package_sent(order_id){
        $.ajax({
            data: "order_id="+$('#order-id'+order_id).val()+"&branch_id="+$('#select-branch-arrival'+order_id+' :selected').text(),
            method: "POST",
            url: "package-sent.php",
        }).done( function(data) {
            $("#package-update-message-1-"+order_id).html(data);
            // console.log(data);
        })
    }
    
        function package_deliver(order_id){
        $.ajax({
            data: "order_id="+$('#order-id'+order_id).val()+"&rider="+$('#select-rider'+order_id+' :selected').text(),
            method: "POST",
            url: "package-deliver.php",
        }).done( function(data) {
            $("#package-update-message-2-"+order_id).html(data);
            // console.log(data);
        })
    }
</script>