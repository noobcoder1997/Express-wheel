<?php
    include '../components/comp-conn.php';
    
    $id = $_POST['id'];

    // update user to become a rider
    mysqli_query($conn, "update tbl_user set position = 1, applicant = 0, img0 = '', img1 = '' where no = '$id' ");

    //notify user for successful application
    $message="Hello! Thank your for applying as a rider in Express wheel. After a keen checking your application we are glad that you have passed the application.";
    $title="Rider Application Passed!";

    mysqli_query($conn, "insert into tbl_notifications (message, title, user_id) values ('$message','$title','$id')");

    echo "User application passed!";
?>