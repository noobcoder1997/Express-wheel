<?php
    include '../components/comp-conn.php';
    
    $id = $_POST['id'];

    // update user table
    mysqli_query($conn, "update tbl_user set img0 = '', img1 = '', applicant = 0 where no = '$id' ");
    
    // notify user for failed application
    $message="Good day! Thank your for applying as a rider in Express wheel. After a keen checking your application we are sorry that you have failed to meet the requirements for the position.";
    $title="Rider Application Failed";

    mysqli_query($conn, "insert into tbl_notifications (message, title, user_id) values ('$message','$title','$id')");
   
    echo "User application failed!";
?>