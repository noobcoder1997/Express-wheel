<?php
    include "../components/comp-conn.php";
    session_start();
    
    $fnim=$_POST['fnim'];
    $mnim=$_POST['mnim'];
    $lnim=$_POST['lnim'];
    $branch=$_POST['branch'];
    $unim=$_POST['unim'];
    $pass=$_POST['pass'];
    $cpass=$_POST['cpass'];
    $position='admin';
    $message;
    
    if($cpass != $pass){
        $message='<div class="alert alert-warning">
                    <strong>Error Password:</strong>
                    Password did not match! Please try again.
                </div>';
    }
    else if($fnim == null || $lnim == null || $branch == null || $unim == null || $pass == null || $cpass == null){
        $message='<div class="alert alert-warning">
                    <strong>Error Input:</strong>
                    Fields should not leave empty! Please try again.
                </div>';
    }
    else{
        if($pass == $cpass){
            $pass = md5($pass);
            $stmt=$conn->prepare("INSERT INTO tbl_admin (f_name, m_name, l_name, username, password, branch_id, position) VALUES (?,?,?,?,?,?,?)");
            $stmt->bind_param("sssssss",$fnim,$mnim,$lnim,$unim,$pass,$branch,$position);
            $stmt->execute();
            $message='<div class="alert alert-success">
                        <strong>Admin Added:</strong>
                        You have added a new admin!
                    </div>';             
        }
  
    }

    echo $message;
?>