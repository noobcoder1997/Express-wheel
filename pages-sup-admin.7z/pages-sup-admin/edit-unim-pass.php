<?php

    include "../components/comp-conn.php";

    $unim = $_POST['unim'];
    $new_pass = $_POST['new_pass'];
    $confirm_pass = $_POST['confirm_pass'];
    $id = $_POST['id'];
    $message = "";

    if($new_pass <> '' || $confirm_pass <> ''){

        if($new_pass == $confirm_pass){

            $pass = md5($new_pass);
            
            $query = "UPDATE tbl_user SET pass = '$pass', user = '$unim' WHERE no = '$id'";
            mysqli_query($conn, $query);
            
            $message = "<div class='alert alert-success'>
                            <strong>Success:</strong> You have updated your password!
                        </div>";
        } 
        else if($new_pass <> $confirm_pass){
            $message = "<div class='alert alert-danger'>
                            <strong>Error:</strong> Password not match!
                         </div>";
        }     
    }
    else if($unim <> ''){
        $query = "UPDATE tbl_user SET user = '$unim' WHERE no = '$id'";
        mysqli_query($conn, $query);
        
        $message = "<div class='alert alert-success'>
                        <strong>Success:</strong> You have updated your username!
                    </div>";
    } 
    else if($unim == ''){
        $message = "<div class='alert alert-warning'>
                        <strong>Error:</strong> Please enter your username!
                    </div>";
    }
    
    echo $message;
?>