<?php
    include "../components/comp-conn.php";

    $fn = $_POST['fn'];
    $mn = $_POST['mn'];
    $ln = $_POST['ln'];
    $sex = $_POST['sex'];
    $bday = $_POST['bday'];
    $id = $_POST['id'];
    $message = "";

    if($fn == '' || $ln == '' || $sex == '' || $bday == ''){
        $message = "<div class='alert alert-danger'>
                        <strong>Error:</strong> Fields should not leave empty!
                     </div>";
    }
    else{

        mysqli_query($conn, "UPDATE tbl_user SET fn = '$fn', mn = '$mn', ln = '$ln', sex = '$sex', bday = '$bday' WHERE no = '$id'");

        $message = "<div class='alert alert-success'>
                        <strong>Success:</strong> You have successfully updated your personal information!
                     </div>";
    }

    echo $message;
?>