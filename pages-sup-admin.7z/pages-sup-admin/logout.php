<?php

    session_start();
    unset($_SESSION['sup_admin_status']);
    session_destroy();
    header('location: ../');
?>