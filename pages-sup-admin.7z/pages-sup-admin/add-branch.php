<?php

    include "../components/comp-conn.php";
    session_start();
    
    $name = htmlentities($_POST['branch-name']);
    $location = htmlentities($_POST['branch-location']);
    $status = '1';
    
    $stmt=$conn->prepare("INSERT INTO tbl_branch (branch_name, location, status) VALUES (?,?,?)");
    $stmt->bind_param("sss",$name,$location,$status);
    $stmt->execute();
    $message='<div class="alert alert-success">
                <strong>Branch Added:</strong>
                You have added a new branch!
            </div>';

    echo $message;
?>