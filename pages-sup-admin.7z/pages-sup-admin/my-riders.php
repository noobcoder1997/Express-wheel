<!DOCTYPE html>
<HTML> 
<head> 
<TITLE>Wheel Express</TITLE>  
<link rel="icon" href="../assets/image/eMove.png">
<meta name="viewport" content="width=device-width, initial-scale=1.0"> 
<link rel="stylesheet" href="../lib/bootstrap/css/bootstrap.css">
<link rel="stylesheet" href="../lib/bootstrap/css/bootstrap.min.css">
<link rel="stylesheet" href="../lib/font-awesome-5/css/all.css">
<script src="../lib/jquery/jquery-1.11.3.js"></script>
<script src="../lib/bootstrap/js/bootstrap.min.js"></script>
<link href="https://cdn.datatables.net/v/dt/dt-2.2.2/datatables.min.css" rel="stylesheet">
<script src="https://cdn.datatables.net/v/dt/dt-2.2.2/datatables.min.js"></script>
<?php
    include "../components/comp-conn.php"; 
    // session_start();
    if(!isset($_SESSION['sup_admin_status'])){
        header('location: ../');
    }
    
    $userNo =  "NO USER NUMBER".$_SESSION['userNo'];
    if(!isset($_SESSION['userNo'])){
        ?>
        <script>
            window.location.href='../';
        </script>
        <?php
    }else{
        $userNo = $_SESSION['userNo'];
    } 
    
    $userQry = mysqli_query($conn,"SELECT * FROM tbl_user WHERE no='$userNo' ")or die(mysqli_error($conn));
    $userRw  = mysqli_fetch_assoc($userQry);
?>
</head>
 <style>
  body {
    font: 400 15px Lato, sans-serif;
    line-height: 1.8;
    color: #818181;
    font-family: 'century gothic';
    overflow-x: hidden;
  }
  h2 {
    font-size: 24px;
    text-transform: uppercase;
    color: #303030;
    font-weight: 600;
    margin-bottom: 30px;
  }
  h4 {
    font-size: 19px;
    line-height: 1.375em;
    color: #303030;
    font-weight: 400;
    margin-bottom: 30px;
  }  
  .jumbotron {
    background-color: #414c50;
    color: #192428;
    padding: 40px 25px;
    padding-top:70px;
    font-family: Montserrat, sans-serif;
  }
  .container-fluid {
    padding: 40px 50px;
    width:100%;
    margin:0;
    position: relative;
  }
  .bg-grey {
    background-color: #414c50;
    color: #39ace7;
  }
  .logo-small {
    color: #192428;
    font-size: 50px;
  }
  .logo {
    color: darkgreen;
    font-size: 200px;
  }
  .thumbnail {
    padding: 0 0 15px 0;
    border: none;
    border-radius: 0;
  }
  .thumbnail img {
    width: 100%;
    height: 100%;
    margin-bottom: 10px;
  }
  .prod:hover{
     border:2px solid grey;
      cursor: pointer;
      transition-duration: .5s;
  }
  .carousel-control.right, .carousel-control.left {
    background-image: none;
    color: darkgreen;
  }
  .carousel-indicators li {
    border-color: darkgreen;
  }
  .carousel-indicators li.active {
    background-color: darkgreen;
  }
  .item h4 {
    font-size: 19px;
    line-height: 1.375em;
    font-weight: 400;
    font-style: italic;
    margin: 70px 0;
  }
  .item span {
    font-style: normal;
  }
  .panel {
    border: 1px solid darkgreen; 
    border-radius:0 !important;
    transition: box-shadow 0.5s;
  }
  .panel:hover {
    box-shadow: 5px 0px 40px rgba(0,0,0, .2);
  }
  .panel-footer .btn:hover {
    border: 1px solid darkgreen;
    background-color: #fff !important;
    color: darkgreen;
  }
  .panel-heading {
    color: #fff !important;
    background-color:darkgreen !important;
    padding: 25px;
    border-bottom: 1px solid transparent;
    border-top-left-radius: 0px;
    border-top-right-radius: 0px;
    border-bottom-left-radius: 0px;
    border-bottom-right-radius: 0px;
  }
  .panel-footer {
    background-color: white !important;
  }
  .panel-footer h3 {
    font-size: 32px;
  }
  .panel-footer h4 {
    color: #aaa;
    font-size: 14px;
  }
  .panel-footer .btn {
    margin: 15px 0;
    background-color:darkgreen;
    color: #fff;
  }
  .navbar {
    margin-bottom: 0;
    background-color: #192428;
    z-index: 9999;
    border: 0;
    font-size: 12px !important;
    line-height: 1.42857143 !important;
    letter-spacing: 4px;
    border-radius: 0;
    font-family: Montserrat, sans-serif;
  }
  .navbar li a, .navbar .navbar-brand {
    color: #fff !important;
  }
  .navbar-nav li a:hover, .navbar-nav li.active a {
    color: #192428 !important;
    background-color: #fff !important;
  }
  .navbar-default .navbar-toggle {
    border-color: transparent;
    color: #fff !important;
  }
  footer .glyphicon {
    font-size: 20px;
    margin-bottom: 10px;
    color: #192428;
  }
  .slideanim {visibility:hidden;}
  .slide {
    animation-name: slide;
    -webkit-animation-name: slide;
    animation-duration: 1s;
    -webkit-animation-duration: 1s;
    visibility: visible;
  }
  @keyframes slide {
    0% {
      opacity: 0;
      transform: translateY(70%);
    } 
    100% {
      opacity: 1;
      transform: translateY(0%);
    }
  }
  @-webkit-keyframes slide {
    0% {
      opacity: 0;
      -webkit-transform: translateY(70%);
    } 
    100% {
      opacity: 1;
      -webkit-transform: translateY(0%);
    }
  } 
    p#order, p#track{
        margin: 50px 0;font-weight:bold; font-size:60px;
    }
    .order-icon, .track-icon{
        font-size:70px
    }
    #content1{
        display:none;
    }
  @media screen and (max-width: 480px) {
    .logo {
      font-size: 150px;
    }
    body{
        width: 100%;
    }
    .order{
        margin-bottom: 40px;
    }
    p#order, p#track{
        font-size:50px;
    }
    .order-icon, .track-icon{
        font-size:50px
    }
    .delete-branch{
        margin-top: 10px;
        position: relative;
    }
    .edit-branch{
        margin-left: 2px; position: relative;
    }
    #content0{
        display: none;
    }
    #content1{
        display: block;
    }
  }
  
 .cat-btn{
     background-color: white;
 }
.cat-btn:hover{ 
    border:1px solid black;
    background-color: lightgreen;
    cursor: pointer;
    transition-duration: 1s;
    
}
.card{
    background: #fff;
    border: 1px solid grey;
    border-radius: 15px;
    box-shadow: 0 0 15px 0 #000;
    margin-bottom: 15px;
}
.btn-block{
    width:100%;
}
.btn:hover, .btn:focus{
    transform: scale(1.03);
}
.my-btn:hover, .my-btn:focus{
    transform: scale(1.06);
}
.btn{
    font-weight: bolder;
}
  </style>
</head>
<!-- -->
<body id="myPage" data-spy="scroll" data-target=".navbar" data-offset="60">

<?php //include('modals/add-branch-modal.php'); ?>
<?php //include('modals/add-admin-modal.php'); ?>
<?php //include('modals/add-rider-modal.php'); ?>
<?php include('modals/log-out-modal.php'); ?>
<?php //include('modals/user-track-order-modal.php'); ?>
<?php //include('modals/user-order-modal.php'); ?>

<nav class="navbar navbar-default navbar-fixed-top">
  <div class="container">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
      <a class="navbar-brand" href="#myPage">
          <table>
              <tr>
                  <td> 
                    <img src='../assets/image/eMove.png' style=' height:25px; border-radius:50%;' /> 
                     
                  </td>
                  <td style='color:white;font-weight:bold;'>&nbsp;<?php  echo $userRw['user'];?></td>
                  <input type='hidden' id='userNo' value='<?php echo $userNo;?>' /> 
              </tr>
          </table>
      </a>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav navbar-right"><li><a class="my-btn" href="index.php" ><span class='fa fa-home' ></span>&nbsp;HOME <sup style='color:white;'></sup></a></li>
        <li><a class="my-btn" href="my-bookings.php" ><span class='fa fa-map-marker-alt fa-fw' ></span>&nbsp;BOOKING <sup style='color:white;'></sup></a></li>
        <li><a class="my-btn" href="my-orders.php" ><span class='fas fa-marker fa-fw' ></span>&nbsp;ORDERS <sup style='color:white;'></sup></a></li>  
        <li><a class="my-btn" href="my-riders.php" ><span class='fa fa-motorcycle fa-fw' ></span>&nbsp;RIDERS <sup style='color:white;'></sup></a></li>  
        <li><a class="my-btn" href="my-users.php" ><span class='fa fa-users fa-fw' ></span>&nbsp;USERS <sup style='color:white;'></sup></a></li>  
        <li><a class="my-btn" href="my-account.php" ><span class='fa fa-user fa-fw' ></span>&nbsp;ME <sup style='color:white;'></sup></a></li>  
        <li><a class="my-btn" data-target="#logout-modal" data-toggle="modal"><span class='fa fa-sign-out-alt fa-fw' ></span>&nbsp;EXIT</a></li>
      </ul>
    </div>
  </div>
</nav>

<div class="jumbotron text-center">
    <BR />
    <br />
    <div class='row'>
        <div class='col-sm-6'>   
        <img src='../assets/image/eMove.png' style='height:100px; border-radius:50%;margin-top:-30px;' />
        <strong style='font-size:45px;color:#39ace7'>Express&nbsp;Wheel</strong> 
        </div>
        <div class='col-sm-6'> 
            <div class='row' style='font-size:2em; font-family: "Comic Sans MS"; color: white '>
                <div class='col-sm-12'> 
                Connecting communities, delivering convenience
                </div> 
            </div>
        </div>
    </div> 
</div> 
<!-- Rider Applicants -->
<div id="applicants" class="container-fluid">
    <?php 
      $applicant=0;
      $query=mysqli_query($conn, "select COUNT(no) as applicants from tbl_user where position = 0 and applicant = 1 ");
      if($query){
        if($row=mysqli_fetch_assoc($query)){
          $applicant=$row['applicants'];
        }
      }
    ?>
    <h2 class="text-center" style='color:#0784b5'>APPLICANTS(<?php echo $applicant; ?>)</h2>
    <div class="row">
        <div class="table-responsive" >
            <table class="table table-striped table-bordered table-hover" id="" style="cursor:default;text-align:left;width:100%;color:#0784b5">
                <thead>
                    <th><span id="content0"></span></th>
                    <th>Rider Name</th>
                    <th></th>
                </thead>
                <tfoot>
                    <th><span id="content0"></span></th>
                    <th>Rider Name</th>
                    <th></th>
                </tfoot>
                <tbody>
                    <?php
                        $no=1;
                        $query = "select * from tbl_user where position = 0 and applicant = 1  ORDER by ln ASC";
                        $stmt=$conn->prepare($query);
                        $stmt->execute();
                        $result=$stmt->get_result();
                        if($result->num_rows == 0){
                            echo "<tr><td colspan='3' class='text-center' style='font-weight:bolder'>No applicants</td></tr>";
                        } 
                        else{
                          while($row=$result->fetch_assoc()){
                              echo "<tr>";
                              
                              echo "<td>
                                      <span id='content0'>
                                          $no
                                      </span>  
                                  </td>";
                              
                              echo "<td >
                                      <strong>
                                          ".strtoupper($row['ln'].", ".$row['fn']." ".$row['mn'][0])."
                                      </strong>
                                  </td>";
                                  
                              echo "<td>
                                      <a class='btn my-btn btn-success' data-toggle='modal' data-target='#view-applicant$row[no]'><span style='font-weight:bolder' class='fa fa-eye fa-fw'></span>&nbsp;View</a> 
                                    <!-- <a class='btn btn-primary' data-toggle='modal' data-target='#edit-rider$row[no]'><span style='font-weight:bolder' class='fa fa-edit fa-fw'></span>&nbsp;Edit</a> -->
                                      <!--<a class='btn my-btn btn-danger my-btn' data-toggle='modal' data-target='#delete-applicant$row[no]'><span style='font-weight:bolder' class='fa fa-trash fa-fw'></span>&nbsp;Remove</a>-->
                                  </td>";
                            
                              echo "</tr>";
                              
                              $no++;
                              include 'modals/rider/view-applicant-modal.php';
                          }
                        }
                    ?>
                    
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Container () -->
<div id="orders" class="container-fluid" style='color:#0784b5'>
    <?php 
      $riders=0;
      $query=mysqli_query($conn, "select COUNT(no) as riders from tbl_user where position = 1 ");
      if($query){
        if($row=mysqli_fetch_assoc($query)){
          $riders=$row['riders'];
        }
      }
    ?>
    <h2 class="text-center" style='color:#0784b5'>RIDERS(<?php echo $riders; ?>)</h2>
    <div class="row">
        <input type="text" style="margin-bottom:20px;" class="form-control" id="searchInput" oninput="searchTable()" placeholder="Search Rider's Name">
    </div>
    <div class="row">
        <div class="table-responsive" style="max-height:70vh;overflow:auto">
            <table class="table table-striped table-bordered table-hover" id="myTable" style="cursor:default;text-align:left;width:100%;">
                <thead>
                    <th><span id="content0"></span></th>
                    <th>Rider Name</th>
                    <th>Earnings (Today)</th>
                    <th>Payback (10%)</th>
                    <th></th>
                </thead>
                <tfoot>
                    <th><span id="content0"></span></th>
                    <th>Rider Name</th>
                    <th>Earnings (Today)</th>
                    <th>Cashback (10%)</th>
                    <th></th>
                </tfoot>
                <tbody>
                    <?php
                        $no=1;
                        $query = "SELECT * FROM tbl_user WHERE position = 1 and no <> 19 ORDER by ln ASC";
                        $stmt=$conn->prepare($query);
                        $stmt->execute();
                        $result=$stmt->get_result();
                        if($result->num_rows == 0){
                            echo "<tr><td colspan='5' class='text-center' style='font-weight:bolder'>No riders</td></tr>";
                        } 
                        else{
                          while($row=$result->fetch_assoc()){
                              echo "<tr>";
                              
                              echo "<td>
                                      <span id='content0'>
                                          $no
                                      </span>  
                                  </td>";
                              
                              echo "<td >
                                      <strong>
                                          ".strtoupper($row['ln'].", ".$row['fn']." ".$row['mn'][0])."
                                      </strong>
                                  </td>";

                              $s_q1=mysqli_query($conn, "select SUM(fare) as summed_id from tbl_book_ride where status = 2 and rider_status = 2 and rider_id = '$row[no]' and _timestamp like  now()");
                              $s_q2=mysqli_query($conn, "select SUM(fee) as summed_id from tbl_user_make_order where status = 2 and rider_status = 2 and rider_id = '$row[no]' and _timestamp like now()");
                              
                              $s1=0;
                              $s2=0;
                              $total1=0;
                              $total2=0;

                              $rs1=mysqli_fetch_assoc($s_q1);
                              $rs2=mysqli_fetch_assoc($s_q2);

                              $total1=($rs1['summed_id']+$rs2['summed_id']);
                              $total2=($total1-($total1/.10));

                              echo "<td>
                                        <span id='content0'>
                                            ".number_format($total1, 2)."
                                        </span>  
                                    </td>";
                              
                              echo "<td>
                                      <span id='content0'>
                                          ".number_format($total2, 2)."
                                      </span>  
                                  </td>"; 

                              echo "<td>
                                      <a class='btn my-btn btn-success' data-toggle='modal' data-target='#view-rider$row[no]'><span style='font-weight:bolder' class='fa fa-eye fa-fw'></span>&nbsp;View</a> 
                                      <a class='btn btn-primary' data-toggle='modal' data-target='#edit-rider$row[no]'><span style='font-weight:bolder' class='fa fa-edit fa-fw'></span>&nbsp;Edit</a> 
                                      <a class='btn my-btn btn-danger my-btn' data-toggle='modal' data-target='#delete-rider$row[no]'><span style='font-weight:bolder' class='fa fa-trash fa-fw'></span>&nbsp;Delete</a>
                                  </td>";
                            
                              echo "</tr>";
                              
                              $no++;
                              include 'modals/rider/view-rider-modal.php';
                              include 'modals/rider/edit-rider-modal.php';
                              include 'modals/rider/delete-rider-modal.php';
                          }
                        }
                    ?>
                    
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Container (Contact Section) -->
<div id="contact" class="container-fluid bg-grey">
  <h2 class="text-center" style='color:#0784b5'>COSTUMER SERVICES</h2>
  <div class="row">
    <div class="col-sm-6 col-sm-offset-3">
      <p><strong>Please contact us</strong></p>
      <p><span class="fa fa-home fa-fw"></span>&nbsp;Business and Management Department</p>
      <p><span class="fa fa-university fa-fw"></span>&nbsp;Southern Leyte State University-San Juan Campus</p>
      <p><span class="fa fa-map-marker-alt fa-fw"></span>&nbsp;San Jose, San Juan, Southern Leyte</p> 
      <p><span class="fa fa-envelope fa-fw"></span>&nbsp;<a style="color:#39ace7" type="button" href="mailto:dbma_sj@southernleytestateu.com">dbma_sj@southernleytestateu.com</a></p>
      <p><span class="fab fa-facebook-f fa-fw"></span>&nbsp;<a style="color: #39ace7" type="button" href="https://www.facebook.com/share/1A6MopfwGS">Express Wheel</a></p>
    </div> 
  </div>
</div> 

<footer class="container-fluid text-center" style='background-color:#0784b5;'>
  <a href="#myPage" title="To Top">
    <span class="glyphicon glyphicon-chevron-up"></span>
  </a> 
</footer>

<script>
$(document).ready(function(){
  // Add smooth scrolling to all links in navbar + footer link
  $(".navbar a, footer a[href='#myPage']").on('click', function(event) {
    // Make sure this.hash has a value before overriding default behavior
    if (this.hash !== "") {
      // Prevent default anchor click behavior
      event.preventDefault();

      // Store hash
      var hash = this.hash;

      // Using jQuery's animate() method to add smooth page scroll
      // The optional number (900) specifies the number of milliseconds it takes to scroll to the specified area
      $('html, body').animate({
        scrollTop: $(hash).offset().top
      }, 900, function(){
   
        // Add hash (#) to URL when done scrolling (default click behavior)
        window.location.hash = hash;
      });
    } // End if
  });
  
  $(window).scroll(function() {
    $(".slideanim").each(function(){
      var pos = $(this).offset().top;

      var winTop = $(window).scrollTop();
        if (pos < winTop + 600) {
          $(this).addClass("slide");
        }
    });
  });
})

$(document).ready( function(){
    $("#item-delivery-type").on("change", function(){
        if($("#item-delivery-type").val() == "1"){
            $("#item-scheduled-span").html("<input type='date' id='item-scheduled' class='form-control' style='margin-top:7px'>")
        }
        else{
            $("#item-scheduled-span").html("");
        }
    })
})
</script>
<script>
  function searchTable() {
    var input, filter, table, tr, td, i, j, txtValue;
    input = document.getElementById("searchInput");
    filter = input.value.toUpperCase();
    table = document.getElementById("myTable");
    tr = table.getElementsByTagName("tr");

    for (i = 1; i < tr.length; i++) { // Start from 1 to skip the header row
      if (tr[i].parentNode.tagName === "TFOOT") {
        continue; // Skip rows inside tfoot
      }
      tr[i].style.display = "none"; // Hide all rows initially
      td = tr[i].getElementsByTagName("td");
      for (j = 0; j < td.length; j++) {
        if (td[j]) {
          txtValue = td[j].textContent || td[j].innerText;
          if (txtValue.toUpperCase().indexOf(filter) > -1) {
            tr[i].style.display = ""; // Show the row if a match is found
            break; // Exit the inner loop once a match is found
          }
        }
      }
    }
  }
</script>
</body>
</html>