<?php
//  session_start();
    include( '../components/comp-conn.php');

    $municipal_code = htmlentities($_POST['mun']);
    
    $query = "select * from refbrgy where citymunCode = '$municipal_code' and brgyDesc <> '$_POST[brgy]' ";
    $brgy = mysqli_query($conn, $query);
    
    while($row = mysqli_fetch_assoc($brgy)){
        echo "<option value='$row[brgyCode]'>$row[brgyDesc]</option>";
    }
?>