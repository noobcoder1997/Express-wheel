<?php
    include "../components/comp-conn.php";
    
    $order_id = $_POST['order_id'];
    $branch_id = $_POST['branch_id'];
    $time = date('h:i:s');
    $date = date('Y-m-d');
    $status = 1;
    $message;
   
    $note = "Your package has arrived at $branch_id";
        
    $query1 = "INSERT INTO tbl_user_track_history (order_id, note, status, date, time) VALUES ('$order_id', '$note', '$status', '$date', '$time')";
    mysqli_query($conn, $query1);
    
    $message = '<div class="alert alert-success">
                <strong>Package Updated:</strong>
                Package arrived at '.$branch_id.'!
            </div>';
    

    echo $message;
   
?>