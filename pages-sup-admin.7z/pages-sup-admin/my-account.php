<!doctype html>
<HTML> 
<head> 
<TITLE>Wheel Express</TITLE>  
<link rel="icon" href="../assets/image/eMove.png">
<meta name="viewport" content="width=device-width, initial-scale=1.0"> 
<link rel="stylesheet" href="../lib/bootstrap/css/bootstrap.css">
<link rel="stylesheet" href="../lib/bootstrap/css/bootstrap.min.css">
<link rel="stylesheet" href="../lib/font-awesome-5/css/all.css">
<script src="../lib/jquery/jquery-1.11.3.js"></script>
<script src="../lib/bootstrap/js/bootstrap.min.js"></script>
<?php
    include "../components/comp-conn.php"; 
    // session_start();
    if(!isset($_SESSION['sup_admin_status'])){
        header('location: ../');
    }
    
    $userNo =  "NO USER NUMBER".$_SESSION['userNo'];
    if(!isset($_SESSION['userNo'])){
        ?>
        <script>
            window.location.href='../';
        </script>
        <?php
    }else{
        $userNo = $_SESSION['userNo'];
    } 
    
    $userQry = mysqli_query($conn,"SELECT * FROM tbl_user WHERE no='$userNo' ")or die(mysqli_error($conn));
    $userRw  = mysqli_fetch_assoc($userQry);
   
?>
</head>
 <style>
  body {
    font: 400 15px Lato, sans-serif;
    line-height: 1.8;
    color: #818181;
    font-family: 'century gothic';
    width:100%;
  }
  h2 {
    font-size: 24px;
    text-transform: uppercase;
    color: #303030;
    font-weight: 600;
    margin-bottom: 30px;
  }
  h4 {
    font-size: 19px;
    line-height: 1.375em;
    color: #303030;
    font-weight: 400;
    margin-bottom: 30px;
  }  
  .jumbotron {
    background-color: #414c50;
    color: #192428;
    padding: 40px 25px;
    padding-top:70px;
    font-family: Montserrat, sans-serif; 
    
  }
  .container-fluid {
    padding: 40px 50px;
  }
  .bg-grey {
    background-color: #414c50;
    color: #39ace7;
  }
  .logo-small {
    color: #192428;
    font-size: 50px;
  }
  .logo {
    color: darkgreen;
    font-size: 200px;
  }
  .thumbnail {
    padding: 0 0 15px 0;
    border: none;
    border-radius: 0;
  }
  .thumbnail img {
    width: 100%;
    height: 100%;
    margin-bottom: 10px;
  }
  .prod:hover{
     border:2px solid grey;
      cursor: pointer;
      transition-duration: .5s;
  }
  .carousel-control.right, .carousel-control.left {
    background-image: none;
    color: darkgreen;
  }
  .carousel-indicators li {
    border-color: darkgreen;
  }
  .carousel-indicators li.active {
    background-color: darkgreen;
  }
  .item h4 {
    font-size: 19px;
    line-height: 1.375em;
    font-weight: 400;
    font-style: italic;
    margin: 70px 0;
  }
  .item span {
    font-style: normal;
  }
  .panel {
    border: 1px solid darkgreen; 
    border-radius:0 !important;
    transition: box-shadow 0.5s;
  }
  .panel:hover {
    box-shadow: 5px 0px 40px rgba(0,0,0, .2);
  }
  .panel-footer .btn:hover {
    border: 1px solid darkgreen;
    background-color: #fff !important;
    color: darkgreen;
  }
  .panel-heading {
    color: #fff !important;
    background-color:darkgreen !important;
    padding: 25px;
    border-bottom: 1px solid transparent;
    border-top-left-radius: 0px;
    border-top-right-radius: 0px;
    border-bottom-left-radius: 0px;
    border-bottom-right-radius: 0px;
  }
  .panel-footer {
    background-color: white !important;
  }
  .panel-footer h3 {
    font-size: 32px;
  }
  .panel-footer h4 {
    color: #aaa;
    font-size: 14px;
  }
  .panel-footer .btn {
    margin: 15px 0;
    background-color:darkgreen;
    color: #fff;
  }
  .navbar {
    margin-bottom: 0;
    background-color: #192428;
    z-index: 9999;
    border: 0;
    font-size: 12px !important;
    line-height: 1.42857143 !important;
    letter-spacing: 4px;
    border-radius: 0;
    font-family: Montserrat, sans-serif;
  }
  .navbar li a, .navbar .navbar-brand {
    color: #fff !important;
  }
  .navbar-nav li a:hover, .navbar-nav li.active a {
    color: #192428 !important;
    background-color: #fff !important;
  }
  .navbar-default .navbar-toggle {
    border-color: transparent;
    color: #fff !important;
  }
  footer .glyphicon {
    font-size: 20px;
    margin-bottom: 10px;
    color: #192428;
  }
  .slideanim {visibility:hidden;}
  .slide {
    animation-name: slide;
    -webkit-animation-name: slide;
    animation-duration: 1s;
    -webkit-animation-duration: 1s;
    visibility: visible;
  }
  @keyframes slide {
    0% {
      opacity: 0;
      transform: translateY(70%);
    } 
    100% {
      opacity: 1;
      transform: translateY(0%);
    }
  }
  @-webkit-keyframes slide {
    0% {
      opacity: 0;
      -webkit-transform: translateY(70%);
    } 
    100% {
      opacity: 1;
      -webkit-transform: translateY(0%);
    }
  } 
  @media screen and (max-width: 480px) {
    .logo {
      font-size: 150px;
      width: 100%;
    }
  }
  
 .cat-btn{
     background-color: white;
 }
.cat-btn:hover{ 
    border:1px solid black;
    background-color: lightgreen;
    cursor: pointer;
    transition-duration: 1s;
    
}
strong{
    word-wrap: word-break;
}
.btn{
    font-weight: bolder;
}
.btn:active, .btn:hover{
    transform: scale(1.03);
}
.my-btn:active, .my-btn:hover{
    transform: scale(1.03);
}
.btn-block{
    width: 100%;
}
  </style>
</head>

<?php include('modals/log-out-modal.php'); ?>

<body id="myPage" data-spy="scroll" data-target=".navbar" data-offset="60">

<nav class="navbar navbar-default navbar-fixed-top">
  <div class="container">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
      <a class="navbar-brand" href="#myPage">
          <table>
              <tr>
                  <td> 
                    <img src='../assets/image/eMove.png' style=' height:25px; border-radius:50%;' /> 
                  </td>
                  <td style='color:white;font-weight:bold;'>&nbsp;<?php  echo $userRw['user'];?></td>
                  <input type='hidden' id='userNo' value='<?php echo $userNo;?>' /> 
              </tr>
          </table>
      </a>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav navbar-right"><li><a href="index.php" ><span class='fa fa-home' ></span>&nbsp;HOME <sup style='color:white;'></sup></a></li> 
        <li><a class="my-btn" href="my-bookings.php" ><span class='fa fa-map-marker-alt fa-fw' ></span>&nbsp;BOOKING <sup style='color:white;'><?php //echo $cartNum;?></sup></a></li>  
        <li><a class="my-btn" href="my-orders.php" ><span class='fas fa-marker fa-fw' ></span>&nbsp;ORDERS <sup style='color:white;'></sup></a></li>  
        <li><a class="my-btn" href="my-riders.php" ><span class='fa fa-motorcycle fa-fw' ></span>&nbsp;RIDERS <sup style='color:white;'></sup></a></li>  
        <li><a class="my-btn" href="my-users.php" ><span class='fa fa-users fa-fw' ></span>&nbsp;USERS <sup style='color:white;'></sup></a></li>   
        <li><a class="my-btn" href="my-account.php" ><span class='fa fa-user fa-fw' ></span>&nbsp;ME <sup style='color:white;'></sup></a></li> 
        <li><a class="my-btn" data-target="#logout-modal" data-toggle="modal"><span class='fa fa-sign-out-alt' ></span>&nbsp;EXIT</a></li>
      </ul>
    </div>
  </div>
</nav>

<div class="jumbotron text-center"  >
    <BR />
    <br />
    <div class='row'>
        <div class='col-sm-6' >   
        <img src='../assets/image/eMove.png' style='height:100px; border-radius:50%;margin-top:-30px;' />
        <strong style='font-size:45px;color:#39ace7'>Express Wheel</strong> 
        </div>
        <div class='col-sm-6'> 
            <div class='row' style='font-size:2em; font-family: "Comic Sans MS"; color: white '>
                <div class='col-sm-12'> 
                Connecting communities, delivering convenience
                </div> 
            </div>
        </div>
    </div> 
</div> 
<script>
    function searchProduct(){
        var srch = $("#search").val();
        window.location.href = "index.php?srch="+srch;
    }
</script>

<div id="verify" class="modal fade" role="dialog" style='z-index:999999'>
    <div class="modal-dialog  modal-md"  >  
        <form onsubmit='return verify();'>
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title" style='font-weight:bold; color:#192428'>
                        <img src='../assets/image/agri-logo.png' style='height:40px; border-radius:50%;' />
                        Express Wheel | Verifying Account
                    </h4>
                </div>
                <div class="modal-body">  
                    <div class='row'> 
                        <div class='col-sm-12'> 
                            <strong>For varification, kindly upload the your valid identification.</strong>
                            <br />
                            <strong>Valid Issued Government ID (Front)</strong>
                            <br />
                            <div class='input-group'>
                                <span class='input-group-addon'><i class='fa fa-user'></i></span> 
                                <input type="file"  id='userIdFront' class='form-control input-sm'>
                            </div> 
                            <strong>Valid Issued Government ID (Back)</strong>
                            <br />
                            <div class='input-group'>
                                <span class='input-group-addon'><i class='fa fa-user'></i></span> 
                                <input type="file"  id='userIdBack' class='form-control input-sm'>
                            </div>
                            <span id='verifyRes'></span>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-success"  >Submit for Varification</button>
                </div>
            </div>
        </form>
    </div>
</div>

<script>
    function verify(){
	    var userIdFront = document.getElementById("userIdFront").files[0]; 
	    var userIdBack  = document.getElementById("userIdBack").files[0]; 
        form_data = new  FormData();  
            form_data.append("userNo",$("#userNo").val());
            form_data.append("userIdFront",userIdFront);
            form_data.append("userIdBack",userIdBack); 
            $.ajax({
                    url: "../query/verify-account-insert.php",
                method: "POST",
                data: form_data,
                contentType: false,
                cache: false,
                processData: false,
                beforeSend: function(){
                },
                success: function(data){ 
                    $("#verifyRes").html(data);
                }
            });
        return false;
    }
</script>


<div id="startBusiness1" class="modal fade" role="dialog" style='z-index:999999'>
    <div class="modal-dialog  modal-md"  >  
        <form onsubmit='return login();'>
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title" style='font-weight:bold; color:#192428'>
                        <img src='../assets/image/agri-logo.png' style='height:40px; border-radius:50%;' />
                        Express Wheel | Creating Online Store
                    </h4>
                </div>
                <div class="modal-body">  
                    <div class='row'> 
                        <div class='col-sm-12'> 
                            <strong>Business Name</strong>
                            <br />
                            <div class='input-group'>
                                <span class='input-group-addon'><i class='fa fa-home'></i></span>
                                <input type='tex' id='businessName' class='form-control input-md' placeholder='Business/Store Name' required />
                            </div>
                            <strong>Location</strong>
                            <br />
                            <div class='input-group'>
                                <span class='input-group-addon'><i class='fa fa-map-marker'></i></span>
                                <input type='text' id='location' class='form-control input-md' placeholder='Location/Address of Business/Store' required />
                            </div> 
                            <span id='businessRes'></span>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-success"  >Create Business</button>
                </div>
            </div>
        </form>
    </div>
</div>  

<!-- User Information -->
<div id="contact" class="container-fluid" style='color:#0784b5'>
  <h2 class="text-center" style='color:#0784b5'>User Information</h2>
  <div class="row">
      <div class="col-sm-4 text-center">
        <img src="../assets/image/user.png" class="img-circle elevation-2" alt="Profile Photo" style="width:100px; height:100px; object-fit: fill; position: flex; margin-left: 10px;">  
      </div>
    <div class="col-sm-4">
        <div class="row">
          <p>First Name: <?php $query = mysqli_query($conn, "SELECT * FROM tbl_user WHERE no='$userNo'"); if($result = mysqli_fetch_assoc($query)){ echo strtoupper($result['fn']); } ?></p>
          <p>Middle Name: <?php $query = mysqli_query($conn, "SELECT * FROM tbl_user WHERE no='$userNo'"); if($result = mysqli_fetch_assoc($query)){ echo strtoupper($result['mn']); } ?></p>
          <p>Last Name: <?php $query = mysqli_query($conn, "SELECT * FROM tbl_user WHERE no='$userNo'"); if($result = mysqli_fetch_assoc($query)){ echo strtoupper($result['ln']); } ?></p>
        </div>
    </div>
    <div class="col-sm-4">
        <div class="row">
          <p>Date of Birth: <?php $query = mysqli_query($conn, "SELECT * FROM tbl_user WHERE no='$userNo'"); if($result = mysqli_fetch_assoc($query)){ echo strtoupper($result['bday']); } ?></p>
          <!--<p>Age: <?php //  $query = mysqli_query($conn, "SELECT * FROM tbl_user WHERE no='$userNo'"); if($result = mysqli_fetch_assoc($query)){ echo strtoupper($result['age']); } ?></p>-->
          <p>Sex: <?php $query = mysqli_query($conn, "SELECT * FROM tbl_user WHERE no='$userNo'"); if($result = mysqli_fetch_assoc($query)){ echo strtoupper($result['sex']); } ?></p>
          <p>Contact Number: <?php $query = mysqli_query($conn, "SELECT * FROM tbl_user WHERE no='$userNo'"); if($result = mysqli_fetch_assoc($query)){ echo strtoupper($result['contact']); } ?>&nbsp;<span class="fa fa-edit fa-edit" data-toggle="modal" data-target="#edit-contact-modal<?php echo $userNo; ?>"></span></p>
          <p>Email address: <?php $query = mysqli_query($conn, "SELECT * FROM tbl_user WHERE no='$userNo'"); if($result = mysqli_fetch_assoc($query)){ echo strtolower($result['email']); } ?>&nbsp;<span class="fa fa-edit fa-edit" data-toggle="modal" data-target="#edit-email-modal<?php echo $userNo; ?>"></span></p>
        </div>
    </div>
    <div class="col-sm-4">
        <div class="row">
          <button class="btn btn-success btn-block" style="margin: 10px 0 20px 0" data-toggle="modal" data-target="#edit-unim-pass-modal<?php echo $userNo; ?>"><span class="fa fa-lock fa-fw"></span>&nbsp;Update Login Credentials</button>
        </div>
        <div class="row">
          <button class="btn btn-success btn-block" style="margin: 10px 0 20px 0" data-toggle="modal" data-target="#edit-info-modal<?php echo $userNo; ?>"><span class="fa fa-user fa-fw"></span>&nbsp;Update Personal Information</button>
        </div>
    </div>
  </div>
</div> 

<!--EDIT PERSONAL INFORMATION MODAL-->
<div id="edit-info-modal<?php echo $userNo; ?>" class="modal fade" role="dialog" style='z-index:999999;color:#0784b5'>
    <div class="modal-dialog  modal-md"  >  
        <div class="modal-content">
            <div class="modal-header text-center">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title" style='font-weight:bold; color:#192428'>
                    <img src='../assets/image/eMove.png' style='height:40px; border-radius:50%;' />
                    Express Wheel | Edit Personal Information
                </h4>
            </div>
            <div class="modal-body">  
                <div class='row'> 
                    <div class='col-sm-12'> 
                        <p>First name</p>  
                        <input class="form-control" id="fn<?php echo $userNo; ?>" value="<?php $query = mysqli_query($conn, "SELECT * FROM tbl_user WHERE no='$userNo'"); if($result = mysqli_fetch_assoc($query)){ echo strtolower($result['fn']); } ?>"/>
                        <p>Middle name (optional)</p>  
                        <input class="form-control" id="mn<?php echo $userNo; ?>" value="<?php $query = mysqli_query($conn, "SELECT * FROM tbl_user WHERE no='$userNo'"); if($result = mysqli_fetch_assoc($query)){ echo strtolower($result['mn']); } ?>"/>
                        <p>Last name</p>  
                        <input class="form-control" id="ln<?php echo $userNo; ?>" value="<?php $query = mysqli_query($conn, "SELECT * FROM tbl_user WHERE no='$userNo'"); if($result = mysqli_fetch_assoc($query)){ echo strtolower($result['ln']); } ?>"/>
                    </div>
                </div>
                <div class='row'> 
                    <div class='col-sm-12'> 
                        <p>Birth date</p>  
                        <input class="form-control" type="date" id="bday<?php echo $userNo; ?>" value="<?php $query = mysqli_query($conn, "SELECT * FROM tbl_user WHERE no='$userNo'"); if($result = mysqli_fetch_assoc($query)){ echo strtolower($result['bday']); } ?>" />
                    </div>
                </div>
                <div class='row'> 
                    <div class='col-sm-12'> 
                        <p>Sex</p>  
                        <select class="form-control" id="sex<?php echo $userNo; ?>">
                            <option value="Male">Male</option>
                            <option value="Female">Female</option>
                        </select>
                    </div>
                </div>
                <br>
                <span id="edit-info-message"></span>
            </div>
            <div class="modal-footer">
                <div class="row">
                    <div class="col-sm-12">
                        <a type="button" class="btn btn-default btn-block" data-dismiss="modal">Cancel</a>
                        <a type="button" class="btn btn-danger btn-block" onclick="edit_info(<?php echo $userNo; ?>);" >Submit</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!--EDIT USERNAME/PASSWORD MODAL-->
<div id="edit-unim-pass-modal<?php echo $userNo; ?>" class="modal fade" role="dialog" style='z-index:999999;color:#0784b5'>
    <div class="modal-dialog  modal-md"  >  
        <div class="modal-content">
            <div class="modal-header text-center">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title" style='font-weight:bold; color:#192428'>
                    <img src='../assets/image/eMove.png' style='height:40px; border-radius:50%;' />
                    Express Wheel | Edit Username/Password
                </h4>
            </div>
            <div class="modal-body">  
                <div class='row'> 
                    <div class='col-sm-12'> 
                        <p>Username</p>  
                        <input class="form-control" id="unim<?php echo $userNo; ?>" value="<?php $query = mysqli_query($conn, "SELECT * FROM tbl_user WHERE no='$userNo'"); if($result = mysqli_fetch_assoc($query)){ echo strtolower($result['user']); } ?>"/>
                    </div>
                </div>
                <div class='row'> 
                    <div class='col-sm-12'> 
                        <p>New Password</p>  
                        <input class="form-control" id="new-pass<?php echo $userNo; ?>" />
                    </div>
                </div>
                <div class='row'> 
                    <div class='col-sm-12'> 
                        <p>Confirm Password</p>  
                        <input class="form-control" id="confirm-pass<?php echo $userNo; ?>" />
                    </div>
                </div>
                <br>
                <span id="edit-unim-pass-message"></span>
            </div>
            <div class="modal-footer">
                <div class="row">
                    <div class="col-sm-12">
                        <a type="button" class="btn btn-default btn-block" data-dismiss="modal">Cancel</a>
                        <a type="button" class="btn btn-danger btn-block" onclick="edit_unim_pass(<?php echo $userNo; ?>)" >Submit</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!--EDIT CONTACT MODAL-->
<div id="edit-contact-modal<?php echo $userNo; ?>" class="modal fade" role="dialog" style='z-index:999999'>
    <div class="modal-dialog  modal-md"  >  
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title text-center" style='font-weight:bold; color:#192428'>
                    <img src='../assets/image/eMove.png' style='height:40px; border-radius:50%;' />
                    Express Wheel | Edit Contact Number
                </h4>
            </div>
            <div class="modal-body">  
                <div class='row'> 
                    <div class='col-sm-12'> 
                        <p>Contact Number</p>
                        <input class="form-control" id="contact<?php echo $userNo; ?>" value="<?php $query = mysqli_query($conn, "SELECT * FROM tbl_user WHERE no='$userNo'"); if($result = mysqli_fetch_assoc($query)){ echo $result['contact']; } ?>" pattern="[0-9].\d{8}|\d{11}">
                    </div>
                </div>
                <br>
                <span id="edit-contact-message"></span>
            </div>
            <div class="modal-footer">
                <a type="button" class="btn btn-default btn-block" data-dismiss="modal">Cancel</a>
                <a type="button" class="btn btn-danger btn-block" id="edit-contact-btn">Submit</a>
            </div>
        </div>
    </div>
</div>

<!--EDIT EMAIL MODAL-->
<div id="edit-email-modal<?php echo $userNo; ?>" class="modal fade" role="dialog" style='z-index:999999'>
    <div class="modal-dialog  modal-md"  >  
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title text-center" style='font-weight:bold; color:#192428'>
                    <img src='../assets/image/eMove.png' style='height:40px; border-radius:50%;' />
                    Express Wheel | Edit Email Address
                </h4>
            </div>
            <div class="modal-body">  
                <div class='row'> 
                    <div class='col-sm-12'> 
                        <p>Contact Number</p>
                        <input class="form-control" id="email<?php echo $userNo; ?>" value="<?php $query = mysqli_query($conn, "SELECT * FROM tbl_user WHERE no='$userNo'"); if($result = mysqli_fetch_assoc($query)){ echo strtolower($result['email']); } ?>" >
                    </div>
                </div>
                <br>
                <span id="edit-email-message"></span>
            </div>
            <div class="modal-footer">
                <a type="button" class="btn btn-default btn-block" data-dismiss="modal">Cancel</a>
                <a type="button" class="btn btn-danger btn-block" id="edit-email-btn">Submit</a>
            </div>
        </div>
    </div>
</div>

<!-- Container (Contact Section) -->
<div id="contact" class="container-fluid bg-grey">
  <h2 class="text-center" style='color:#0784b5'>COSTUMER SERVICES</h2>
  <div class="row">
    <div class="col-sm-6 col-sm-offset-3">
      <p><strong>Please contact us</strong></p>
      <p><span class="fa fa-home fa-fw"></span>&nbsp;Business and Management Department</p>
      <p><span class="fa fa-university fa-fw"></span>&nbsp;Southern Leyte State University-San Juan Campus</p>
      <p><span class="fa fa-map-marker-alt fa-fw"></span>&nbsp;San Jose, San Juan, Southern Leyte</p> 
      <p><span class="fa fa-envelope fa-fw"></span>&nbsp;<a style="color:#39ace7" type="button" href="mailto:dbma_sj@southernleytestateu.com">dbma_sj@southernleytestateu.com</a></p>
      <p><span class="fab fa-facebook-f fa-fw"></span>&nbsp;<a style="color: #39ace7" type="button" href="https://www.facebook.com/share/1A6MopfwGS">Express Wheel</a></p>
    </div> 
  </div>
</div>

<footer class="container-fluid text-center" style='background-color:#0784b5'>
  <a href="#myPage" title="To Top">
    <span class="glyphicon glyphicon-chevron-up"></span>
  </a> 
</footer>

<script>
  $(document).ready(function(){
    // Add smooth scrolling to all links in navbar + footer link
    $(".navbar a, footer a[href='#myPage']").on('click', function(event) {
      // Make sure this.hash has a value before overriding default behavior
      if (this.hash !== "") {
        // Prevent default anchor click behavior
        event.preventDefault();

        // Store hash
        var hash = this.hash;

        // Using jQuery's animate() method to add smooth page scroll
        // The optional number (900) specifies the number of milliseconds it takes to scroll to the specified area
        $('html, body').animate({
          scrollTop: $(hash).offset().top
        }, 900, function(){
    
          // Add hash (#) to URL when done scrolling (default click behavior)
          window.location.hash = hash;
        });
      } // End if
    });
    
    $(window).scroll(function() {
      $(".slideanim").each(function(){
        var pos = $(this).offset().top;

        var winTop = $(window).scrollTop();
          if (pos < winTop + 600) {
            $(this).addClass("slide");
          }
      });
    });
  })
</script>

<script>
    $("#edit-contact-btn").on('click', ()=>{
        $.ajax({
            data: "contact="+$('#contact'+<?php echo $userNo; ?>).val()+"&id="+<?php echo $userNo; ?>,
            method: 'post',
            url: 'edit-contact.php',
        }).done( function(data){
            $('#edit-contact-message').html(data);
        })
    })
</script>

<script>
    $('#edit-email-btn').on('click', ()=>{
        $.ajax({
            data: "email="+$('#email'+<?php echo $userNo; ?>).val()+"&id="+<?php echo $userNo; ?>,
            method: 'post',
            url: 'edit-email.php',
        }).done( function(data){
            $('#edit-email-message').html(data);
        })    
    })
</script>

<script>
    function edit_unim_pass(id){
        $.ajax(
            {
                url: "edit-unim-pass.php",
                method: "post",
                data: "unim="+$('#unim'+id).val()+"&new_pass="+$('#new-pass'+id).val()+"&confirm_pass="+$('#confirm-pass'+id).val()+"&id="+id,
            } 
        ).done( function(data){
            $('#edit-unim-pass-message').html(data);
        });        
    }
</script>

<script>
    function edit_info(id){
        $.ajax(
            {
                url: 'edit-info.php',
                method: 'post',
                data: "fn="+$('#fn'+id).val() + "&mn=" + $('#mn'+id).val() + "&ln="+$('#ln'+id).val() + "&sex=" + $('#sex'+id+' :selected').text() + "&bday=" + $('#bday'+id).val()+ "&id=" + id,
            }
        ).done( (data)=>{
            $('#edit-info-message').html(data);
        });       
    }
</script>
</body>
</html>