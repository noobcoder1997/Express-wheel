<?php
    include "../components/comp-conn.php";
    session_start();
    
    $fnim=$_POST['fnim'];
    $mnim=$_POST['mnim'];
    $lnim=$_POST['lnim'];
    $branch=$_POST['branch'];
    $unim=$_POST['unim'];
    $pass=$_POST['pass'];
    $cpass=$_POST['cpass'];
    $id=$_POST['id'];
    $message;
    
    if($fnim == null || $lnim == null || $branch == null || $unim == null){
        $message='<div class="alert alert-warning">
                    <strong>Error Input:</strong>
                    Fields should not leave empty! Please try again.
                </div>';
    }else if($pass != $cpass){
        $message='<div class="alert alert-warning">
                    <strong>Error Password:</strong>
                    Password did not match! Please try again.
                </div>';
    }
    else{
        $query = "select * from tbl_admin where username = '$unim' and password = '$pass' ";
        $result = mysqli_query($conn, $query);
        if(mysqli_num_rows($result)>0){
            $message='<div class="alert alert-warning">
                    <strong>Error user id:</strong>
                    Username and password is already in use. Please make another username and password.
                </div>';
        }
        else{
            if( ($pass != null || $cpass != null) OR ($pass != '' || $cpass != '') OR (!empty($pass) || !empty($cpass)) ){
                $pass = md5($pass);
                $stmt=$conn->prepare("update tbl_admin set f_name = ?, m_name = ?, l_name = ?, username = ?, password = ?, branch_id = ? where id = ?");
                $stmt->bind_param("sssssss",$fnim,$mnim,$lnim,$unim,$pass,$branch,$id);
                $stmt->execute();
                $message='<div class="alert alert-success">
                            <strong>Admin updated:</strong>
                            You have updated an admin!
                        </div>';                
            }
            else{
                $stmt=$conn->prepare("update tbl_admin set f_name = ?, m_name = ?, l_name = ?, username = ?, branch_id = ? where id = ?");
                $stmt->bind_param("ssssss",$fnim,$mnim,$lnim,$unim,$branch,$id);
                $stmt->execute();
                $message='<div class="alert alert-success">
                            <strong>Admin updated:</strong>
                            You have updated an admin!
                        </div>'; 
            }
        }
    }

    echo $message;
?>