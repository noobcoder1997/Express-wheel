<?php
    include '../components/comp-conn.php';
    // session_start();
    
    $branch_name=$_POST['branch-name'];
    $location=$_POST['location'];
    $id=$_POST['id'];
    $message='';
    
    $query = "select * from tbl_branch where branch_name = '$branch_name' and location = '$location' ";
    $result = mysqli_query($conn, $query);
    if(mysqli_num_rows($result) > 0){
        $message = "<div class='alert alert-danger'>
                        <strong>Edit Branch:</strong> Branch already exist. Please try again.
                    </div>";
    }
    else{
        $query = "update tbl_branch set branch_name = '$branch_name', location = '$location' where id = '$id' ";
        mysqli_query($conn, $query);
        
        $message =  "<div class='alert alert-success'>
                        <strong>Edit Branch:</strong> Branch successfuly created!
                    </div>";
    }
    
    echo $message;
    
?>