<?php    
    $id = $_POST['id'];
    
    $query = "delete from tbl_user_make_order where id = '$id' ";
    mysqli_query($conn, $query);
    
    echo "Order removed successfuly!";
?>