<?php
    include '../components/comp-conn.php';
    session_start();
    
    $id = $_POST['id'];
    
    $query = "delete from tbl_branch where id = '$id' ";
    mysqli_query($conn, $query);
    
    echo "Branch removed successfuly!";
?>