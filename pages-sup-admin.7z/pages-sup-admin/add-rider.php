<?php
    include "../components/comp-conn.php";
    session_start();
    
    $fnim=$_POST['fnim'];
    $mnim=$_POST['mnim'];
    $lnim=$_POST['lnim'];
    $unim=$_POST['unim'];
    $pass=$_POST['pass'];
    $cpass=$_POST['cpass'];
    // $position='rider';
    $message;
    
    if($cpass != $pass){
        $message='<div class="alert alert-warning">
                    <strong>Error Password:</strong>
                    Password did not match! Please try again.
                </div>';
    }
    else if($fnim == null || $lnim == null || $unim == null || $pass == null || $cpass == null){
        $message='<div class="alert alert-warning">
                    <strong>Error Input:</strong>
                    Fields should not leave empty! Please try again.
                </div>';
    }
    else{
        if($pass == $cpass){
            $pass = md5($pass);
            $stmt=$conn->prepare("INSERT INTO tbl_riders (f_name, m_name, l_name, username, password) VALUES (?,?,?,?,?) ");
            $stmt->bind_param("sssss",$fnim,$mnim,$lnim,$unim,$pass);
            $stmt->execute();
            $message='<div class="alert alert-success">
                        <strong>Rider Added:</strong>
                        You have added a new rider!
                    </div>';           
        }
  
    }

    echo $message;
?>