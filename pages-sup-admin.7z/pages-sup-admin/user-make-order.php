<?php
    include "../components/comp-conn.php";
    // session_start();
    $sender_name = htmlentities($_POST['sender-name']);
    $sender_contact = htmlentities($_POST['sender-contact']);
    $sender_brgy = htmlentities($_POST['sender-barangay']);
    $sender_city = htmlentities($_POST['sender-city']); 
    $sender_prov = htmlentities($_POST['sender-province']);
    
    $recipient_name = htmlentities($_POST['recipient-name']);
    $recipient_contact = htmlentities($_POST['recipient-contact']);
    $recipient_brgy = htmlentities($_POST['recipient-barangay']);
    $recipient_city = htmlentities($_POST['recipient-city']); 
    $recipient_prov = htmlentities($_POST['recipient-province']);
    
    $item_name = htmlentities($_POST['item-name']);
    $item_weight = htmlentities($_POST['item-weight']);
    $item_quantity = htmlentities($_POST['item-quantity']);
    
    $item_value = htmlentities($_POST['item-value']);
    $item_length = htmlentities($_POST['item-length']);
    $item_width = htmlentities($_POST['item-width']);
    
    $item_height = htmlentities($_POST['item-height']);
    $item_service_type = htmlentities($_POST['item-service-type']);
    $item_package_type = htmlentities($_POST['item-package-type']); // selected option text in select tag
    
    $item_delivery_type = htmlentities($_POST['item-delivery-type']); // selected option text in select tag
    $item_scheduled = htmlentities($_POST['item-scheduled']);   // date for schedule
    $item_fee = htmlentities($_POST['item-fee']);
    
    $item_remarks = htmlentities($_POST['item-remarks']);
    $branch_id = htmlentities($_POST['branch-id']);
    
    $message = "";
    
    if(strlen($recipient_contact) != 11){
        $message = "<div class='alert alert-warning'>";
        $message .= "<strong>Warning:</strong> Invalid Contact Number! Please try again.";
        $message .= "<h1 style='font-weight:bolder' id='text-to-copy'>".$number."</h1>";
        $message .= "</div>";
    }
    else if(
        $sender_name == null ||
        $sender_contact == null || 
        $sender_brgy == null ||
        $sender_city == null ||
        $sender_prov == null ||
        $recipient_name == null || 
        $recipient_contact == null ||
        $recipient_brgy == null || 
        $recipient_city == null || 
        $recipient_prov == null || 
        $item_name == null ||
        $item_weight == null ||
        $item_quantity == null ||
        $item_value == null ||
        $item_length == null ||
        $item_width == null ||
        $item_height == null ||
        $item_service_type == null ||
        $item_package_type = null ||
        $item_delivery_type == null ||
        $item_scheduled == null || 
        $item_fee == null ||
        $item_remarks == null){
            
            $message = "<div class='alert alert-warning'>";
            $message .= "<strong>Warning:</strong> Fields should no leave empty.";
            $message .= "<h1 style='font-weight:bolder' id='text-to-copy'>".$number."</h1>";
            $message .= "</div>";
    }
    else{
        $query = "SELECT id FROM tbl_user_make_order ORDER BY id DESC";
        $stmt = $conn->prepare($query);
        $stmt->execute();
        $result=$stmt->get_result();
        $row = $result->fetch_assoc();
        $lastid = isset($row['id']);
        
        $number = rand(1000000,2000000);
        
        $stmt = $conn->prepare("INSERT INTO tbl_user_make_order (order_number, sender_name, sender_contact, sender_barangay, sender_city, sender_province, recipient_name, recipient_contact, recipient_barangay, recipient_city, recipient_province, item_name, item_quantity, 	item_weight, item_value, item_length, item_width, item_height, service_type, package_type, delivery_type, item_scheduled, fee, remarks, branch_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?) ");
        $stmt->bind_param("sssssssssssssssssssssssss",$number, $sender_name,$sender_contact,$sender_brgy, $sender_city, $sender_prov,$recipient_name,$recipient_contact,$recipient_brgy, $recipient_city, $recipient_prov,$item_name,$item_quantity,$item_weight,$item_value,$item_length,$item_width,$item_height,$item_service_type,$item_package_type,$item_delivery_type,$item_scheduled,$item_fee,$item_remarks, $branch_id);
        $stmt->execute();
        
        $message = "<div class='alert alert-success'>";
        $message .= "<strong>Order Successful:</strong> You have created an order! <br> Your Order Number:";
        $message .= "<h1 style='font-weight:bolder' id='text-to-copy'>".$number."</h1>";
        $message .= "<a class='btn'><span class='fa fa-copy' onclick='copy()'></span> copy</a>";
        $message .= "</div>";
        
        $query1 = "SELECT * FROM tbl_branch WHERE id = ?";
        $stmt1 = $conn->prepare($query1);
        $stmt1->bind_param("s",$branch_id);
        $stmt1->execute();
        $result1 = $stmt1->get_result();
        while($rw1 = $result1->fetch_assoc()){
            $date = date("Y-m-d");
            $time = date("h:i:s");
            $note = "Your package has been received by $rw1[branch_name].";
            
            $query2 = "INSERT INTO tbl_user_track_history (order_id, date, note, time) VALUES (?, ?, ?, ?)";
            $stmt2 = $conn->prepare($query2);
            $stmt2->bind_param("ssss",$number,$date,$note,$time);
            $stmt2->execute();
        }        
    }
    echo $message;
?>

