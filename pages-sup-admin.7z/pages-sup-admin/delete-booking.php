<?php    
    $id = $_POST['id'];
    
    $query = "delete from tbl_book_ride where id = '$id' ";
    mysqli_query($conn, $query);
    
    echo "Booking removed successfuly!";
?>