<!--Edit Admin Modal-->
<div id="editAdminModal<?php echo $row['id']; ?>" class="modal fade" role="dialog" style='z-index:999999; color:#0784b5'>
    <div class="modal-dialog  modal-md"  >  
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title text-center" style='font-weight:bold; color:#192428'>
                    <img src='../assets/image/eMove.png' style='height:40px; border-radius:50%;' />
                    Express Wheel | Edit Admin
                </h4>
            </div>
            <div class="modal-body">  
                <div class='row'> 
                    <div class='col-sm-12'> 
                        <p>First name</p>
                        <input class="form-control" id="fnim-<?php echo $row['id']; ?>" value="<?php echo $row['f_name']; ?>">
                        <p>Middle name</p>
                        <input class="form-control" id="mnim-<?php echo $row['id']; ?>" placeholder="(optional)" value="<?php echo $row['m_name']; ?>">
                        <p>Last name</p>
                        <input class="form-control" id="lnim-<?php echo $row['id']; ?>" value="<?php echo $row['l_name']; ?>">
                        <p>Branch</p>
                        <select class="form-control" id="brnch-<?php echo $row['id']; ?>" >
                            <?php
                                $query0 = "SELECT * FROM tbl_branch";
                                $result0 = mysqli_query($conn, $query0);
                                while($r0 = mysqli_fetch_assoc($result0)){
                                    echo "<option value='$r0[id]'>$r0[branch_name]</option>";
                                }
                            ?>
                        </select>
                        <p>Username</p>
                        <input class="form-control" id="unim-<?php echo $row['id']; ?>" value="<?php echo $row['username']; ?>">
                        <p>Password</p>
                        <input class="form-control" id="pass-<?php echo $row['id']; ?>">
                        <p>Confirm Password</p>
                        <input class="form-control" id="cpass-<?php echo $row['id']; ?>">
                    </div>
                </div>
                <br>
                <span id="edit-admin-message<?php echo $row['id']; ?>"></span>
            </div>
            <div class="modal-footer">
                <a type="button" class="btn btn-default" data-dismiss="modal">Cancel</a>
                <a type="button" class="btn btn-danger" id="edit-admin-btn<?php echo $row['id']; ?>">Submit</a>
            </div>
        </div>
    </div>
</div>


<script>
    $('#edit-admin-btn<?php echo $row['id']; ?>').on('click', function(){
        var fnim=$('#fnim-<?php echo $row['id']; ?>').val();
        var mnim=$('#mnim-<?php echo $row['id']; ?>').val();
        var lnim=$('#lnim-<?php echo $row['id']; ?>').val();
        var branch=$('#brnch-<?php echo $row['id']; ?>').val();
        var unim=$('#unim-<?php echo $row['id']; ?>').val();
        var pass=$('#pass-<?php echo $row['id']; ?>').val();
        var cpass=$('#cpass-<?php echo $row['id']; ?>').val();
        var id="<?php echo $row['id']; ?>";
        
        form=new FormData();
        form.append('fnim', fnim);
        form.append('mnim', mnim);
        form.append('lnim', lnim);
        form.append('branch', branch);
        form.append('unim', unim);
        form.append('pass', pass);
        form.append('cpass', cpass);
        form.append('id', id);
        $.ajax({
            url: 'edit-admin.php',
            method: 'POST',
            data: form,
            cache: false,
            processData: false,
            contentType: false,
        }).done( function(data){
            $('#edit-admin-message<?php echo $row['id']; ?>').html(data);
        })
    })
    
</script>


