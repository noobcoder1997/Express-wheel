<!--SELECT BRANCH IN PACKAGE SEND-->
<div id="out-for-delivery<?php echo $row['order_id']; ?>" class="modal fade" role="dialog" style='z-index:999999; color:#0784b5'>
    <div class="modal-dialog  modal-xs" >  
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title text-center" style='font-weight:bold; color:#192428'>
                    <img src='../assets/image/eMove.png' style='height:40px; border-radius:50%;' />
                    Express Wheel | Out for delivery
                </h4>
            </div>
            <div class="modal-body">  
                <div class='row'>
                    <div class='col-sm-12 text-left'> 
                        <p>Order Number</p>
                        <input type="text" class="form-control" id="order-id<?php echo $row['order_id']; ?>" value="<?php echo $row['order_id']; ?>"/>
                        <p>Select Rider:</p>
                        <select id="select-rider<?php echo $row['order_id']; ?>" class="form-control">
                            <?php
                                $query0 = "SELECT * FROM tbl_riders";
                                $result0 = mysqli_query($conn, $query0);
                                while($rw0=mysqli_fetch_assoc($result0)){
                                    echo "<option value='$rw0[id]'>$rw0[f_name]</option>";
                                }
                            ?>
                        </select>
                    </div>
                </div>
                <br>
                <span id="package-update-message-2-<?php echo $row['order_id']; ?>"></span>
            </div>
            <div class="modal-footer">
                <button class="btn btn-default" data-dismiss="modal">Close</button>
                <button class="btn btn-danger" onclick="package_deliver(<?php echo $row['order_id']; ?>)">Submit</button>
            </div>
        </div>
    </div>
</div> 