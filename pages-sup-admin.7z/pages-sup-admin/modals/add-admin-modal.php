<!--Add Admin Modal-->
<div id="addAdminModal" class="modal fade" role="dialog" style='z-index:999999; color:#0784b5'>
    <div class="modal-dialog  modal-md"  >  
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title text-center" style='font-weight:bold; color:#192428'>
                    <img src='../assets/image/eMove.png' style='height:40px; border-radius:50%;' />
                    Express Wheel | Add Admin
                </h4>
            </div>
            <div class="modal-body">  
                <div class='row'> 
                    <div class='col-sm-12'> 
                        <p>First name</p>
                        <input class="form-control" id="fnim">
                        <p>Middle name</p>
                        <input class="form-control" id="mnim" placeholder="(optional)">
                        <p>Last name</p>
                        <input class="form-control" id="lnim">
                        <p>Branch</p>
                        <select class="form-control" id="brnch">
                            <?php
                                $query = "SELECT * FROM tbl_branch";
                                $result = mysqli_query($conn, $query);
                                while($row = mysqli_fetch_assoc($result)){
                                    echo "<option value='$row[id]'>$row[branch_name]</option>";
                                }
                            ?>
                        </select>
                        <p>Username</p>
                        <input class="form-control" id="unim">
                        <p>Password</p>
                        <input class="form-control" id="pass">
                        <p>Confirm Password</p>
                        <input class="form-control" id="cpass">
                    </div>
                </div>
                <br>
                <span id="add-admin-message"></span>
            </div>
            <div class="modal-footer">
                <a type="button" class="btn btn-default" data-dismiss="modal">Cancel</a>
                <a type="button" class="btn btn-danger" id="create-admin-btn">Submit</a>
            </div>
        </div>
    </div>
</div>


<script>
    $('#create-admin-btn').on('click', function(){
        var fnim=$('#fnim').val();
        var mnim=$('#mnim').val();
        var lnim=$('#lnim').val();
        var branch=$('#brnch').val();
        var unim=$('#unim').val();
        var pass=$('#pass').val();
        var cpass=$('#cpass').val();
        
        form=new FormData();
        form.append('fnim', fnim);
        form.append('mnim', mnim);
        form.append('lnim', lnim);
        form.append('branch', branch);
        form.append('unim', unim);
        form.append('pass', pass);
        form.append('cpass', cpass);
        $.ajax({
            method: 'POST',
            data: form,
            url: 'add-admin.php',
            cache: false,
            processData: false,
            contentType: false,
        }).done( function(data){
            $('#add-admin-message').html(data);
        })
    })
    
</script>


