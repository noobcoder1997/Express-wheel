<!-- The Modal -->
<div class="modal" id="view-booking<?php echo $row['id']; ?>" style='z-index:999999; color:#0784b5'>
    <div class="modal-dialog">
        <div class="modal-content">

            <!-- Modal Header -->
            <div class="modal-header text-center">
                <!--<button type="button" class="close" data-dismiss="modal">&times;</button>-->
                <h4 class="modal-title" style='font-weight:bold; color:#192428'>
                    <img src='../assets/image/emove.png' style='height:40px; border-radius:50%;' />
                    Express Wheel | View Booking
                </h4>
            </div>

            <!-- Modal body -->
            <div class="modal-body" style="text-align:Left">
                <div class="row">
                    <div class="col-sm-12">
                        <div class="form-group">
                            <?php 
                                $q=mysqli_query($conn, "select * from tbl_book_ride where id = '$row[id]' ");
                                $r = mysqli_fetch_assoc($q);
                            ?>  
                                <div class="col-sm-12">
                                    <p style="font-weight:bold">Date:
                                        <?php
                                            echo $r['_timestamp'];
                                        ?>
                                    </p>
                                    <p style="font-weight:bold">Rider Name: 
                                        <?php 
                                            $r_query = mysqli_query($conn, "select fn, ln from tbl_user where no = '$r[rider_id]' ");
                                            if($res = mysqli_fetch_assoc($r_query)){
                                                echo strtoupper($res['fn']. " ".$res['ln']); 
                                            }
                                        ?>
                                    </p>
                                    <p style="font-weight:bold">Passenger Name: 
                                        <?php 
                                            $r_query = mysqli_query($conn, "select fn, ln from tbl_user where no = '$r[passenger_id]' ");
                                            if($res = mysqli_fetch_assoc($r_query)){
                                                echo strtoupper($res['fn']. " ".$res['ln']); 
                                            }
                                        ?>
                                    </p>
                                    <p style="font-weight:bold">From:
                                        <?php
                                            $r_query = mysqli_query($conn, "select brgyDesc from tbl_brgy where id = '$r[_from]' ");
                                            if($res = mysqli_fetch_assoc($r_query)){
                                                echo strtoupper($res['brgyDesc']); 
                                            }
                                        ?>
                                    </p>
                                    <p style="font-weight:bold">To:
                                        <?php
                                            $r_query = mysqli_query($conn, "select brgyDesc from tbl_brgy where id = '$r[_to]' ");
                                            if($res = mysqli_fetch_assoc($r_query)){
                                                echo strtoupper($res['brgyDesc']); 
                                            }
                                        ?>
                                    </p>
                                    <?php
                                        if($r['status']==2){
                                        ?>
                                            <p style="font-weight:bold">Status: Successful
                                            </p>
                                            <p style="font-weight:bold">Fare: &#8369;
                                            <?php 
                                                echo $r['fare'];
                                            ?>
                                            </p>
                                            <p style="font-weight:bold">cashback(10%): &#8369;
                                            <?php 
                                                number_format(print($r['fare']*.10), 2);
                                            ?>
                                            </p>
                                            <p style="font-weight:bold">Rider Earnings(90%): &#8369;
                                                <?php 
                                                    number_format(print($r['fare']-($r['fare']*.10)), 2);
                                                ?>
                                            </p>
                                        <?php
                                    ?>
                                    <?php
                                        }
                                        elseif($r['status']==3){
                                        ?>
                                            <p style="font-weight:bold">Status: Cancelled
                                            </p>
                                            <p style="font-weight:bold">Fare: &#8369; 00.00
                                            </p>
                                            <p style="font-weight:bold">Cashback(10%): &#8369; 00.00
                                            </p>
                                            <p style="font-weight:bold">Rider Earnings(90%): &#8369; 00.00
                                            </p>
                                        <?php
                                        }
                                    ?>
                                </div>
                        </div>
                    </div>
                </div>
                </div>
            <!-- Modal footer -->
            <div class="modal-footer">
                <button type="button" class="btn btn-default btn-block" data-dismiss="modal">Close</button>
                <!--<button type="submit" class="btn btn-danger" id="submit-track-btn" >Submit</button>-->
            </div>
        </div>
    </div>
</div>