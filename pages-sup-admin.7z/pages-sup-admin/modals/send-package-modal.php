<!--SELECT BRANCH IN PACKAGE SEND-->
<div id="send-package-<?php echo $row['order_id']; ?>" class="modal fade" role="dialog" style='z-index:999999; color:#0784b5'>
    <div class="modal-dialog  modal-xs" >  
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title text-center" style='font-weight:bold; color:#192428'>
                    <img src='../assets/image/eMove.png' style='height:40px; border-radius:50%;' />
                    Express Wheel | Send Package
                </h4>
            </div>
            <div class="modal-body">  
                <div class='row'>
                    <div class='col-sm-12 text-left'> 
                        <p>Order Number</p>
                        <input type="text" class="form-control" id="order-id<?php echo $row['order_id']; ?>" value="<?php echo $row['order_id']; ?>"/>
                        <p>Select Branch:</p>
                        <select id="select-branch-arrival<?php echo $row['order_id']; ?>" class="form-control">
                            <?php
                                $query0 = "SELECT * FROM tbl_branch";
                                $result0 = mysqli_query($conn, $query0);
                                while($rw0=mysqli_fetch_assoc($result0)){
                                    echo "<option value='$rw0[id]'>$rw0[branch_name]</option>";
                                }
                            ?>
                        </select>
                    </div>
                </div>
                <br>
                <span id="package-update-message-1-<?php echo $row['order_id']; ?>"></span>
            </div>
            <div class="modal-footer">
                <button class="btn btn-default" data-dismiss="modal">Close</button>
                <button class="btn btn-danger" onclick="package_sent(<?php echo $row['order_id']; ?>)">Submit</button>
            </div>
        </div>
    </div>
</div> 