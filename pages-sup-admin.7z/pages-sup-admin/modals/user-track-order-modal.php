
<!-- The Modal -->
<div class="modal" id="track-order" style='z-index:999999; color:#0784b5'>
  <div class="modal-dialog">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
         <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title text-center" style='font-weight:bold; color:#192428'>
            <img src='../assets/image/eMove.png' style='height:40px; border-radius:50%;' />
            Express Wheel | Track your order
        </h4>
      </div>

      <!-- Modal body -->
      <div class="modal-body" style="text-align:Left">
        <div class="row">
            <div class="col-sm-12">
                <p>Search Order Receipt Number</p>
                <input class="form-control" id="order-number">
            </div>
        </div>
        <br>
        <div class="row">
            <div class="col-sm-12">
                <p>History</p>
                <span id="span-history" class='alert alert-default'>
                    <?php
                        // $query = "select order_id from tbl_user_track_history where status = '1' group by order_id";
                        // $result = mysqli_query($conn, $query);
                        // if(mysqli_num_rows($result) > 0){
                        //     while($row = mysqli_fetch_assoc($result)){
                        //         echo "<p id='order-id$row[order_id]' style='font-weight:bolder'>$row[order_id]</p></br>";
                                
                        //     }    
                        // }
                    ?>
                </span>
            </div>
        </div>
            <br>
            <span id="track-response-message"></span>
      </div>

      <!-- Modal footer -->
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-danger" id="submit-track-btn" >Submit</button>
      </div>

    </div>
  </div>
</div>

<!-- The Modal -->
<div class="modal" id="track-order-0" style='z-index:999999; color:#0784b5'>
  <div class="modal-dialog">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
         <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title" style='font-weight:bold; color:#192428'>
            <img src='../assets/image/agri-logo.png' style='height:40px; border-radius:50%;' />
            Express Wheel | Track your order
        </h4>
      </div>

      <!-- Modal body -->
      <div class="modal-body" style="text-align:Left">
        <div class="row">
            <div class="col-sm-12">
                <label>Progress:</label>
                <div class="col-sm-12">
                    <span id="progress"></span>
                </div>
        </div>
      </div>
            
      <!-- Modal footer -->
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal" onclick="$('#track-order').modal('toggle');">Close</button>
        <!--<button type="submit" class="btn btn-danger" id="submit-track-btn" >Submit</button>-->
      </div>

    </div>
  </div>
</div>
</div>
                            
<script>
    
    // Track Order
    $("#submit-track-btn").on("click", function (){
        form = new FormData()
        form.append('order-number', $('#order-number').val())
        // form.append('user-number', "<?php //echo $userNo; ?>")
        $.ajax({
            url: 'user-track-order.php',
            data: form,
            method: 'POST',
            cache: false,
            contentType: false,
            processData: false,
        }).done( function(data){
            if(data == 0){
                $('#track-response-message').html('<div class="alert alert-danger">\
                                                        <strong>Error: </strong> Invalid Order number! Please try again.\
                                                        <a class="close" data-dismiss="alert">&times</a>\
                                                    </div>');
            }
            else{
                // Display successfull results
                $('#progress').html('');
                $('#progress').append(data)     
                $("#track-order").modal('toggle'); // closes the first modal
                $("#track-order-0").modal('toggle'); // opens the second modal 
                // $.ajax({
                //     url: 'history.php',
                //     data: form,
                //     method: 'POST',
                //     cache: false,
                //     contentType: false,
                //     processData: false,
                // })
            }
        })
    })
</script>