
<!--Edit Branch Modal-->
<div id="editBranchModal<?php echo $row['id']; ?>" class="modal fade" role="dialog" style='z-index:999999; color:#0784b5'>
    <div class="modal-dialog  modal-md"  >  
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title text-center" style='font-weight:bold; color:#192428'>
                    <img src='../assets/image/eMove.png' style='height:40px; border-radius:50%;' />
                    Express Wheel | Edit Branch
                </h4>
            </div>
            <div class="modal-body">  
                <div class='row'>
                    <div class='col-sm-12'> 
                        <p>Branch Name</p>
                        <input class="form-control" id="branch-name-<?php echo $row['id']; ?>" value="<?php echo $row['branch_name']; ?>">
                        <p>Location</p>
                        <input class="form-control" id="branch-location-<?php echo $row['id']; ?>" value="<?php echo $row['location']; ?>">
                    </div>
                </div>
                <br>
                <span id="edit-branch-message<?php echo $row['id']; ?>"></span>
            </div>
            <div class="modal-footer">
                <a type="button" class="btn btn-default" data-dismiss="modal">Cancel</a>
                <a type="button" class="btn btn-danger" id="edit-branch-btn<?php echo $row['id']; ?>">Submit</a>
            </div>
        </div>
    </div>
</div> 

<script>
    $("#edit-branch-btn<?php echo $row['id']; ?>").on('click', function(){
        form = new FormData();
        form.append('branch-name',$("#branch-name-<?php echo $row['id']; ?>").val());
        form.append('location',$("#branch-location-<?php echo $row['id']; ?>").val());
        form.append('id',"<?php echo $row['id']; ?>");
        $.ajax({
            url: 'edit-branch.php',
            data:form,
            method: 'POST',
            cache: false,
            processData:false,
            contentType: false,
        }).done( function(data){
            $('#edit-branch-message<?php echo $row['id']; ?>').html(data);
        })
    });
    
</script>