<!--Logout Modal-->
<div id="logout-modal" class="modal fade" role="dialog" style='z-index:999999; color:#0784b5'>
    <div class="modal-dialog  modal-md">  
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title text-center" style='font-weight:bold; color:#192428'>
                    <img src='../assets/image/eMove.png' style='height:40px; border-radius:50%;' />
                    Express Wheel | Sign out
                </h4>
            </div>
            <div class="modal-body">  
                <div class='row'> 
                    <div class='col-sm-12'> 
                         Do you really want to continue?   
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <a type="button" class="btn btn-default btn-block" data-dismiss="modal">Cancel</a>
                <a type="button" class="btn btn-success btn-block" href="logout.php" >Sign out</a>
            </div>
        </div>
    </div>
</div>