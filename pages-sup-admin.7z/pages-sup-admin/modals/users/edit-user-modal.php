<!--Edit Admin Modal-->
<div id="edit-user<?php echo $row['no']; ?>" class="modal fade" role="dialog" style='z-index:999999; color:#0784b5'>
    <div class="modal-dialog  modal-md"  >  
        <div class="modal-content">
            <div class="modal-header">
                <!--<button type="button" class="close" data-dismiss="modal">&times;</button>-->
                <h4 class="modal-title text-center" style='font-weight:bold; color:#192428'>
                    <img src='../assets/image/eMove.png' style='height:40px; border-radius:50%;' />
                    Express Wheel | Edit User Information
                </h4>
            </div>
            <div class="modal-body">  
                <div class='row'> 
                    <div class='col-sm-12'>
                        <label>PERSONAL INFORMATION</label> 
                        <p>First Name</p>
                        <input class="form-control" id="ufnim-<?php echo $row['no']; ?>" value="<?php echo $row['fn']; ?>">
                        <p>Middle Name</p>
                        <input class="form-control" id="umnim-<?php echo $row['no']; ?>" placeholder="(optional)" value="<?php echo $row['mn']; ?>">
                        <p>Last name</p>
                        <input class="form-control" id="ulnim-<?php echo $row['no']; ?>" value="<?php echo $row['ln']; ?>">
                        <p>Birth Date</p>
                        <input class="form-control" id="ubday-<?php echo $row['no']; ?>" value="<?php echo $row['bday']; ?>"type="date" >
                        <p>Sex</p> 
                        <select class="form-control" id="usex-<?php echo $row['no']; ?>" >
                        <?php
                            echo ($row['sex'] == 'Male') ? "<option value='$row[sex]'>$row[sex]</option><option value=Female>Female</option>" : "<option value='$row[sex]'>$row[sex]</option><option value=Male>Male</option>" ;
                        ?>  
                        </select>
                        <p>Email Address</p>
                        <input class="form-control" id="uemail-<?php echo $row['no']; ?>" value="<?php echo $row['email']; ?>">
                        <p>Contact Number</p>
                        <input class="form-control" id="ucno-<?php echo $row['no']; ?>" value="<?php echo $row['contact']; ?>" type="number">
                        <p>Municipal</p>
                        <select class="form-control" id="umun-<?php echo $row['no']; ?>" value="<?php echo $row['municipal']; ?>" >
                            <option value="<?php echo $row['municipal']?>"><?php echo $row['municipal']; ?></option>
                            <?php
                                $query=mysqli_query($conn, "select * from refcitymun where provCode = '0864' ");
                                while($res=mysqli_fetch_assoc($query)){
                                    echo "<option value=$res[citymunCode]>$res[citymunDesc]</option>";
                                }
                            ?>
                        </select>
                        <p>Barangay</p>
                        <select class="form-control" id="ubrgy-<?php echo $row['no']; ?>" >
                            <option value="<?php echo $row['barangay']; ?>"><?php echo $row['barangay']; ?></option>
                        </select>
                        <p>Purok</p>
                        <input class="form-control" id="upurok-<?php echo $row['no']; ?>" placeholder="(optional)" value="<?php echo $row['purok']; ?>">
                        <p>Zipcode</p>
                        <input class="form-control" id="uzcode-<?php echo $row['no']; ?>" value="<?php echo $row['zipcode']; ?>">
                        <p>Landmark</p>
                        <input class="form-control" id="ulmark-<?php echo $row['no']; ?>" value="<?php echo $row['landmark']; ?>">
                        <br>
                        <label>LOGIN CREDENTIALS</label>
                        <p>Username</p>
                        <input class="form-control" id="uunim-<?php echo $row['no']; ?>" value="<?php echo $row['user']; ?>" placeholder="will not change if empty">
                        <p>Password</p>
                        <input class="form-control" id="upass-<?php echo $row['no']; ?>" placeholder="will not change if empty">
                        <p>Confirm Password</p>
                        <input class="form-control" id="ucpass-<?php echo $row['no']; ?>" placeholder="will not change if empty">
                    </div>
                </div>
                <br>
                <span id="edit-user-message<?php echo $row['no']; ?>"></span>
            </div>
            <div class="modal-footer">
                <a type="button" class="btn btn-default btn-block" data-dismiss="modal">Cancel</a>
                <a type="button" class="btn btn-danger btn-block" id="edit-user-btn<?php echo $row['no']; ?>">Submit</a>
            </div>
        </div>
    </div>
</div>

<div id="edit-user" class="modal fade" role="dialog" style='z-index:999999; color:#0784b5'>
    <div class="modal-dialog  modal-xs" >  
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title text-center" style='font-weight:bold; color:#192428'>
                    <img src='../assets/image/eMove.png' style='height:40px; border-radius:50%;' />
                    Express Wheel | Edit User
                </h4>
            </div>
            <div class="modal-body">  
                <div class='row'>
                    <div class='col-sm-12 text-center'> 
                        <p id="edit-user-message"></p>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <a type="button" class="btn btn-danger btn-block" onclick="history.go(0);">OK</a>
            </div>
        </div>
    </div>
</div> 

<script>
    $('#edit-user-btn<?php echo $row['no']; ?>').on('click', function(){
        var id="<?php echo $row['no']; ?>";
        var ufnim=$('#ufnim-'+id).val();
        var umnim=$('#umnim-'+id).val();
        var ulnim=$('#ulnim-'+id).val();
        var ubday=$('#ubday-'+id).val();
        var ucno=$('#ucno-'+id).val();
        var upurok=$('#upurok-'+id).val();
        var ubrgy=$('#ubrgy-'+id+" :selected").text();
        var umun=$('#umun-'+id+' :selected').text();
        var uzcode=$('#uzcode-'+id).val();
        var ulmark=$('#ulmark-'+id).val();
        var usex=$('#usex-'+id).val();
        var uemail=$('#uemail-'+id).val();
        var uunim=$('#uunim-'+id).val();
        var upass=$('#upass-'+id).val();
        var ucpass=$('#ucpass-'+id).val();
        
        form=new FormData();
        (ufnim=='') ? form.append('ufnim', '<?php echo $row['fn']; ?>') : form.append('ufnim', ufnim);
        (umnim=='') ? form.append('umnim', '<?php echo $row['mn']; ?>') : form.append('umnim', umnim);
        (ulnim=='') ? form.append('ulnim', '<?php echo $row['ln']; ?>') : form.append('ulnim', ulnim);
        (ubday=='') ? form.append('ubday', '<?php echo $row['bday']; ?>') : form.append('ubday', ubday);
        (ucno=='') ? form.append('ucno', '<?php echo $row['contact']; ?>') : form.append('ucno', ucno);
        (upurok=='') ? form.append('upurok', '<?php echo $row['purok']; ?>') : form.append('upurok', upurok);
        (ubrgy=='') ? form.append('ubrgy', '<?php echo $row['barangay']; ?>') : form.append('ubrgy', ubrgy);
        (umun=='') ? form.append('umun', '<?php echo $row['municipal']; ?>') : form.append('umun', umun);
        (uzcode=='') ? form.append('uzcode', '<?php echo $row['zipcode']; ?>') : form.append('uzcode', uzcode);
        (ulmark=='') ? form.append('ulmark', '<?php echo $row['landmark']; ?>') : form.append('ulmark', ulmark);
        (usex=='') ? form.append('usex', '<?php echo $row['sex']; ?>') : form.append('usex', usex);
        (uemail=='') ? form.append('uemail', '<?php echo $row['user']; ?>') : form.append('uemail', uemail);
        form.append('upass', upass);
        form.append('ucpass', ucpass);
        form.append('id', id);
        (uunim == '') ? form.append('uunim', '<?php echo $row['user']; ?>') : form.append('uunim', uunim);
        $.ajax({
            url: 'edit-user.php',
            method: 'POST',
            data: form,
            cache: false,
            processData: false,
            contentType: false,
            dataType:'json',
        }).done( function(data){
            $('#edit-user-message<?php echo $row['no']; ?>').html(data);
            if(data[1]==0){
                $('#edit-user<?php echo $row['no']; ?>').modal('toggle');
                $('#edit-user').modal('toggle');
                $('#edit-user-message').html('You have successfully updated a user...');
            }
        })
    })
    
    $('#umun-<?php echo $row['no']; ?>').on('change', () => {
        form=new FormData();
        form.append('mun', $('#umun-<?php echo $row['no']; ?>').val());
        form.append('brgy',$('#ubrgy-<?php echo $row['no']; ?>').val());
        $.ajax({
            data:form,
            type:'post',
            url:'load-barangay.php',
            processData:false,
            contentType:false,
            cache:false,
        }).done((data)=>{
            $('#ubrgy-<?php echo $row['no']; ?>').append(data);
        })
    })
</script>
