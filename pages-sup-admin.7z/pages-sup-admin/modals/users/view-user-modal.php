<!-- The Modal -->
<div class="modal" id="view-user<?php echo $row['no']; ?>" style='z-index:999999; color:#0784b5'>
  <div class="modal-dialog">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header text-center">
         <!--<button type="button" class="close" data-dismiss="modal">&times;</button>-->
        <h4 class="modal-title" style='font-weight:bold; color:#192428'>
            <img src='../assets/image/emove.png' style='height:40px; border-radius:50%;' />
            Express Wheel | User Information
        </h4>
      </div>

      <!-- Modal body -->
      <div class="modal-body" style="text-align:Left">
        <div class="row">
            <div class="col-sm-12">
                <div class="form-group">
                    <?php 
                        $q=mysqli_query($conn, "select * from tbl_user where no = '$row[no]' ");
                        $r = mysqli_fetch_assoc($q);
                    ?>  
                        <div class="col-sm-12">
                            <br>
                            <p style="text-align:center"><img src="../assets/image/1613698030.png" style="width:120px; height:120px"></p>
                            <br>
                            <p style="font-weight:bold">First Name: <?php echo strtoupper($r['fn']); ?></p>
                            <p style="font-weight:bold">Middle Name: <?php echo strtoupper($r['mn']); ?></p>
                            <p style="font-weight:bold">Last Name: <?php echo strtoupper($r['ln']); ?></p>
                            <p style="font-weight:bold">Sex: <?php echo $r['sex']; ?></p>
                            <p style="font-weight:bold">Birth Date: <?php echo strtoupper($r['bday']); ?></p>
                            <p style="font-weight:bold">Contact Number: <?php echo $r['contact']; ?></p>
                            <p style="font-weight:bold">Email Address: <?php echo strtoupper($r['email']); ?></p>
                            <p style="font-weight:bold">Home Address: <?php echo strtoupper($r['purok'].', '.$r['barangay'].', '.$r['municipal'].', ('.$r['zipcode'].')'); ?></p>
                        </div>
                </div>
            </div>
        </div>
        </div>
      <!-- Modal footer -->
      <div class="modal-footer">
        <button type="button" class="btn btn-default btn-block" data-dismiss="modal">Close</button>
        <!--<button type="submit" class="btn btn-danger" id="submit-track-btn" >Submit</button>-->
      </div>
  </div>
</div>
</div>