
                            <!-- The Modal -->
                            <div class="modal" id="make-order" style='z-index:999999; color:#0784b5'>
                              <div class="modal-dialog">
                                <div class="modal-content">
                            
                                  <!-- Modal Header -->
                                  <div class="modal-header">
                                     <button type="button" class="close" data-dismiss="modal">&times;</button>
                                    <h4 class="modal-title" style='font-weight:bold; color:#192428'>
                                        <img src='../assets/image/eMove.png' style='height:40px; border-radius:50%;' />
                                        Express Wheel | Make an order
                                    </h4>
                                  </div>
                            
                                  <!-- Modal body -->
                                  <div class="modal-body" style="text-align:left">
                                        <div class="row">
                                            <div class="col-sm-6">
                                                <p>Sender Name: </p> 
                                                <input class="form-control" id="sender-name">
                                                
                                                <p>Contact Number:</p>
                                                <input class="form-control" type="number" id="sender-contact"  min="1" step="1" oninput="validity.valid||(value='');">
                                                
                                                <p>Address:</p>
                                                <div class="row">
                                                    <div class="col-sm-4">
                                                        <p>Province</p>
                                                        <select id="select-province-0" class="form-control">
                                                            <?php
                                                                $query = "select * from refprovince WHERE provCode = '0864' order by provDesc ASC ";
                                                                $province = mysqli_query($conn, $query);
                                                                while($row = mysqli_fetch_assoc($province)){
                                                                    echo "<option value='$row[provCode]'>$row[provDesc]</option>";
                                                                }
                                                            ?>
                                                        </select>
                                                    </div>
                                                    <div class="col-sm-4">
                                                        <p>City</p>
                                                        <select id="select-citymun-0" class="form-control"></select>
                                                    </div>
                                                    <div class="col-sm-4">
                                                        <p>Barangay</p>
                                                        <select id="select-barangay-0" class="form-control"></select>
                                                    </div>
                                                </div>
                                                <!--<textarea class="form-control" id="sender-address"></textarea>-->
                                            </div>
                                            <div class="col-sm-6">
                                                <p>Recipient Name: </p> 
                                                <input class="form-control" id="recipient-name">
                                                
                                                <p>Contact Number:</p>
                                                <input class="form-control" type="number"  id="recipient-contact"  min="1" step="1" oninput="validity.valid||(value='');">
                                                
                                                <p>Destination:</p>
                                                <div class="row">
                                                    <div class="col-sm-4">
                                                        <p>Province</p>
                                                        <select id="select-province-1" class="form-control">
                                                            <?php
                                                                $query = "select * from refprovince WHERE provCode = '0864' order by provDesc ASC";
                                                                $province = mysqli_query($conn, $query);
                                                                while($row = mysqli_fetch_assoc($province)){
                                                                    echo "<option value='$row[provCode]'>$row[provDesc]</option>";
                                                                }
                                                            ?>
                                                        </select>
                                                    </div>
                                                    <div class="col-sm-4">
                                                        <p>City</p>
                                                        <select id="select-citymun-1" class="form-control"></select>
                                                    </div>
                                                    <div class="col-sm-4">
                                                        <p>Barangay</p>
                                                        <select id="select-barangay-1" class="form-control"></select>
                                                    </div>
                                                </div>
                                                <!--<textarea class="form-control"  id="recipient-address"></textarea>-->
                                            </div>
                                        </div> 
                                        <div class="row">
                                            <div class="col-sm-12">
                                                <p>Item Name:</p>
                                                <input class="form-control" id="item-name">
                                                
                                                <p>Weight(KG):</p>
                                                <input class="form-control" id="item-weight" onkeypress="return event.charCode != 45">
                                                
                                                <p>Quantity:</p>
                                                <input class="form-control" id="item-quantity" type="number" min="1" step="1" oninput="validity.valid||(value='');">
                                                
                                                <p>Item Value:</p>
                                                <input class="form-control" id="item-value" type="number"  onkeypress="return event.charCode != 45">
                                                
                                                <p>Length(CM):</p>
                                                <input class="form-control" id="item-length" type="number"  onkeypress="return event.charCode != 45">
                                                
                                                <p>Width(CM):</p>
                                                <input class="form-control" id="item-width" type="number"  onkeypress="return event.charCode != 45">
                                                
                                                <p>Height(CM):</p>
                                                <input class="form-control" id="item-height" type="number"  onkeypress="return event.charCode != 45">
                                                
                                                <p>Service type:</p>
                                                <input class="form-control" value="Standard" readonly id="item-service-type">
                                                
                                                <p>Package type:</p>
                                                <select class="form-control" id="item-package-type">
                                                    <option value="0">No Package</option>
                                                    <option value="1">Box</option>
                                                    <option value="2">Pouch</option>
                                                </select>
                                                
                                                <p>Delivery</p>
                                                <select class="form-control" id="item-delivery-type">
                                                    <option value="0">Same day</option>
                                                    <option value="1">Scheduled</option>
                                                </select>
                                                <span id="item-scheduled-span"></span>
                                                
                                                <p>Fee:</p>
                                                <input class="form-control" id="item-fee" type="number"  onkeypress="return event.charCode != 45">
                                                
                                                <p>Remarks:</p>
                                                <textarea  class="form-control" id="item-remarks"></textarea>
                                                
                                                <p>Branch</p>
                                                <select id="select-branch" class="form-control">
                                                    <?php
                                                        $query = "select * from tbl_branch order by branch_name";
                                                        $result = mysqli_query($conn, $query);
                                                        while($row = mysqli_fetch_assoc($result)){
                                                            echo "<option value='$row[id]'>$row[branch_name]</option>";
                                                        }
                                                    ?>
                                                </select>
                                            </div>
                                        </div>
                                        
                                        <br>
                                        <span id="response-message"></span>
                                  </div>
                            
                                  <!-- Modal footer -->
                                  <div class="modal-footer">
                                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                    <button type="submit" class="btn btn-danger" id="submit-order-btn" >Submit</button>
                                  </div>
                            
                                </div>
                              </div>
                            </div>
                            
<script>
    // Submit Order
    $("#submit-order-btn").on("click", function(){
        // var sender_address = $("#select-barangay-0 :selected").text()+", "+$("#select-citymun-0 :selected").text()+", "+$("#select-province-0 :selected").text();
        // var recipient_address = $("#select-barangay-1 :selected").text()+", "+$("#select-citymun-1 :selected").text()+", "+$("#select-province-1 :selected").text();
        form = new FormData()
        form.append("sender-name",$("#sender-name").val())
        form.append("sender-contact",$("#sender-contact").val())
        form.append("sender-barangay",$("#select-barangay-0 :selected").text())
        form.append("sender-city",$("#select-citymun-0 :selected").text())
        form.append("sender-province",$("#select-province-0 :selected").text())
        form.append("recipient-name",$("#recipient-name").val())
        form.append("recipient-contact",$("#recipient-contact").val())
        form.append("recipient-barangay",$("#select-barangay-1 :selected").text())
        form.append("recipient-city",$("#select-citymun-1 :selected").text())
        form.append("recipient-province",$("#select-province-1 :selected").text())
        form.append("item-name",$("#item-name").val())
        form.append("item-weight",$("#item-weight").val())
        form.append("item-quantity",$("#item-quantity").val())
        form.append("item-value",$("#item-value").val())
        form.append("item-length",$("#item-length").val())
        form.append("item-width",$("#item-width").val())
        form.append("item-height",$("#item-height").val())
        form.append("item-service-type",$("#item-service-type").val())
        form.append("item-package-type",$("#item-package-type :selected").text())
        form.append("item-delivery-type",$("#item-delivery-type :selected").text())
        form.append("item-scheduled",$("#item-scheduled").val()) //date type
        form.append("item-fee",$("#item-fee").val())
        form.append("item-remarks",$("#item-remarks").val())
        form.append("branch-id",$("#select-branch").val())
        
        $.ajax({
            url: "user-make-order.php",
            method: "POST",
            data: form,
            cache: false,
            contentType: false,
            processData: false
        }).done( function(data){
            $('#response-message').html(data);
        })
    })
</script>