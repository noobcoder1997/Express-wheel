<!--Add Branch Modal-->
<div id="addBranchModal" class="modal fade" role="dialog" style='z-index:999999; color:#0784b5'>
    <div class="modal-dialog  modal-md"  >  
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title text-center" style='font-weight:bold; color:#192428'>
                    <img src='../assets/image/eMove.png' style='height:40px; border-radius:50%;' />
                    Express Wheel | Add Branch
                </h4>
            </div>
            <div class="modal-body">  
                <div class='row'> 
                    <div class='col-sm-12'> 
                        <p>Branch Name</p>
                        <input class="form-control" id="branch-name">
                        <p>Location</p>
                        <input class="form-control" id="branch-location">
                    </div>
                </div>
                <br>
                <span id="add-branch-message"></span>
            </div>
            <div class="modal-footer">
                <a type="button" class="btn btn-default" data-dismiss="modal">Cancel</a>
                <a type="button" class="btn btn-danger" id="create-branch-btn">Submit</a>
            </div>
        </div>
    </div>
</div> 

<script>
    $('#create-branch-btn').on('click', function(){
        var name = $('#branch-name').val();
        var location = $('#branch-location').val();
        if(name == '' || location == ''){
            $("#add-branch-message").html(`<div class="alert alert-danger">
                <strong>Error Branch Name:</strong>
                You have inputted an Invalid branch name!
            </div>`);
        }
        else{
            form = new FormData()
            form.append('branch-name', $('#branch-name').val())
            form.append('branch-location', $('#branch-location').val())
            $.ajax({
                url: 'add-branch.php',
                data: form,
                method: 'POST',
                cache: false,
                contentType: false,
                processData: false,
            }).done( function(data){
                $("#add-branch-message").html(data)
                
                // var reLoad = setTimeout(()=>{
                //     $("#addBranchModal").modal('toggle')
                //     window.location.reload(true)
                // },2000);
                // reLoad;
            })
        }
    })
</script>











