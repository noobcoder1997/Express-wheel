<!-- The Modal -->
<div class="modal" id="view-order<?php echo $row['id']; ?>" style='z-index:999999; color:#0784b5'>
  <div class="modal-dialog">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
         <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title" style='font-weight:bold; color:#192428'>
            <img src='../assets/image/agri-logo.png' style='height:40px; border-radius:50%;' />
            Express Wheel | Track your order
        </h4>
      </div>

      <!-- Modal body -->
      <div class="modal-body" style="text-align:Left">
        <div class="row">
            <div class="col-sm-12">
                
                <label>Progress:</label>
                <div class="col-sm-12">
                    <span id="progress<?php echo $row['id']; ?>"></span>
                </div>
            </div>
        </div>
        <br>
      <!-- Modal footer -->
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        <!--<button type="submit" class="btn btn-danger" id="submit-track-btn" >Submit</button>-->
      </div>

    </div>
  </div>
</div>
</div>
                            
<script>
    $("#view-order<?php echo $row['id']; ?>").on('show.bs.modal', function () {
        // Track Order
        form = new FormData()
        form.append('order-number', "<?php echo $row['order_id']; ?>")
        // form.append('user-number', "<?php //echo $userNo; ?>")
        $.ajax({
            url: 'user-track-order.php',
            data: form,
            method: 'POST',
            cache: false,
            contentType: false,
            processData: false,
        }).done( function(data){
            if(data == 0){
                $('#track-response-message').html('<div class="alert alert-danger">\
                                                        <strong>Error: </strong> Invalid Order number! Please try again.\
                                                        <a class="close" data-dismiss="alert">&times</a>\
                                                    </div>');
            }
            else{
                // Display successfull results
                $('#progress<?php echo $row['id']; ?>').html('');
                $('#progress<?php echo $row['id']; ?>').append(data)     
                // $("#track-order-0").modal('toggle'); // opens the second modal 
                // $.ajax({
                //     url: 'history.php',
                //     data: form,
                //     method: 'POST',
                //     cache: false,
                //     contentType: false,
                //     processData: false,
                // })
            }
        })
    });
</script>