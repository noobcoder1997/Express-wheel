<!-- The Modal -->
<div class="modal" id="view-rider<?php echo $row['no']; ?>" style='z-index:999999; color:#0784b5'>
  <div class="modal-dialog">
    <div class="modal-content">
      <!-- Modal Header -->
      <div class="modal-header text-center">
         <!--<button type="button" class="close" data-dismiss="modal">&times;</button>-->
        <h4 class="modal-title" style='font-weight:bold; color:#192428'>
            <img src='../assets/image/emove.png' style='height:40px; border-radius:50%;' />
            Express Wheel | Rider Information
        </h4>
      </div>
      <!-- Modal body -->
      <div class="modal-body" style="text-align:Left">
        <div class="row">
          <div class="col-sm-12">
            <div class="form-group">
            <?php 
                  $q=mysqli_query($conn, "select * from tbl_user where no = '$row[no]' ");
                  $r = mysqli_fetch_assoc($q);
              ?>  
              <div class="col-sm-12">
                  <br>
                  <p style="text-align:center"><img src="../assets/image/1613698030.png" style="width:120px; height:120px"></p>
                  <br>
                  <a href="#r-info" data-toggle="collapse" class="btn btn-primary" style="margin-bottom:20px;width: 100%">
                    <span class="fa fa-eye fa-fw"></span> Rider Information
                  </a>
                  <div class="collapse" id="r-info">
                    <p style="font-weight:bold">First Name: <?php echo strtoupper($r['fn']); ?></p>
                    <p style="font-weight:bold">Middle Name: <?php echo strtoupper($r['mn']); ?></p>
                    <p style="font-weight:bold">Last Name: <?php echo strtoupper($r['ln']); ?></p>
                    <p style="font-weight:bold">Sex: <?php echo $r['sex']; ?></p>
                    <p style="font-weight:bold">Birth Date: <?php echo strtoupper($r['bday']); ?></p>
                    <p style="font-weight:bold">Contact Number: <?php echo $r['contact']; ?></p>
                    <p style="font-weight:bold">Email Address: <?php echo strtoupper($r['email']); ?></p>
                    <p style="font-weight:bold">Home Address: <?php echo strtoupper($r['purok'].', '.$r['barangay'].', '.$r['municipal'].', ('.$r['zipcode'].')'); ?></p>
                  </div>
              </div>
              <div class="col-sm-12">
                <a href="#collapse" data-toggle="collapse" class="btn btn-success" style="margin-bottom:20px;width: 100%">
                  <span class="fa fa-eye fa-fw"></span> View Earnings
                </a>
                <div class="collapse" id="collapse">
                  <div class="col-sm-12 input-group text-right">
                    <input type="text" class="form-control" placeholder="Search DATE like 1970-01-01..." oninput="onInput(this)">
                    <br>
                    <br>
                  </div>
                  <div class="table-responsive" style="max-height:40vh;overflow:auto;width:100%">
                      <div class="col-sm-12">
                        <div class="row">
                            <div class="col-sm-3" style="font-weight:bolder; color: #5b2c6f;">Date</div>
                            <div class="col-sm-3" style="font-weight:bolder; color: #5b2c6f;">Earnings</div>
                            <div class="col-sm-3" style="font-weight:bolder; color: #5b2c6f;">Cashback</div>
                            <div class="col-sm-3" style="font-weight:bolder; color: #5b2c6f;">Final Income</div>
                        </div>
                      </div>
                      <div class="col-sm-12" id="datas">
                      <?php 
                      $datas = array();

                      $query = mysqli_query($conn, "SELECT DATE_FORMAT(_timestamp, '%Y-%m-%d') as _timestamp, SUM(fares) AS fares FROM (SELECT _timestamp, fare AS fares FROM tbl_book_ride WHERE rider_id = '$row[no]' AND status = 2 AND rider_status = 2 UNION ALL SELECT _timestamp, fee AS fares FROM tbl_user_make_order WHERE rider_id = '$row[no]' AND status = 2 AND rider_status = 2 ) AS combined GROUP BY DATE_FORMAT(_timestamp, '%Y-%m-%d')");

                      $datas = array();
                      $sum = 0;
                      $payback = 0;
                      $income = 0;
                      $index = 0;

                      while($res = mysqli_fetch_assoc($query)){
                          $timestamp = $res['_timestamp'];
                          $sum += $res['fares'];
                          $payback += ($res['fares'] * 0.10);
                          $income += $res['fares'] - ($res['fares'] * 0.10);
                          $datas[$index] = [
                              'timestamp' => $timestamp,
                              'fare' => $res['fares'],
                              'payback' => ($res['fares'] * 0.10),
                              'income' => ($res['fares'] - ($res['fares'] * 0.10))
                          ];
                          $index++;
                      }

                      foreach($datas as $data):
                      ?>
                          <div class="row">
                              <div class="col-sm-3">
                                  <?php echo $data['timestamp']; ?>
                              </div>
                              <div class="col-sm-3">
                                  <?php echo number_format($data['fare'], 2); ?>
                              </div>
                              <div class="col-sm-3">
                                  <?php echo number_format($data['payback'], 2); ?>
                              </div>
                              <div class="col-sm-3">
                                  <?php echo number_format($data['income'], 2); ?>
                              </div>
                          </div>
                      <?php 
                      endforeach;
                      ?>
                      </div>
                      <div class="col-sm-12" id="searched-data">
                          <div class="row">
                              <div class="col-sm-3">
                                  <span id="date"></span>
                              </div>
                              <div class="col-sm-3">
                                  <span id="fare"></span>
                              </div>
                              <div class="col-sm-3">
                                  <span id="payback"></span>
                              </div>
                              <div class="col-sm-3">
                                  <span id="income"></span>
                              </div>
                          </div>
                      </div>
                  </div>
                  <br>
                  <div class="row" style="background-color: #21618c;text-shadow: -1px 0 black, 0 1px black, 1px 0 black, 0 -1px black; ">
                    <div class="col-sm-10">
                      <p style="color:#fff; text-align:left;">Total Earnings: <strong style="font-size:24px">&#x20B1; <?php echo $sum; ?></strong></p>
                    </div>
                  </div>
                  <div class="row" style="background-color: #f1c40f; text-shadow: -1px 0 black, 0 1px black, 1px 0 black, 0 -1px black;">
                    <div class="col-sm-10">
                      <p style="color:#fff; text-align:left;">Total Payback: <strong style="font-size:24px">&#x20B1; <?php echo $payback; ?></strong></p>
                    </div>
                  </div>
                  <div class="row" style="background-color: #2ecc71; text-shadow: -1px 0 black, 0 1px black, 1px 0 black, 0 -1px black;">
                    <div class="col-sm-10">
                      <p style="color:#fff; text-align:left;">Total Income: &nbsp;&nbsp;<strong style="font-size:24px">&#x20B1; <?php echo $income; ?></strong></p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <!-- form-group -->
          </div>
          <!-- col-sm-12 -->
        </div>
        <!-- row -->
      </div>
      <!-- Modal footer -->
      <div class="modal-footer">
        <button type="button" class="btn btn-default btn-block" data-dismiss="modal">Close</button>
        <!--<button type="submit" class="btn btn-danger" id="submit-track-btn" >Submit</button>-->
      </div>
    </div>
  </div>
</div>

<div class="modal" id="myModal">
  <div class="modal-dialog">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title">Modal Heading</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>

      <!-- Modal body -->
      <div class="modal-body">

      </div>

      <!-- Modal footer -->
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
      </div>

    </div>
  </div>
</div>

<script>
  function onInput(input){
    $.ajax({
      data: 'date='+$(input).val(),
      type: 'post',
      url:  'search-date.php',
      dataType: 'json',
      success: (data)=>{
        if(data[0].date != ""){
          $('#date').text(data[0].date);
          $('#fare').text(data[0].fare);
          $('#payback').text(data[0].payback);
          $('#income').text(data[0].final_income);
          $('#search-data').show();
          $('#datas').hide();
        }
        else{
          $('#search-data').hide();         
          $('#datas').show();
        }
      },
      error: (error)=>{
        console.log(error.error);
      },
    });
  }
</script>