<!--Edit Rider Modal-->
<div id="edit-rider<?php echo $row['no']; ?>" class="modal fade" role="dialog" style='z-index:999999; color:#0784b5'>
    <div class="modal-dialog  modal-md"  >  
        <div class="modal-content">
            <div class="modal-header">
                <!--<button type="button" class="close" data-dismiss="modal">&times;</button>-->
                <h4 class="modal-title text-center" style='font-weight:bold; color:#192428'>
                    <img src='../assets/image/eMove.png' style='height:40px; border-radius:50%;' />
                    Express Wheel | Edit Rider Information
                </h4>
            </div>
            <div class="modal-body">  
                <div class='row'> 
                    <div class='col-sm-12'>
                        <label>PERSONAL INFORMATION</label> 
                        <p>First Name</p>
                        <input class="form-control" id="rfnim-<?php echo $row['no']; ?>" value="<?php echo $row['fn']; ?>">
                        <p>Middle Name</p>
                        <input class="form-control" id="rmnim-<?php echo $row['no']; ?>" placeholder="(optional)" value="<?php echo $row['mn']; ?>">
                        <p>Last name</p>
                        <input class="form-control" id="rlnim-<?php echo $row['no']; ?>" value="<?php echo $row['ln']; ?>">
                        <p>Birth Date</p>
                        <input class="form-control" id="rbday-<?php echo $row['no']; ?>" value="<?php echo $row['bday']; ?>"type="date" >
                        <p>Sex</p> 
                        <select class="form-control" id="rsex-<?php echo $row['no']; ?>" >
                        <?php
                            echo ($row['sex'] == 'Male') ? "<option value='$row[sex]'>$row[sex]</option><option value=Female>Female</option>" : "<option value='$row[sex]'>$row[sex]</option><option value=Male>Male</option>" ;
                        ?>  
                        </select>
                        <p>Email Address</p>
                        <input class="form-control" id="remail-<?php echo $row['no']; ?>" value="<?php echo $row['email']; ?>">
                        <p>Contact Number</p>
                        <input class="form-control" id="rcno-<?php echo $row['no']; ?>" value="<?php echo $row['contact']; ?>" type="number">
                        <p>Municipal</p>
                        <select class="form-control" id="rmun-<?php echo $row['no']; ?>" value="<?php echo $row['municipal']; ?>" >
                            <option value="<?php echo $row['municipal']?>"><?php echo $row['municipal']; ?></option>
                            <?php
                                $query=mysqli_query($conn, "select * from refcitymun where provCode = '0864' ");
                                while($res=mysqli_fetch_assoc($query)){
                                    echo "<option value=$res[citymunCode]>$res[citymunDesc]</option>";
                                }
                            ?>
                        </select>
                        <p>Barangay</p>
                        <select class="form-control" id="rbrgy-<?php echo $row['no']; ?>" >
                            <option value="<?php echo $row['barangay']; ?>"><?php echo $row['barangay']; ?></option>
                        </select>
                        <p>Purok</p>
                        <input class="form-control" id="rpurok-<?php echo $row['no']; ?>" placeholder="(optional)" value="<?php echo $row['purok']; ?>">
                        <p>Zipcode</p>
                        <input class="form-control" id="rzcode-<?php echo $row['no']; ?>" value="<?php echo $row['zipcode']; ?>">
                        <p>Landmark</p>
                        <input class="form-control" id="rlmark-<?php echo $row['no']; ?>" value="<?php echo $row['landmark']; ?>">
                        <br>
                        <label>LOGIN CREDENTIALS</label>
                        <p>Username</p>
                        <input class="form-control" id="runim-<?php echo $row['no']; ?>" value="<?php echo $row['user']; ?>" placeholder="will not change if empty">
                        <p>Password</p>
                        <input class="form-control" id="rpass-<?php echo $row['no']; ?>" placeholder="will not change if empty">
                        <p>Confirm Password</p>
                        <input class="form-control" id="rcpass-<?php echo $row['no']; ?>" placeholder="will not change if empty">
                    </div>
                </div>
                <br>
                <span id="edit-rider-message<?php echo $row['no']; ?>"></span>
            </div>
            <div class="modal-footer">
                <a type="button" class="btn btn-default btn-block" data-dismiss="modal">Cancel</a>
                <a type="button" class="btn btn-danger btn-block" id="edit-rider-btn<?php echo $row['no']; ?>">Submit</a>
            </div>
        </div>
    </div>
</div>

<div id="edit-rider" class="modal fade" role="dialog" style='z-index:999999; color:#0784b5'>
    <div class="modal-dialog  modal-xs" >  
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title text-center" style='font-weight:bold; color:#192428'>
                    <img src='../assets/image/eMove.png' style='height:40px; border-radius:50%;' />
                    Express Wheel | Edit Rider
                </h4>
            </div>
            <div class="modal-body">  
                <div class='row'>
                    <div class='col-sm-12 text-center'> 
                        <p id="edit-rider-message"></p>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <a type="button" class="btn btn-danger btn-block" onclick="history.go(0);">OK</a>
            </div>
        </div>
    </div>
</div> 

<script>
    $('#edit-rider-btn<?php echo $row['no']; ?>').on('click', function(){
        var id="<?php echo $row['no']; ?>";
        var ufnim=$('#rfnim-'+id).val();
        var ulnim=$('#rlnim-'+id).val();
        var umnim=$('#rmnim-'+id).val();
        var ubday=$('#rbday-'+id).val();
        var ucno=$('#rcno-'+id).val();
        var upurok=$('#rpurok-'+id).val();
        var ubrgy=$('#rbrgy-'+id+" :selected").text();
        var umun=$('#rmun-'+id+' :selected').text();
        var uzcode=$('#rzcode-'+id).val();
        var ulmark=$('#rlmark-'+id).val();
        var usex=$('#rsex-'+id).val();
        var uemail=$('#remail-'+id).val();
        var uunim=$('#runim-'+id).val();
        var upass=$('#rpass-'+id).val();
        var ucpass=$('#rcpass-'+id).val();
        
        form=new FormData();
        (ufnim=='') ? form.append('rfnim', '<?php echo $row['fn']; ?>') : form.append('rfnim', ufnim);
        (umnim=='') ? form.append('rmnim', '<?php echo $row['mn']; ?>') : form.append('rmnim', umnim);
        (ulnim=='') ? form.append('rlnim', '<?php echo $row['ln']; ?>') : form.append('rlnim', ulnim);
        (ubday=='') ? form.append('rbday', '<?php echo $row['bday']; ?>') : form.append('rbday', ubday);
        (ucno=='') ? form.append('rno', '<?php echo $row['contact']; ?>') : form.append('rcno', ucno);
        (upurok=='') ? form.append('rpurok', '<?php echo $row['purok']; ?>') : form.append('rpurok', upurok);
        (ubrgy=='') ? form.append('rbrgy', '<?php echo $row['barangay']; ?>') : form.append('rbrgy', ubrgy);
        (umun=='') ? form.append('rmun', '<?php echo $row['municipal']; ?>') : form.append('rmun', umun);
        (uzcode=='') ? form.append('rzcode', '<?php echo $row['zipcode']; ?>') : form.append('rzcode', uzcode);
        (ulmark=='') ? form.append('rlmark', '<?php echo $row['landmark']; ?>') : form.append('rlmark', ulmark);
        (usex=='') ? form.append('rsex', '<?php echo $row['sex']; ?>') : form.append('rsex', usex);
        (uemail=='') ? form.append('remail', '<?php echo $row['user']; ?>') : form.append('remail', uemail);
        form.append('rpass', upass);
        form.append('rcpass', ucpass);
        form.append('id', id);
        (uunim == '') ? form.append('runim', '<?php echo $row['user']; ?>') : form.append('runim', uunim);
        $.ajax({
            url: 'edit-rider.php',
            method: 'POST',
            data: form,
            cache: false,
            processData: false,
            contentType: false,
            dataType:'json',
        }).done( function(data){
            $('#edit-rider-message<?php echo $row['no']; ?>').html(data);
            if(data[1]==0){
                $('#edit-rider<?php echo $row['no']; ?>').modal('toggle');
                $('#edit-rider').modal('toggle');
                $('#edit-rider-message').html('You have successfully updated a rider...');
            }
        })
    })
    
    $('#umun-<?php echo $row['no']; ?>').on('change', () => {
        form=new FormData();
        form.append('mun', $('#rmun-<?php echo $row['no']; ?>').val());
        form.append('brgy',$('#rbrgy-<?php echo $row['no']; ?>').val());
        $.ajax({
            data:form,
            type:'post',
            url:'load-barangay.php',
            processData:false,
            contentType:false,
            cache:false,
        }).done((data)=>{
            $('#rbrgy-<?php echo $row['no']; ?>').append(data);
        })
    })
</script>



