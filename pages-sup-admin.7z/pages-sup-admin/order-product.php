<HTML> 
<head> 
<TITLE>e-Baligya</TITLE>  
<link rel="icon" href="../assets/image/agri-logo.png">
<meta name="viewport" content="width=device-width, initial-scale=1.0"> 
<link rel="stylesheet" href="../lib/bootstrap/css/bootstrap.css">
<link rel="stylesheet" href="../lib/bootstrap/css/bootstrap.min.css">
<link rel="stylesheet" href="../lib/font-awesome-5/css/all.css">
<script src="../lib/jquery/jquery-1.11.3.js"></script>
<script src="../lib/bootstrap/js/bootstrap.min.js"></script>
<?php
    include "../components/comp-conn.php"; 
    session_start();
    $userNo =  "NO USER NUMBER".$_SESSION['userNo'];
    if(!isset($_SESSION['userNo'])){
        ?>
        <script>
            window.location.href='../';
        </script>
        <?php
    }else{
        $userNo = $_SESSION['userNo'];
    } 
    
    $userQry = mysqli_query($conn,"SELECT * FROM tbl_user WHERE no='$userNo' ")or die(mysqli_error($conn));
    $userRw  = mysqli_fetch_assoc($userQry);
    $verified = $userRw['verified'];
    if($verified == 2){
        
         ?>
        <script>
            alert("Sorry it seem your account has been deactivated. Please contact the customer service.")
            window.location.href='../';
        </script>
        <?php
    }else if($verified==1){
        $ver = "";
    }else{ 
        $pg  = 'verified-account.php';
        $ver = '<a   data-toggle="modal" data-target="#verify" >Get verify</a>';
    }
    
    
    
    
?>
</head>
 <style>
  body {
    font: 400 15px Lato, sans-serif;
    line-height: 1.8;
    color: #818181;
    font-family: 'century gothic';
  }
  h2 {
    font-size: 24px;
    text-transform: uppercase;
    color: #303030;
    font-weight: 600;
    margin-bottom: 30px;
  }
  h4 {
    font-size: 19px;
    line-height: 1.375em;
    color: #303030;
    font-weight: 400;
    margin-bottom: 30px;
  }  
  .jumbotron {
    background-color: lightgreen;
    color: darkgreen;
    padding: 40px 25px;
    padding-top:70px;
    font-family: Montserrat, sans-serif; 
    
  }
  .container-fluid {
    padding: 40px 50px;
  }
  .bg-grey {
    background-color: #f6f6f6;
  }
  .logo-small {
    color: darkgreen;
    font-size: 50px;
  }
  .logo {
    color: darkgreen;
    font-size: 200px;
  }
  .thumbnail {
    padding: 0 0 15px 0;
    border: none;
    border-radius: 0;
  }
  .thumbnail img {
    width: 100%;
    height: 100%;
    margin-bottom: 10px;
  }
  .prod:hover{
     border:2px solid grey;
      cursor: pointer;
      transition-duration: .5s;
  }
  .carousel-control.right, .carousel-control.left {
    background-image: none;
    color: darkgreen;
  }
  .carousel-indicators li {
    border-color: darkgreen;
  }
  .carousel-indicators li.active {
    background-color: darkgreen;
  }
  .item h4 {
    font-size: 19px;
    line-height: 1.375em;
    font-weight: 400;
    font-style: italic;
    margin: 70px 0;
  }
  .item span {
    font-style: normal;
  }
  .panel {
    border: 1px solid darkgreen; 
    border-radius:0 !important;
    transition: box-shadow 0.5s;
  }
  .panel:hover {
    box-shadow: 5px 0px 40px rgba(0,0,0, .2);
  }
  .panel-footer .btn:hover {
    border: 1px solid darkgreen;
    background-color: #fff !important;
    color: darkgreen;
  }
  .panel-heading {
    color: #fff !important;
    background-color:darkgreen !important;
    padding: 25px;
    border-bottom: 1px solid transparent;
    border-top-left-radius: 0px;
    border-top-right-radius: 0px;
    border-bottom-left-radius: 0px;
    border-bottom-right-radius: 0px;
  }
  .panel-footer {
    background-color: white !important;
  }
  .panel-footer h3 {
    font-size: 32px;
  }
  .panel-footer h4 {
    color: #aaa;
    font-size: 14px;
  }
  .panel-footer .btn {
    margin: 15px 0;
    background-color:darkgreen;
    color: #fff;
  }
  .navbar {
    margin-bottom: 0;
    background-color: darkgreen;
    z-index: 9999;
    border: 0;
    font-size: 12px !important;
    line-height: 1.42857143 !important;
    letter-spacing: 4px;
    border-radius: 0;
    font-family: Montserrat, sans-serif;
  }
  .navbar li a, .navbar .navbar-brand {
    color: #fff !important;
  }
  .navbar-nav li a:hover, .navbar-nav li.active a {
    color: darkgreen !important;
    background-color: #fff !important;
  }
  .navbar-default .navbar-toggle {
    border-color: transparent;
    color: #fff !important;
  }
  footer .glyphicon {
    font-size: 20px;
    margin-bottom: 20px;
    color: darkgreen;
  }
  .slideanim {visibility:hidden;}
  .slide {
    animation-name: slide;
    -webkit-animation-name: slide;
    animation-duration: 1s;
    -webkit-animation-duration: 1s;
    visibility: visible;
  }
  @keyframes slide {
    0% {
      opacity: 0;
      transform: translateY(70%);
    } 
    100% {
      opacity: 1;
      transform: translateY(0%);
    }
  }
  @-webkit-keyframes slide {
    0% {
      opacity: 0;
      -webkit-transform: translateY(70%);
    } 
    100% {
      opacity: 1;
      -webkit-transform: translateY(0%);
    }
  } 
  @media screen and (max-width: 480px) {
    .logo {
      font-size: 150px;
    }
  }
  
 .cat-btn{
     background-color: white;
 }
.cat-btn:hover{ 
    border:1px solid black;
    background-color: lightgreen;
    cursor: pointer;
    transition-duration: 1s;
} 
  </style>
</head>
<body id="myPage" data-spy="scroll" data-target=".navbar" data-offset="60">

<nav class="navbar navbar-default navbar-fixed-top">
  <div class="container">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
      <a class="navbar-brand" href="#myPage">
          <table>
              <tr>
                  <td> 
                    <img src='../assets/image/agri-logo.png' style=' height:25px; border-radius:50%;' /> 
                     
                  </td>
                  <td style='color:white;font-weight:bold;'>&nbsp;<?php  echo $userRw['user']."<small> $ver</small>";?></td>
                  <input type='hidden' id='userNo' value='<?php echo $userNo;?>' /> 
              </tr>
          </table>
      </a>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav navbar-right">
        <?php  
            $cartQry = mysqli_query($conn,"SELECT * FROM tbl_cart WHERE userNo='$userNo'  ")or die(mysqli_error($conn));
            $cartNum = mysqli_num_rows($cartQry);
            $cartNum = $cartNum==0?"":$cartNum;
            
            
            $orderQry = mysqli_query($conn,"SELECT * FROM tbl_order WHERE userNo='$userNo'  ")or die(mysqli_error($conn));
            $orderNum = mysqli_num_rows($orderQry);
            $orderNum = $orderNum==0?"":$orderNum;
        ?>
        <?php if($verified==1){ ?><li><a href="#" data-toggle="modal" data-target="#startBusiness"><span class='fas fa-store-alt' ></span> MY STORE</a></li>  <?php } ?>
        <li><a href="my-cart.php" ><span class='fa fa-shopping-cart' ></span> MY CART <sup style='color:white;'><?php echo $cartNum;?></sup></a></li>  
        <li><a href="my-order.php" ><span class='fas fa-dolly' ></span> MY ORDERS <sup style='color:white;'><?php echo $orderNum;?></sup></a></li>  
        <li><a data-target="#logout-modal" data-toggle="modal"><span class='fa fa-sign-out-alt' ></span>SIGN OUT</a></li>
      </ul>
    </div>
  </div>
</nav>

<div class="jumbotron text-center"  >
    <div class='row'>
        <div class='col-sm-3' style=''>   
        <img src='../assets/image/agri-logo.png' style='height:60px; border-radius:50%;margin-top:-30px;' />
        <strong style='font-size:50px;color:darkgreen'>e-Baligya</strong>
        </div>
        <div class='col-sm-9'> 
            <div class='row' style='margin-top:25px;'>
                <div class='col-sm-12'> 
                    <div class='input-group'> 
                    <?php
                        $srchs  = "";
                        if(isset($_GET['srch'])){
                            $srchs = $_GET['srch']; 
                        } 
                    ?>
                        <input type='text' class='form-control input-lg' id='search' value='<?php echo $srchs;?>' placeholder='Search for the product you are looking for...' />
                        <div class='input-group-btn'>
                            <button class='btn btn-success btn-lg' onclick='searchProduct();'> 
                                &nbsp;
                                <i class='fa fa-search'></i>
                                 &nbsp;
                            </button>
                        </div>
                    </div> 
                </div>
                <div class='col-sm-12' style='text-align:left'> 
                    <span class='btn-cat'>Crops</span> | 
                    <span class='btn-cat'>Livestock products</span> | 
                    <span class='btn-cat'>Processed products</span> |
                    <span class='btn-cat'>Aquatic products</span> |
                    <span class='btn-cat'>Handicrafts products</span>  
                </div>
            </div>
        </div>
    </div> 
</div> 
<script>
    function searchProduct(){
        var srch = $("#search").val();
        window.location.href = "index.php?srch="+srch;
    }
</script> 
 
<!-- Container (products Section) -->
<div id="products" class="container-fluid" style='margin-top:30px;padding-top:10px;'>
     
    <div class="row ">
    <?php
        
        $prodNo = $_GET['prodNo'];
        
        $qry0 = mysqli_query($conn,"SELECT * FROM tbl_product WHERE no='$prodNo' ")or die(mysqli_error($conn));
        $rw0 = mysqli_fetch_assoc($qry0);
        
        $price = $rw0['price']; 
        $prodNo = $rw0['no'];
        $strNo = $rw0['store'];
        
        $qry1 = mysqli_query($conn,"SELECT * FROM tbl_store WHERE no='$strNo' ")or die(mysqli_error($conn));
        $rw1 = mysqli_fetch_assoc($qry1);
        
        $rating =  "No rating";
        $raters =  "No rating";
        $rateQry = mysqli_query($conn,"SELECT * FROM tbl_rate WHERE prodNo='$prodNo' ")or die(mysqli_error($conn));
        if(mysqli_num_rows($rateQry)>0){ 
            $rateQry = mysqli_query($conn,"SELECT avg(rate) as rating, count(rate) as raters FROM tbl_rate WHERE prodNo='$prodNo' ")or die(mysqli_error($conn));
            $rateRw  = mysqli_fetch_assoc($rateQry);
            $rating  = $rateRw['rating'];
            $raters  = $rateRw['raters'];
            
        } 
        
        
        ?>
        <input type='hidden' id='prodNo'  value='<?php echo $prodNo;?>' >
        <input type='hidden' id='price'  value='<?php echo $price;?>' >
        <input type='hidden' id='strNo'  value='<?php echo $strNo;?>' >
        <div class='col-sm-4' style='border:1px solid transparent;'>
            <img src='../assets/image/<?php echo $rw0['img'];?>' style='width:100%;'/>
        </div>
        <div class='col-sm-8' style='background-color:whitesmoke'>
            <span style='font-size:40px;color:black;'>
                <strong><?php echo $rw0['name'];?></strong>
            </span>
            <div class='row'>
                <div class='col-sm-4'> 
                <?php
                            $rRating = 0;
                            $rating =  "No rating";
                            
                            $raters =  "No rating";
                            $rateQry = mysqli_query($conn,"SELECT * FROM tbl_rate WHERE prodNo='$prodNo' ")or die(mysqli_error($conn));
                            if(mysqli_num_rows($rateQry)>0){ 
                                $rateQry = mysqli_query($conn,"SELECT avg(rate) as rating, count(rate) as raters FROM tbl_rate WHERE prodNo='$prodNo' ")or die(mysqli_error($conn));
                                $rateRw  = mysqli_fetch_assoc($rateQry);
                                $rating  = $rateRw['rating'];
                                $raters  = $rateRw['raters'];
                                $rRating = round($rating);
                                
                                for($r=0;$r<$rRating;$r++){
                                    echo "<i class='fa fa-star' style='color:#D5BB10;font-size:9px;'></i>";
                                }
                                for($x=$r;$x<5;$x++){
                                    echo "<i class='fa fa-star' style='font-size:9px;'></i>";
                                }
                                echo " <small style='font-size:9px;' >$rRating | $raters </small>";
                            }else{
                                $rRating = 0;
                                
                                for($r=0;$r<$rRating;$r++){
                                    echo "<i class='fa fa-star' style='color:yellow'></i>";
                                }
                                for($x=$r;$x<5;$x++){
                                    echo "<i class='fa fa-star' style='font-size:9px;'></i>";
                                }
                                echo " <small style='font-size:9px;' >$rRating | No rating</small>";
                            }
                            
                        ?>
                </div> 
            </div>
            <div class='row'>
                <div class='col-sm-12'> 
                     
                </div> 
            </div>
            <div class='row'>
                <div class='col-sm-12'> 
                        <small style='font-size:12px;color:grey' ><?php echo $rw0['description'];?></small>
                </div> 
            </div>
            <div class='row'>
                <div class='col-sm-12'>
                    <span style='font-size:25px;color:darkgreen; font-weight:bold;'>&#8369; <?php echo number_format($price,2);?><span style='font-size:9px;color:grey'>/<?php echo $rw0['unit'];?></span></span> 
                </div> 
            </div>
            <div class='row'> 
                <div class='col-sm-2 col-xs-6'> 
                    Quantity
                    <div class='input-group'>
                        <span class='input-group-addon'  onclick='addQuatity(-1)'><i class='fa fa-chevron-left'></i></span>
                        <input type='text' id='qty' class='form-control' value='1' style='text-align:center'>
                        <span class='input-group-addon' onclick='addQuatity(1)'><i class='fa fa-chevron-right'></i></span>
                    </div>
                </div> 
            </div>
            <hr />
            <div class='row'>
                <div class='col-sm-12 col-xs-12'> 
                    Total
                    <div class='row'>
                        <div class='col-sm-12' id='total' style='font-size:35px;color:darkgreen; font-weight:bold;'>&#8369; <?php echo number_format($price,2);?></div>
                    </div>
                </div>
            </div>
            <div class='row'>
                <div class='col-sm-12'>
                    <button class='btn btn-default btn-lg' style='border-radius:0px; ' onclick='addToCart()'><span class='fa fa-shopping-cart' ></span> Add to Cart</button>
                    <button class='btn btn-success btn-lg' style='border-radius:0px; ' onclick='orderProduct()'><span class='fas fa-dolly' ></span> Order product</button>
                </div>
            </div>
            <div class='row'>
                <div class='col-sm-12' id='order' ></div>
            </div>
            <br />
            <br />
            <div class='row'>
                <div class='col-sm-12'>
                    <button class='btn btn-warning' onclick="history.back()" ><i class='fa fa-chevron-left'></i> Back </button>
                    <br />
                    <br />
                </div>
            </div>
        </div>
    </div>
</div>
<script>
    function buy(prodNo){
        var userNo = $("#userNo").val(); 
    }
    
    function addQuatity(v){
        var qty = parseInt($("#qty").val()); 
        var prc = parseFloat($("#price").val()); 
        qty += parseInt(v);
        if(qty<=0){
            qty = 1;
        }
        $("#qty").val(qty);
        var total = qty * prc;
        var ttl   = total.toFixed(2)
        $("#total").html("&#8369; "+ttl)
    }
    function addToCart(){  
        var qty = parseFloat($("#qty").val()); 
        var prc = parseFloat($("#price").val());  
        var strNo = $("#strNo").val(); 
        form_data = new  FormData();  
        form_data.append("prodNo",$("#prodNo").val());
        form_data.append("qty",qty); 
        form_data.append("prc",prc);  
        form_data.append("strNo",strNo);
        $.ajax({
            url: "../query/add-to-cart.php",
            method: "POST",
            data: form_data,
            contentType: false,
            cache: false,
            processData: false,
            beforeSend: function(){
            },
            success: function(data){ 
                $("#order").html(data);
            }
        });
        return false;
    }
    function orderProduct(){  
        var qty = parseFloat($("#qty").val()); 
        var prc = parseFloat($("#price").val()); 
        form_data = new  FormData();  
        form_data.append("prodNo",$("#prodNo").val());
        form_data.append("qty",qty); 
        form_data.append("prc",prc); 
        $.ajax({
            url: "../query/order-product.php",
            method: "POST",
            data: form_data,
            contentType: false,
            cache: false,
            processData: false,
            beforeSend: function(){
            },
            success: function(data){ 
                $("#order").html(data);
            }
        });
        return false;
    }
     
</script>

<!-- Container (Contact Section) -->
<div id="contact" class="container-fluid bg-grey">
  <h2 class="text-center">COSTUMER SERVICES</h2>
  <div class="row">
    <div class="col-sm-4 col-sm-offset-4">
      <p>Please contact us</p>
      <p><span class="fa fa-home"></span>Business and Management Department</p>
      <p><span class="fa fa-university"></span>Southern Leyte State University-San Juan Campus</p>
      <p><span class="glyphicon glyphicon-map-marker"></span>San Jose, San Juan, Southern Leyte</p> 
      <p><span class="glyphicon glyphicon-envelope"></span> dbma_sj@southernleytestateu.com</p>
    </div> 
  </div>
</div> 

<footer class="container-fluid text-center">
  <a href="#myPage" title="To Top">
    <span class="glyphicon glyphicon-chevron-up"></span>
  </a> 
</footer>

<!--LOGOUT MODAL-->
<div id="logout-modal" class="modal fade" role="dialog" style='z-index:999999'>
    <div class="modal-dialog  modal-md"  >  
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title" style='font-weight:bold; color:#192428'>
                    <img src='../assets/image/agri-logo.png' style='height:40px; border-radius:50%;' />
                    Express Wheel | Sign out
                </h4>
            </div>
            <div class="modal-body">  
                <div class='row'> 
                    <div class='col-sm-12'> 
                         Do you really want to continue?   
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <a type="button" class="btn btn-default" data-dismiss="modal">Cancel</a>
                <a type="button" class="btn btn-success" href="../index.php" >Sign out</a>
            </div>
        </div>
    </div>
</div> 

<script>
$(document).ready(function(){
  // Add smooth scrolling to all links in navbar + footer link
  $(".navbar a, footer a[href='#myPage']").on('click', function(event) {
    // Make sure this.hash has a value before overriding default behavior
    if (this.hash !== "") {
      // Prevent default anchor click behavior
      event.preventDefault();

      // Store hash
      var hash = this.hash;

      // Using jQuery's animate() method to add smooth page scroll
      // The optional number (900) specifies the number of milliseconds it takes to scroll to the specified area
      $('html, body').animate({
        scrollTop: $(hash).offset().top
      }, 900, function(){
   
        // Add hash (#) to URL when done scrolling (default click behavior)
        window.location.hash = hash;
      });
    } // End if
  });
  
  $(window).scroll(function() {
    $(".slideanim").each(function(){
      var pos = $(this).offset().top;

      var winTop = $(window).scrollTop();
        if (pos < winTop + 600) {
          $(this).addClass("slide");
        }
    });
  });
})
</script>

</body>
</html>