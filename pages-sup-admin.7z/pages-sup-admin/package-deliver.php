<?php
    include "../components/comp-conn.php";
    
    $order_id = $_POST['order_id'];
    $branch_id = $_POST['branch_id'];
    $rider = $_POST['rider'];
    $time = date('h:i:s');
    $date = date('Y-m-d');
    $status = 1;
    $message;
   
    // GET THE LATEST LOCATION KULANG PA TA OG COLUMN FOR LOCATION SA TABLE
    // $result = mysqli_query($conn, "select * from tbl_user_track_history WHERE order_id = '$order_id' ORDER BY date DESC LIMIT 1 ");
   
    // if( $row = mysqli_fetch_assoc($result)){
        
    // }
    
    
    
    $note = "Your package is out for delivery.";
        
    $query1 = "INSERT INTO tbl_user_track_history (order_id, note, status, date, time) VALUES ('$order_id', '$note', '$status', '$date', '$time')";
    mysqli_query($conn, $query1);
    
    $message = '<div class="alert alert-success">
                <strong>Package Updated:</strong>
                Package is out for delivery!
            </div>';
    

    echo $message;
   
?>
