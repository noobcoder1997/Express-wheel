<?php
    include '../components/comp-conn.php';

    if (isset($_POST['date'])) {

        $date = $_POST['date'];
        $array_date = array();
        $fare = 0;
        $timestamp = "";

        $query = "SELECT DATE_FORMAT(_timestamp, '%Y-%m-%d') AS '_timestamp', SUM(fares) AS fare FROM ( SELECT _timestamp, fare AS fares FROM tbl_book_ride WHERE DATE_FORMAT(_timestamp, '%Y-%m-%d') = '$date' AND status = 2 AND rider_status = 2 UNION ALL SELECT _timestamp, fee AS fares FROM tbl_user_make_order WHERE DATE_FORMAT(_timestamp, '%Y-%m-%d') = '$date' AND status = 2 AND rider_status = 2 ) AS combined GROUP BY DATE_FORMAT(_timestamp, '%Y-%m-%d') ";

        $result = mysqli_query($conn, $query);

        if(mysqli_num_rows($result) > 0){
            while ($row = mysqli_fetch_assoc($result)) {
                $fare += $row['fare']; 
                $timestamp = $row['_timestamp'];
            }
        }

        array_push($array_date, [
            'date' => $timestamp,
            'fare' => $fare,
            'payback' => ($fare * 0.20),     
            'final_income' => ($fare - ($fare * 0.20))               
        ]);

        echo json_encode($array_date);
    }
?>