<?php
    include '../components/comp-conn.php';
    session_start();
    
    $id = $_POST['id'];
    
    $query = "delete from tbl_user where no = '$id' ";
    mysqli_query($conn, $query);
    
    echo "User removed successfuly!";
?>